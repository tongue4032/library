<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-17 04:02:29 --> Query error: Column 'barcode' cannot be null - Invalid query: INSERT INTO `lib_book_action` (`barcode`, `bookname`, `author`, `user_id`, `username`, `borrow_time`) VALUES (NULL, NULL, NULL, '1', 'user', '2019-04-17')
ERROR - 2019-04-17 04:08:56 --> Severity: Notice --> Undefined variable: id /Applications/MAMP/htdocs/CI/application/views/query.php 32
ERROR - 2019-04-17 04:08:56 --> Severity: Notice --> Undefined variable: id /Applications/MAMP/htdocs/CI/application/views/query.php 32
ERROR - 2019-04-17 05:10:22 --> Query error: Unknown column '安庆' in 'where clause' - Invalid query: SELECT *
FROM `lib_bookinfo`
WHERE `安庆` IS NULL
ERROR - 2019-04-17 05:10:59 --> Query error: Unknown column '安庆' in 'where clause' - Invalid query: SELECT *
FROM `lib_bookinfo`
WHERE `安庆` IS NULL
ERROR - 2019-04-17 05:11:08 --> Query error: Unknown column '安庆' in 'where clause' - Invalid query: SELECT *
FROM `lib_bookinfo`
WHERE `安庆` IS NULL
ERROR - 2019-04-17 05:11:16 --> Query error: Unknown column '庆山' in 'where clause' - Invalid query: SELECT *
FROM `lib_bookinfo`
WHERE `庆山` IS NULL
ERROR - 2019-04-17 05:13:29 --> Query error: Table 'library.流浪地球' doesn't exist - Invalid query: SELECT *
FROM `流浪地球`
ERROR - 2019-04-17 05:13:56 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2019-04-17 05:14:06 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2019-04-17 05:42:20 --> Severity: Notice --> Use of undefined constant bookname - assumed 'bookname' /Applications/MAMP/htdocs/CI/application/models/User_model.php 66
ERROR - 2019-04-17 05:42:20 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2019-04-17 05:42:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-17 05:43:09 --> Severity: Notice --> Use of undefined constant bookname - assumed 'bookname' /Applications/MAMP/htdocs/CI/application/models/User_model.php 66
ERROR - 2019-04-17 05:43:09 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2019-04-17 05:43:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:222) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-17 05:46:16 --> Severity: Notice --> Use of undefined constant bookname - assumed 'bookname' /Applications/MAMP/htdocs/CI/application/models/User_model.php 66
ERROR - 2019-04-17 05:46:16 --> Query error: Table 'library.流浪地球' doesn't exist - Invalid query: SELECT *
FROM `流浪地球`
ERROR - 2019-04-17 05:46:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:222) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-17 05:47:20 --> Severity: Notice --> Use of undefined constant bookname - assumed 'bookname' /Applications/MAMP/htdocs/CI/application/models/User_model.php 66
ERROR - 2019-04-17 05:47:20 --> Query error: Table 'library.流浪地球' doesn't exist - Invalid query: SELECT *
FROM `流浪地球`
ERROR - 2019-04-17 05:47:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:222) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-17 05:47:32 --> Severity: Notice --> Use of undefined constant bookname - assumed 'bookname' /Applications/MAMP/htdocs/CI/application/models/User_model.php 66
ERROR - 2019-04-17 05:47:32 --> Query error: Table 'library.庆山' doesn't exist - Invalid query: SELECT *
FROM `庆山`
ERROR - 2019-04-17 05:47:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:222) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-17 05:49:56 --> Severity: Notice --> Use of undefined constant bookname - assumed 'bookname' /Applications/MAMP/htdocs/CI/application/models/User_model.php 66
ERROR - 2019-04-17 05:49:56 --> Query error: Table 'library.庆山' doesn't exist - Invalid query: SELECT *
FROM `庆山`
ERROR - 2019-04-17 05:49:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-17 05:50:04 --> Severity: Notice --> Use of undefined constant bookname - assumed 'bookname' /Applications/MAMP/htdocs/CI/application/models/User_model.php 66
ERROR - 2019-04-17 05:50:04 --> Query error: Table 'library.流浪地球' doesn't exist - Invalid query: SELECT *
FROM `流浪地球`
ERROR - 2019-04-17 05:50:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-17 05:50:36 --> Query error: Table 'library.流浪地球' doesn't exist - Invalid query: SELECT *
FROM `流浪地球`
ERROR - 2019-04-17 05:51:14 --> Query error: Table 'library.流浪地球' doesn't exist - Invalid query: SELECT *
FROM `流浪地球`
ERROR - 2019-04-17 05:51:35 --> Query error: Unknown column '流浪地球' in 'where clause' - Invalid query: SELECT *
FROM `lib_bookinfo`
WHERE `流浪地球` IS NULL
ERROR - 2019-04-17 05:52:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 2 - Invalid query: SELECT *
FROM 
ERROR - 2019-04-17 05:54:03 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::where() /Applications/MAMP/htdocs/CI/application/models/User_model.php 68
ERROR - 2019-04-17 16:04:05 --> 404 Page Not Found: Docs-assets/ico
ERROR - 2019-04-17 17:55:10 --> 404 Page Not Found: Docs-assets/ico
