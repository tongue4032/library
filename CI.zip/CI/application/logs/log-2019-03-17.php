<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-17 03:01:45 --> 404 Page Not Found: Docs-assets/ico
