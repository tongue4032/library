<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-25 03:33:37 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 03:33:37 --> Query error: Unknown column 'time' in 'field list' - Invalid query: INSERT INTO `lib_borrow` (`username`, `time`, `bookname`) VALUES ('user', '2019-04-25', NULL)
ERROR - 2019-04-25 03:33:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 03:35:49 --> Severity: error --> Exception: syntax error, unexpected ')' /Applications/MAMP/htdocs/CI/application/models/Book_model.php 43
ERROR - 2019-04-25 03:39:35 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/controllers/Book.php 53
ERROR - 2019-04-25 03:44:45 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-25 03:45:07 --> Severity: Notice --> Undefined variable: bookname /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-25 03:45:09 --> Severity: Notice --> Undefined variable: bookname /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-25 03:46:33 --> Severity: Notice --> Undefined index: id /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-25 03:46:51 --> Severity: Notice --> Undefined index: id /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-25 05:03:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 2 - Invalid query: SELECT *
FROM 1
ERROR - 2019-04-25 05:04:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '13' at line 2 - Invalid query: SELECT *
FROM 13
ERROR - 2019-04-25 05:20:55 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-25 05:21:30 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-25 05:24:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0, 1, 2, `username`, `borrow_time`) VALUES ('barcode', 'bookname', 'author', 'us' at line 1 - Invalid query: INSERT INTO `lib_borrow` (0, 1, 2, `username`, `borrow_time`) VALUES ('barcode', 'bookname', 'author', 'user', '2019-04-25')
ERROR - 2019-04-25 05:25:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0, 1, 2, `username`, `borrow_time`) VALUES ('barcode', 'bookname', 'author', 'us' at line 1 - Invalid query: INSERT INTO `lib_borrow` (0, 1, 2, `username`, `borrow_time`) VALUES ('barcode', 'bookname', 'author', 'user', '2019-04-25')
ERROR - 2019-04-25 05:36:41 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 05:36:41 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/models/Book_model.php 40
ERROR - 2019-04-25 05:36:41 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/models/Book_model.php 41
ERROR - 2019-04-25 05:36:41 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/database/DB_driver.php 1477
ERROR - 2019-04-25 05:36:41 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `lib_borrow` (`barcode`, `bookname`, `author`, `user_id`, `username`, `borrow_time`) VALUES ('2', '2', '2', Array, 'user', '1')
ERROR - 2019-04-25 05:36:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 05:36:43 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 05:36:43 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/models/Book_model.php 40
ERROR - 2019-04-25 05:36:43 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/models/Book_model.php 41
ERROR - 2019-04-25 05:36:43 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/database/DB_driver.php 1477
ERROR - 2019-04-25 05:36:43 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `lib_borrow` (`barcode`, `bookname`, `author`, `user_id`, `username`, `borrow_time`) VALUES ('2', '2', '2', Array, 'user', '1')
ERROR - 2019-04-25 05:36:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 05:39:47 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 05:39:47 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/models/Book_model.php 40
ERROR - 2019-04-25 05:39:47 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/models/Book_model.php 41
ERROR - 2019-04-25 05:39:47 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/CI/application/models/Book_model.php 42
ERROR - 2019-04-25 05:39:47 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/CI/application/models/Book_model.php 43
ERROR - 2019-04-25 05:39:47 --> Severity: Notice --> Undefined index: time /Applications/MAMP/htdocs/CI/application/models/Book_model.php 44
ERROR - 2019-04-25 05:39:47 --> Query error: Column 'barcode' cannot be null - Invalid query: INSERT INTO `lib_borrow` (`barcode`, `bookname`, `author`, `user_id`, `username`, `borrow_time`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-04-25 05:39:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 05:41:56 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 05:41:56 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/models/Book_model.php 40
ERROR - 2019-04-25 05:41:56 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/models/Book_model.php 41
ERROR - 2019-04-25 05:41:56 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/CI/application/models/Book_model.php 42
ERROR - 2019-04-25 05:41:56 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/CI/application/models/Book_model.php 43
ERROR - 2019-04-25 05:41:56 --> Severity: Notice --> Undefined index: time /Applications/MAMP/htdocs/CI/application/models/Book_model.php 44
ERROR - 2019-04-25 05:41:56 --> Query error: Column 'barcode' cannot be null - Invalid query: INSERT INTO `lib_borrow` (`barcode`, `bookname`, `author`, `user_id`, `username`, `borrow_time`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-04-25 05:41:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 05:42:26 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 05:42:26 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/models/Book_model.php 40
ERROR - 2019-04-25 05:42:26 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/CI/application/models/Book_model.php 41
ERROR - 2019-04-25 05:42:26 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/CI/application/models/Book_model.php 42
ERROR - 2019-04-25 05:42:26 --> Severity: Notice --> Undefined index: time /Applications/MAMP/htdocs/CI/application/models/Book_model.php 43
ERROR - 2019-04-25 05:42:26 --> Query error: Column 'bookname' cannot be null - Invalid query: INSERT INTO `lib_borrow` (`bookname`, `author`, `user_id`, `username`, `borrow_time`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-04-25 05:42:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 05:42:41 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 05:42:41 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/CI/application/models/Book_model.php 40
ERROR - 2019-04-25 05:42:41 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/CI/application/models/Book_model.php 41
ERROR - 2019-04-25 05:42:41 --> Severity: Notice --> Undefined index: time /Applications/MAMP/htdocs/CI/application/models/Book_model.php 42
ERROR - 2019-04-25 05:42:41 --> Query error: Column 'author' cannot be null - Invalid query: INSERT INTO `lib_borrow` (`author`, `user_id`, `username`, `borrow_time`) VALUES (NULL, NULL, NULL, NULL)
ERROR - 2019-04-25 05:42:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 05:42:51 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 05:42:51 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/CI/application/models/Book_model.php 40
ERROR - 2019-04-25 05:42:51 --> Severity: Notice --> Undefined index: time /Applications/MAMP/htdocs/CI/application/models/Book_model.php 41
ERROR - 2019-04-25 05:42:51 --> Query error: Column 'user_id' cannot be null - Invalid query: INSERT INTO `lib_borrow` (`user_id`, `username`, `borrow_time`) VALUES (NULL, NULL, NULL)
ERROR - 2019-04-25 05:42:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 05:43:53 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 05:43:53 --> Query error: Column 'barcode' cannot be null - Invalid query: INSERT INTO `lib_borrow` (`barcode`) VALUES (NULL)
ERROR - 2019-04-25 05:43:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 05:46:23 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 05:46:23 --> Query error: Table 'library.tbl_borrow' doesn't exist - Invalid query: INSERT INTO `TBL_BORROW` (`barcode`) VALUES (NULL)
ERROR - 2019-04-25 05:46:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 05:50:05 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 05:50:05 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/models/Book_model.php 40
ERROR - 2019-04-25 05:50:05 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/models/Book_model.php 41
ERROR - 2019-04-25 05:50:05 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/CI/application/models/Book_model.php 42
ERROR - 2019-04-25 05:50:05 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/CI/application/models/Book_model.php 43
ERROR - 2019-04-25 05:50:05 --> Severity: Notice --> Undefined index: time /Applications/MAMP/htdocs/CI/application/models/Book_model.php 44
ERROR - 2019-04-25 05:50:05 --> Query error: Column 'barcode' cannot be null - Invalid query: INSERT INTO `lib_borrow` (`barcode`, `bookname`, `author`, `user_id`, `username`, `borrow_time`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-04-25 05:50:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 05:51:29 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 05:51:29 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/models/Book_model.php 40
ERROR - 2019-04-25 05:51:29 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/models/Book_model.php 41
ERROR - 2019-04-25 05:51:29 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/CI/application/models/Book_model.php 42
ERROR - 2019-04-25 05:51:29 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/CI/application/models/Book_model.php 43
ERROR - 2019-04-25 05:51:29 --> Severity: Notice --> Undefined index: time /Applications/MAMP/htdocs/CI/application/models/Book_model.php 44
ERROR - 2019-04-25 05:51:29 --> Query error: Column 'barcode' cannot be null - Invalid query: INSERT INTO `lib_borrow` (`barcode`, `bookname`, `author`, `user_id`, `username`, `borrow_time`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-04-25 05:51:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 05:53:17 --> Severity: Notice --> Undefined index: book /Applications/MAMP/htdocs/CI/application/controllers/Book.php 58
ERROR - 2019-04-25 05:53:17 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 05:53:17 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/models/Book_model.php 40
ERROR - 2019-04-25 05:53:17 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/models/Book_model.php 41
ERROR - 2019-04-25 05:53:17 --> Query error: Column 'barcode' cannot be null - Invalid query: INSERT INTO `lib_borrow` (`barcode`, `bookname`, `author`, `user_id`, `username`, `borrow_time`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-04-25 05:53:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 05:54:01 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 05:54:01 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/models/Book_model.php 40
ERROR - 2019-04-25 05:54:01 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/models/Book_model.php 41
ERROR - 2019-04-25 05:54:01 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/CI/application/models/Book_model.php 42
ERROR - 2019-04-25 05:54:01 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/CI/application/models/Book_model.php 43
ERROR - 2019-04-25 05:54:01 --> Severity: Notice --> Undefined index: time /Applications/MAMP/htdocs/CI/application/models/Book_model.php 44
ERROR - 2019-04-25 05:54:01 --> Query error: Column 'barcode' cannot be null - Invalid query: INSERT INTO `lib_borrow` (`barcode`, `bookname`, `author`, `user_id`, `username`, `borrow_time`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-04-25 05:54:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-25 06:00:16 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-25 06:00:16 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/models/Book_model.php 40
ERROR - 2019-04-25 06:00:16 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/models/Book_model.php 41
ERROR - 2019-04-25 06:00:16 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/CI/application/models/Book_model.php 42
ERROR - 2019-04-25 06:00:16 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/CI/application/models/Book_model.php 43
ERROR - 2019-04-25 06:00:16 --> Severity: Notice --> Undefined index: time /Applications/MAMP/htdocs/CI/application/models/Book_model.php 44
