<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-15 03:12:02 --> 404 Page Not Found: Form/index
ERROR - 2019-02-15 03:18:56 --> 404 Page Not Found: Form/index
ERROR - 2019-02-15 03:19:15 --> 404 Page Not Found: Form/index
ERROR - 2019-02-15 03:24:08 --> 404 Page Not Found: Form/index
ERROR - 2019-02-15 03:24:22 --> 404 Page Not Found: Form/index
ERROR - 2019-02-15 03:24:58 --> 404 Page Not Found: Form/index
ERROR - 2019-02-15 03:25:27 --> Severity: error --> Exception: /Applications/MAMP/htdocs/CI/application/models/User_model.php exists, but doesn't declare class User_model /Applications/MAMP/htdocs/CI/system/core/Loader.php 340
ERROR - 2019-02-15 04:06:23 --> Severity: error --> Exception: /Applications/MAMP/htdocs/CI/application/models/User_model.php exists, but doesn't declare class User_model /Applications/MAMP/htdocs/CI/system/core/Loader.php 340
ERROR - 2019-02-15 04:20:22 --> Severity: error --> Exception: Call to undefined function run() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 43
ERROR - 2019-02-15 04:20:56 --> Severity: Notice --> Use of undefined constant flase - assumed 'flase' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 43
ERROR - 2019-02-15 04:20:56 --> Query error: Unknown column 'reg_time' in 'field list' - Invalid query: INSERT INTO `lib_user` (`username`, `password`, `email`, `reg_time`) VALUES ('user1', 'e10adc3949ba59abbe56e057f20f883e', '2046817306@qq.com', 1550200856)
ERROR - 2019-02-15 04:20:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-15 04:28:33 --> Severity: Notice --> Use of undefined constant flase - assumed 'flase' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 43
ERROR - 2019-02-15 04:28:33 --> Query error: Unknown column 'reg_time' in 'field list' - Invalid query: INSERT INTO `lib_user` (`username`, `password`, `email`, `reg_time`) VALUES ('user1', 'e10adc3949ba59abbe56e057f20f883e', '2046817306@qq.com', 1550201313)
ERROR - 2019-02-15 04:28:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-15 05:03:24 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 05:04:50 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 05:04:58 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 05:10:08 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:11:41 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:11:49 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:11:50 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:11:50 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:11:50 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:11:51 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:12:18 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:12:19 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:12:19 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:12:20 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:12:20 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:12:20 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:13:44 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:13:44 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:13:45 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:13:45 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:13:45 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:13:45 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:13:45 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:13:46 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:13:46 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:13:46 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:13:46 --> Severity: error --> Exception: Call to undefined function view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-15 07:18:43 --> Severity: error --> Exception: Call to undefined function row_array() /Applications/MAMP/htdocs/CI/application/models/User_model.php 18
ERROR - 2019-02-15 07:20:28 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 07:20:28 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 07:20:36 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 07:20:36 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 07:20:39 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 07:20:39 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:08:21 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:08:21 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:09:08 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:09:08 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:09:27 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:09:27 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:12:48 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:12:48 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:12:48 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:12:48 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:12:48 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:12:48 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:12:49 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:12:49 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:12:49 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:12:49 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:12:49 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:12:49 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:12:49 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:12:49 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:13:03 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:13:03 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:13:29 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:13:29 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:13:40 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:13:40 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:13:41 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:13:41 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:13:41 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:13:41 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:13:41 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:13:41 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:14:16 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:14:16 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:14:17 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:14:17 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:14:17 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:14:17 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:14:21 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:14:21 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:14:22 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:14:22 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:14:22 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:14:22 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:14:36 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:14:36 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:14:40 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:15:14 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:15:14 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:15:56 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:15:56 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:17:17 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:17:17 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:17:18 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:17:18 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:17:18 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:17:18 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:17:18 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:17:18 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:17:19 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:17:19 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:18:05 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:18:05 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:18:29 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:18:29 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:19:13 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:19:13 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:19:13 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:19:13 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:19:13 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:19:13 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:19:35 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:19:35 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:20:19 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:20:19 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:21:49 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:21:49 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:22:24 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:22:24 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:22:43 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:22:43 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:23:34 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 08:23:34 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:25:27 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 08:25:27 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 10:13:37 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 10:13:37 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 12:22:32 --> Severity: Notice --> Use of undefined constant flase - assumed 'flase' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 45
ERROR - 2019-02-15 12:22:32 --> Query error: Unknown column 'reg_time' in 'field list' - Invalid query: INSERT INTO `lib_user` (`username`, `password`, `email`, `reg_time`) VALUES ('user1', 'e10adc3949ba59abbe56e057f20f883e', '2046817306@qq.com', 1550229752)
ERROR - 2019-02-15 12:22:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-15 12:25:51 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 12:25:51 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 12:33:38 --> Query error: Unknown column 'reg_time' in 'field list' - Invalid query: INSERT INTO `lib_user` (`username`, `password`, `email`, `reg_time`) VALUES ('user1', 'Tony1411--', '2046817306@qq.com', 1550230418)
ERROR - 2019-02-15 12:45:16 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 12:45:16 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 12:49:47 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-15 12:49:47 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-15 12:50:52 --> 404 Page Not Found: Home/main.js
ERROR - 2019-02-15 12:50:52 --> 404 Page Not Found: Home/main.css
ERROR - 2019-02-15 12:58:12 --> 404 Page Not Found: Home/main.css
ERROR - 2019-02-15 12:58:12 --> 404 Page Not Found: Home/main.js
ERROR - 2019-02-15 12:58:51 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `lib_user` (`username`, `password`, `email`) VALUES ('haha', 'john1234', '2046817306@me.com')
