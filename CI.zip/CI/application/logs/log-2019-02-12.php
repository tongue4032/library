<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-12 03:17:52 --> Severity: error --> Exception: Call to undefined function set_value() /Applications/MAMP/htdocs/CI/application/views/register.php 33
ERROR - 2019-02-12 03:37:46 --> 404 Page Not Found: Controllers/home
ERROR - 2019-02-12 04:03:29 --> 404 Page Not Found: Controllers/home
ERROR - 2019-02-12 04:03:46 --> 404 Page Not Found: Controllers/home
ERROR - 2019-02-12 04:04:06 --> 404 Page Not Found: Controllers/home
ERROR - 2019-02-12 04:05:54 --> Severity: error --> Exception: Call to undefined function form_open() /Applications/MAMP/htdocs/CI/application/views/login.php 30
ERROR - 2019-02-12 04:09:04 --> Severity: error --> Exception: Call to undefined function form_open() /Applications/MAMP/htdocs/CI/application/views/login.php 30
ERROR - 2019-02-12 04:17:16 --> 404 Page Not Found: Home/Home
ERROR - 2019-02-12 04:17:25 --> 404 Page Not Found: Home/Home
ERROR - 2019-02-12 04:17:27 --> 404 Page Not Found: Home/Home
ERROR - 2019-02-12 04:17:49 --> 404 Page Not Found: Home/login
ERROR - 2019-02-12 04:18:07 --> 404 Page Not Found: Home/login
ERROR - 2019-02-12 04:18:08 --> 404 Page Not Found: Home/login
ERROR - 2019-02-12 04:18:20 --> 404 Page Not Found: Home/Home
ERROR - 2019-02-12 04:29:49 --> Severity: error --> Exception: Call to undefined function set_value() /Applications/MAMP/htdocs/CI/application/views/login.php 33
ERROR - 2019-02-12 08:59:57 --> 404 Page Not Found: Css/style1.css
