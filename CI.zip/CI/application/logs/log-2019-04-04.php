<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-04 03:39:37 --> 404 Page Not Found: Docs-assets/ico
