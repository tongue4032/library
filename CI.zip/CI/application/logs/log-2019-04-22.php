<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-22 06:06:14 --> 404 Page Not Found: Home/index
ERROR - 2019-04-22 06:07:46 --> 404 Page Not Found: Home/index
ERROR - 2019-04-22 06:07:48 --> 404 Page Not Found: Home/register
ERROR - 2019-04-22 06:07:56 --> 404 Page Not Found: Home/username_login
ERROR - 2019-04-22 06:11:22 --> 404 Page Not Found: Home/index
ERROR - 2019-04-22 08:20:29 --> 404 Page Not Found: Home/captcha
ERROR - 2019-04-22 08:20:39 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:20:40 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:20:42 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:20:42 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:20:43 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:20:55 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:20:56 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:20:56 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:20:56 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:23:34 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:31:26 --> 404 Page Not Found: Secure/index
ERROR - 2019-04-22 08:32:05 --> 404 Page Not Found: Secure/index
ERROR - 2019-04-22 08:32:06 --> 404 Page Not Found: Secure/register
ERROR - 2019-04-22 08:32:08 --> 404 Page Not Found: Secure/username_login
ERROR - 2019-04-22 08:32:10 --> 404 Page Not Found: Secure/forget
ERROR - 2019-04-22 08:38:59 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:38:59 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:38:59 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:39:00 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:39:00 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:39:07 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:39:10 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:39:10 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:39:11 --> 404 Page Not Found: Secure/search
ERROR - 2019-04-22 08:49:26 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 255
ERROR - 2019-04-22 08:49:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 08:49:36 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 255
ERROR - 2019-04-22 08:49:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 08:49:44 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 255
ERROR - 2019-04-22 08:49:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 08:49:51 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 255
ERROR - 2019-04-22 08:49:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 08:49:54 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 255
ERROR - 2019-04-22 08:49:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 08:50:09 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 255
ERROR - 2019-04-22 08:50:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 08:54:11 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 318
ERROR - 2019-04-22 08:54:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 08:54:28 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 318
ERROR - 2019-04-22 08:54:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 09:01:11 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 318
ERROR - 2019-04-22 09:01:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 09:01:26 --> 404 Page Not Found: Book/sarch
ERROR - 2019-04-22 09:01:26 --> 404 Page Not Found: Book/sarch
ERROR - 2019-04-22 09:01:36 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 318
ERROR - 2019-04-22 09:01:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 09:13:23 --> 404 Page Not Found: Home/index
ERROR - 2019-04-22 09:14:26 --> 404 Page Not Found: Home/index
ERROR - 2019-04-22 09:14:29 --> 404 Page Not Found: Book/index
ERROR - 2019-04-22 09:15:13 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 318
ERROR - 2019-04-22 09:15:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 09:15:25 --> 404 Page Not Found: Secure/user_info
ERROR - 2019-04-22 09:17:54 --> 404 Page Not Found: Home/modify
ERROR - 2019-04-22 09:19:35 --> 404 Page Not Found: Home/user_info
ERROR - 2019-04-22 09:19:53 --> 404 Page Not Found: Home/user_info
ERROR - 2019-04-22 09:25:47 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 318
ERROR - 2019-04-22 09:25:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 09:26:16 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 255
ERROR - 2019-04-22 09:26:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 09:26:49 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:26:56 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:26:59 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:27:10 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:27:18 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:27:23 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:27:51 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:27:56 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 534
ERROR - 2019-04-22 09:27:56 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/core/Config.php 340
ERROR - 2019-04-22 09:27:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-04-22 09:31:25 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:32:38 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:32:42 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:33:48 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:33:59 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:34:04 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:35:51 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:35:56 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:36:06 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:36:10 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:36:22 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:36:29 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/query.php 27
ERROR - 2019-04-22 09:36:29 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 27
ERROR - 2019-04-22 09:38:18 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:41:21 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:42:54 --> Severity: error --> Exception: Call to undefined function required() /Applications/MAMP/htdocs/CI/application/controllers/Book.php 32
ERROR - 2019-04-22 09:43:51 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:44:44 --> 404 Page Not Found: Home/borrow
ERROR - 2019-04-22 09:45:59 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 09:46:30 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 10:14:36 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/query.php 27
ERROR - 2019-04-22 10:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 27
ERROR - 2019-04-22 10:18:23 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/query.php 27
ERROR - 2019-04-22 10:18:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 27
ERROR - 2019-04-22 10:21:07 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 28
ERROR - 2019-04-22 10:23:16 --> Severity: Notice --> Undefined property: Book::$sesson /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:23:16 --> Severity: error --> Exception: Call to a member function set_userdata() on null /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:23:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-22 10:23:18 --> Severity: Notice --> Undefined property: Book::$sesson /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:23:18 --> Severity: error --> Exception: Call to a member function set_userdata() on null /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:23:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-22 10:23:18 --> Severity: Notice --> Undefined property: Book::$sesson /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:23:18 --> Severity: error --> Exception: Call to a member function set_userdata() on null /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:23:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-22 10:23:19 --> Severity: Notice --> Undefined property: Book::$sesson /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:23:19 --> Severity: error --> Exception: Call to a member function set_userdata() on null /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:23:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-22 10:23:42 --> Severity: Notice --> Undefined property: Book::$sesson /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:23:42 --> Severity: error --> Exception: Call to a member function set_userdata() on null /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:23:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-22 10:24:04 --> Severity: Notice --> Undefined property: Book::$sesson /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:04 --> Severity: error --> Exception: Call to a member function set_userdata() on null /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-22 10:24:04 --> Severity: Notice --> Undefined property: Book::$sesson /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:04 --> Severity: error --> Exception: Call to a member function set_userdata() on null /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-22 10:24:04 --> Severity: Notice --> Undefined property: Book::$sesson /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:04 --> Severity: error --> Exception: Call to a member function set_userdata() on null /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-22 10:24:05 --> Severity: Notice --> Undefined property: Book::$sesson /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:05 --> Severity: error --> Exception: Call to a member function set_userdata() on null /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-22 10:24:05 --> Severity: Notice --> Undefined property: Book::$sesson /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:05 --> Severity: error --> Exception: Call to a member function set_userdata() on null /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-22 10:24:05 --> Severity: Notice --> Undefined property: Book::$sesson /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:05 --> Severity: error --> Exception: Call to a member function set_userdata() on null /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-22 10:24:05 --> Severity: Notice --> Undefined property: Book::$sesson /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:05 --> Severity: error --> Exception: Call to a member function set_userdata() on null /Applications/MAMP/htdocs/CI/application/controllers/Book.php 33
ERROR - 2019-04-22 10:24:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-22 10:24:34 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/views/query.php 30
ERROR - 2019-04-22 10:24:34 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/views/query.php 31
ERROR - 2019-04-22 10:24:34 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/views/query.php 32
ERROR - 2019-04-22 10:24:34 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:34 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:34 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:34 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/views/query.php 30
ERROR - 2019-04-22 10:24:34 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/views/query.php 31
ERROR - 2019-04-22 10:24:34 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/views/query.php 32
ERROR - 2019-04-22 10:24:34 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:34 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:34 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:34 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/query.php 30
ERROR - 2019-04-22 10:24:34 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/query.php 31
ERROR - 2019-04-22 10:24:34 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/query.php 32
ERROR - 2019-04-22 10:24:34 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:34 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:34 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:42 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/views/query.php 30
ERROR - 2019-04-22 10:24:42 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/views/query.php 31
ERROR - 2019-04-22 10:24:42 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/views/query.php 32
ERROR - 2019-04-22 10:24:42 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:42 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:42 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:42 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/views/query.php 30
ERROR - 2019-04-22 10:24:42 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/views/query.php 31
ERROR - 2019-04-22 10:24:42 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/views/query.php 32
ERROR - 2019-04-22 10:24:42 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:42 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:42 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:42 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/query.php 30
ERROR - 2019-04-22 10:24:42 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/query.php 31
ERROR - 2019-04-22 10:24:42 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/query.php 32
ERROR - 2019-04-22 10:24:42 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:42 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:24:42 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/query.php 33
ERROR - 2019-04-22 10:27:56 --> Severity: error --> Exception: syntax error, unexpected ')' /Applications/MAMP/htdocs/CI/application/views/query.php 28
ERROR - 2019-04-22 10:28:33 --> Severity: error --> Exception: syntax error, unexpected ')' /Applications/MAMP/htdocs/CI/application/views/query.php 28
ERROR - 2019-04-22 10:30:35 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/query.php 27
ERROR - 2019-04-22 10:30:35 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 27
ERROR - 2019-04-22 10:30:47 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/query.php 27
ERROR - 2019-04-22 10:30:47 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 27
ERROR - 2019-04-22 10:53:36 --> Severity: error --> Exception: Call to undefined method CI_Input::view() /Applications/MAMP/htdocs/CI/application/views/homepage.php 105
ERROR - 2019-04-22 10:53:41 --> Severity: error --> Exception: Call to undefined method CI_Input::view() /Applications/MAMP/htdocs/CI/application/views/homepage.php 105
ERROR - 2019-04-22 10:53:53 --> Severity: error --> Exception: Call to undefined method CI_Input::view() /Applications/MAMP/htdocs/CI/application/views/homepage.php 105
ERROR - 2019-04-22 10:53:56 --> Severity: error --> Exception: Call to undefined method CI_Input::view() /Applications/MAMP/htdocs/CI/application/views/homepage.php 105
ERROR - 2019-04-22 11:11:21 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 11:14:05 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 11:14:35 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 11:14:39 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 11:14:54 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 11:14:58 --> Severity: error --> Exception: Call to undefined function uri() /Applications/MAMP/htdocs/CI/application/controllers/Book.php 34
ERROR - 2019-04-22 11:15:18 --> Severity: error --> Exception: Call to undefined function url() /Applications/MAMP/htdocs/CI/application/controllers/Book.php 34
ERROR - 2019-04-22 11:15:21 --> Severity: error --> Exception: Call to undefined function url() /Applications/MAMP/htdocs/CI/application/controllers/Book.php 34
ERROR - 2019-04-22 11:15:42 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 11:19:24 --> 404 Page Not Found: Book/dev.ci.com
ERROR - 2019-04-22 11:19:26 --> Severity: error --> Exception: Call to undefined method CI_Session::unset_data() /Applications/MAMP/htdocs/CI/application/views/homepage.php 47
ERROR - 2019-04-22 11:19:27 --> Severity: error --> Exception: Call to undefined method CI_Session::unset_data() /Applications/MAMP/htdocs/CI/application/views/homepage.php 47
ERROR - 2019-04-22 11:19:54 --> Severity: error --> Exception: Call to undefined method CI_Session::unset_flashdata() /Applications/MAMP/htdocs/CI/application/views/homepage.php 47
ERROR - 2019-04-22 11:19:56 --> Severity: error --> Exception: Call to undefined method CI_Session::unset_flashdata() /Applications/MAMP/htdocs/CI/application/views/homepage.php 47
ERROR - 2019-04-22 11:27:47 --> 404 Page Not Found: Book/index
ERROR - 2019-04-22 11:37:01 --> 404 Page Not Found: Home/info
ERROR - 2019-04-22 11:57:48 --> 404 Page Not Found: Home/reset
ERROR - 2019-04-22 11:58:51 --> 404 Page Not Found: Home/captcha
