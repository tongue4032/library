<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-23 13:33:52 --> 404 Page Not Found: Docs-assets/ico
