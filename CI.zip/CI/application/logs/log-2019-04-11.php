<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-11 03:08:17 --> 404 Page Not Found: Docs-assets/ico
