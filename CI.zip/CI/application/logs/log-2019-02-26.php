<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-26 03:59:44 --> Severity: error --> Exception: syntax error, unexpected 'true' (T_STRING), expecting ',' or ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 98
ERROR - 2019-02-26 03:59:44 --> Severity: error --> Exception: syntax error, unexpected 'true' (T_STRING), expecting ',' or ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 98
ERROR - 2019-02-26 03:59:45 --> Severity: error --> Exception: syntax error, unexpected 'true' (T_STRING), expecting ',' or ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 98
ERROR - 2019-02-26 04:00:27 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/application/models/User_model.php 45
ERROR - 2019-02-26 04:04:17 --> Severity: error --> Exception: Too few arguments to function User_model::get_user(), 2 passed in /Applications/MAMP/htdocs/CI/application/controllers/Home.php on line 40 and exactly 3 expected /Applications/MAMP/htdocs/CI/application/models/User_model.php 14
ERROR - 2019-02-26 04:06:11 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/application/models/User_model.php 44
ERROR - 2019-02-26 04:06:42 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/application/models/User_model.php 44
ERROR - 2019-02-26 04:52:00 --> 404 Page Not Found: Home/search
ERROR - 2019-02-26 07:37:12 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ';' or '{' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 109
ERROR - 2019-02-26 07:37:13 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ';' or '{' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 109
ERROR - 2019-02-26 10:03:37 --> 404 Page Not Found: Home/phone_register
