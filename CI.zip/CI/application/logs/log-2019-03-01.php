<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-01 04:01:34 --> 404 Page Not Found: Home/login
ERROR - 2019-03-01 04:06:26 --> 404 Page Not Found: Home/login
ERROR - 2019-03-01 04:06:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/libraries/Mailer.php:33) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-03-01 04:06:43 --> 404 Page Not Found: Home/login
ERROR - 2019-03-01 04:08:01 --> 404 Page Not Found: Home/login
ERROR - 2019-03-01 04:08:56 --> 404 Page Not Found: Home/login
ERROR - 2019-03-01 04:11:21 --> 404 Page Not Found: Home/login
ERROR - 2019-03-01 04:46:21 --> 404 Page Not Found: Search/index
ERROR - 2019-03-01 04:46:24 --> 404 Page Not Found: Search/index
ERROR - 2019-03-01 07:52:08 --> 404 Page Not Found: Home/query
