<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-13 11:33:31 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-13 11:33:34 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-13 11:34:33 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-13 11:37:42 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-13 11:38:03 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-13 12:01:04 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-13 12:11:11 --> 404 Page Not Found: Home/home
ERROR - 2019-03-13 12:11:30 --> 404 Page Not Found: Home/home
ERROR - 2019-03-13 12:12:21 --> 404 Page Not Found: Do_username_login/index
ERROR - 2019-03-13 12:12:41 --> 404 Page Not Found: Do_username_login/index
ERROR - 2019-03-13 12:12:57 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-13 12:15:50 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 59
ERROR - 2019-03-13 12:15:53 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 59
ERROR - 2019-03-13 12:15:57 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 59
ERROR - 2019-03-13 12:16:03 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 59
ERROR - 2019-03-13 12:16:41 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-13 12:20:20 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 153
ERROR - 2019-03-13 12:20:21 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 153
ERROR - 2019-03-13 12:20:46 --> 404 Page Not Found: Index/index
ERROR - 2019-03-13 12:21:32 --> 404 Page Not Found: Index/index
ERROR - 2019-03-13 12:22:16 --> 404 Page Not Found: Home/home
ERROR - 2019-03-13 12:23:29 --> 404 Page Not Found: Do_email_login/index
ERROR - 2019-03-13 12:23:46 --> 404 Page Not Found: Do_email_login/index
ERROR - 2019-03-13 12:51:58 --> 404 Page Not Found: %E3%80%91/index
ERROR - 2019-03-13 13:03:10 --> Severity: Notice --> Undefined variable: emai_lbody /Applications/MAMP/htdocs/CI/application/models/User_model.php 54
ERROR - 2019-03-13 13:05:40 --> 404 Page Not Found: CI/Home
ERROR - 2019-03-13 13:07:42 --> 404 Page Not Found: Home/Home
ERROR - 2019-03-13 13:09:12 --> 404 Page Not Found: Home/Home
ERROR - 2019-03-13 13:10:17 --> 404 Page Not Found: Home/Home
ERROR - 2019-03-13 13:10:42 --> 404 Page Not Found: Home/Home
ERROR - 2019-03-13 13:11:42 --> 404 Page Not Found: Username_login/index
