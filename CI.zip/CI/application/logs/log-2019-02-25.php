<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-25 09:53:35 --> Severity: Notice --> Undefined variable: mail /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-25 10:01:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = 'Tony1411--', 1 = '2046817306@me.com'
WHERE `lib_user` = 'Tony1411--'' at line 1 - Invalid query: UPDATE `lib_user` SET 0 = 'Tony1411--', 1 = '2046817306@me.com'
WHERE `lib_user` = 'Tony1411--'
ERROR - 2019-02-25 10:50:30 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:31 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:31 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:32 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:32 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:32 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:32 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:32 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:32 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:33 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:33 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:33 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:33 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:33 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:34 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:34 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:34 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:34 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:35 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:35 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:35 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:35 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:35 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:36 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:36 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:36 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:36 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:36 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:37 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:37 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:37 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:38 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:38 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:38 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:51:39 --> Severity: error --> Exception: syntax error, unexpected '[', expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 79
ERROR - 2019-02-25 10:55:27 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:55:57 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:55:58 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:55:59 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:55:59 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:55:59 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:55:59 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:55:59 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:56:00 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:57:16 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:57:17 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:57:17 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:57:17 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:57:17 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:57:17 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:57:18 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:57:18 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:57:18 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:57:18 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:57:18 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:57:18 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 10:57:19 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 11:01:44 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 11:04:35 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 11:04:36 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 11:04:37 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 11:04:37 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 11:04:37 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 11:07:20 --> Severity: Notice --> Undefined variable: _session /Applications/MAMP/htdocs/CI/application/controllers/Home.php 80
ERROR - 2019-02-25 11:07:20 --> Severity: Notice --> Undefined variable: _session /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 11:10:15 --> Severity: Notice --> Undefined variable: _session /Applications/MAMP/htdocs/CI/application/controllers/Home.php 80
ERROR - 2019-02-25 11:11:19 --> Severity: Notice --> Undefined variable: _session /Applications/MAMP/htdocs/CI/application/controllers/Home.php 80
ERROR - 2019-02-25 11:11:46 --> Severity: Notice --> Undefined variable: _session /Applications/MAMP/htdocs/CI/application/controllers/Home.php 80
ERROR - 2019-02-25 11:12:16 --> Severity: Notice --> Undefined variable: _session /Applications/MAMP/htdocs/CI/application/controllers/Home.php 80
ERROR - 2019-02-25 11:14:33 --> Severity: Notice --> Undefined variable: _session /Applications/MAMP/htdocs/CI/application/controllers/Home.php 80
ERROR - 2019-02-25 11:14:33 --> Severity: Notice --> Undefined variable: _session /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 11:28:01 --> Severity: Notice --> Undefined variable: password /Applications/MAMP/htdocs/CI/application/models/User_model.php 44
ERROR - 2019-02-25 11:34:57 --> Severity: Notice --> Undefined index: token /Applications/MAMP/htdocs/CI/application/controllers/Home.php 80
ERROR - 2019-02-25 11:40:49 --> Severity: Notice --> Undefined index: token /Applications/MAMP/htdocs/CI/application/controllers/Home.php 80
ERROR - 2019-02-25 11:40:49 --> Severity: Notice --> Undefined index: token /Applications/MAMP/htdocs/CI/application/controllers/Home.php 80
ERROR - 2019-02-25 11:40:50 --> Severity: Notice --> Undefined index: token /Applications/MAMP/htdocs/CI/application/controllers/Home.php 80
ERROR - 2019-02-25 12:37:03 --> Severity: Notice --> Undefined variable: _session /Applications/MAMP/htdocs/CI/application/controllers/Home.php 80
ERROR - 2019-02-25 12:37:03 --> Severity: Notice --> Undefined variable: _session /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 12:37:24 --> Severity: Notice --> Undefined variable: _session /Applications/MAMP/htdocs/CI/application/controllers/Home.php 80
ERROR - 2019-02-25 12:37:24 --> Severity: Notice --> Undefined variable: _session /Applications/MAMP/htdocs/CI/application/controllers/Home.php 88
ERROR - 2019-02-25 13:11:25 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 90
ERROR - 2019-02-25 13:12:39 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 90
