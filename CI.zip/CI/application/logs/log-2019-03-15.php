<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-15 02:57:41 --> Severity: error --> Exception: syntax error, unexpected ''back_time'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 249
ERROR - 2019-03-15 03:34:01 --> 404 Page Not Found: Docs-assets/ico
