<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-27 07:59:54 --> Severity: error --> Exception: Call to undefined function show_msg() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 230
ERROR - 2019-03-27 08:00:21 --> Severity: error --> Exception: Call to undefined function show_msg() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 230
ERROR - 2019-03-27 11:34:05 --> 404 Page Not Found: Home/modify
ERROR - 2019-03-27 11:34:48 --> 404 Page Not Found: Css/style10.css
ERROR - 2019-03-27 11:34:58 --> 404 Page Not Found: Css/style1.css
ERROR - 2019-03-27 11:35:42 --> 404 Page Not Found: Css/style10.css
ERROR - 2019-03-27 11:49:35 --> 404 Page Not Found: Home/modify
ERROR - 2019-03-27 11:51:09 --> Severity: Notice --> Undefined index: email /Applications/MAMP/htdocs/CI/application/views/user_info.php 52
ERROR - 2019-03-27 12:28:06 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 12:28:06 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 62
ERROR - 2019-03-27 12:28:06 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 68
ERROR - 2019-03-27 12:29:58 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 12:29:58 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 62
ERROR - 2019-03-27 12:29:58 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 68
ERROR - 2019-03-27 12:30:02 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 12:30:02 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 62
ERROR - 2019-03-27 12:30:02 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 68
ERROR - 2019-03-27 12:30:08 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 12:30:08 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 62
ERROR - 2019-03-27 12:30:08 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 68
ERROR - 2019-03-27 12:30:19 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 12:30:19 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 62
ERROR - 2019-03-27 12:30:19 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 68
ERROR - 2019-03-27 12:34:05 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 12:34:05 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 62
ERROR - 2019-03-27 12:34:05 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 68
ERROR - 2019-03-27 15:38:21 --> 404 Page Not Found: Docs-assets/ico
ERROR - 2019-03-27 15:43:28 --> Severity: Notice --> Undefined variable: username /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 15:43:28 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 62
ERROR - 2019-03-27 15:43:28 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 68
ERROR - 2019-03-27 15:45:09 --> Severity: Notice --> Undefined variable: admin_id /Applications/MAMP/htdocs/CI/application/controllers/Home.php 62
ERROR - 2019-03-27 15:45:09 --> Severity: Notice --> Undefined variable: username /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 15:45:09 --> Severity: Notice --> Undefined variable: password /Applications/MAMP/htdocs/CI/application/views/modify.php 39
ERROR - 2019-03-27 15:45:09 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 62
ERROR - 2019-03-27 15:45:09 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 68
ERROR - 2019-03-27 15:46:11 --> Severity: Notice --> Undefined variable: admin_id /Applications/MAMP/htdocs/CI/application/controllers/Home.php 62
ERROR - 2019-03-27 15:46:11 --> Severity: Notice --> Undefined variable: username /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 15:46:11 --> Severity: Notice --> Undefined variable: password /Applications/MAMP/htdocs/CI/application/views/modify.php 39
ERROR - 2019-03-27 15:46:11 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 62
ERROR - 2019-03-27 15:46:11 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 68
ERROR - 2019-03-27 16:07:30 --> Severity: Notice --> Undefined variable: admin_id /Applications/MAMP/htdocs/CI/application/controllers/Home.php 62
ERROR - 2019-03-27 16:07:30 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 16:07:30 --> Severity: Notice --> Undefined variable: username /Applications/MAMP/htdocs/CI/application/views/modify.php 39
ERROR - 2019-03-27 16:07:30 --> Severity: Notice --> Undefined variable: password /Applications/MAMP/htdocs/CI/application/views/modify.php 45
ERROR - 2019-03-27 16:07:30 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 68
ERROR - 2019-03-27 16:07:30 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 74
ERROR - 2019-03-27 16:17:33 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 16:17:33 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 68
ERROR - 2019-03-27 16:17:33 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 74
ERROR - 2019-03-27 16:21:24 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 68
ERROR - 2019-03-27 16:21:24 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/CI/application/views/modify.php 74
ERROR - 2019-03-27 16:35:25 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/CI/application/controllers/Home.php 56
ERROR - 2019-03-27 16:35:25 --> Severity: Notice --> Undefined variable: user_id /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 16:35:36 --> Severity: Notice --> Undefined variable: user_id /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 16:35:49 --> Severity: Notice --> Undefined variable: user_id /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 16:35:56 --> Severity: Notice --> Undefined variable: user_id /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 16:36:48 --> Severity: Notice --> Undefined variable: user_id /Applications/MAMP/htdocs/CI/application/views/modify.php 33
ERROR - 2019-03-27 16:51:46 --> Severity: Notice --> Undefined property: home::$admin_model /Applications/MAMP/htdocs/CI/application/controllers/Home.php 291
ERROR - 2019-03-27 16:51:46 --> Severity: error --> Exception: Call to a member function modify() on null /Applications/MAMP/htdocs/CI/application/controllers/Home.php 291
ERROR - 2019-03-27 16:51:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-27 16:52:01 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 16:53:19 --> Severity: Notice --> Undefined index: email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 16:54:15 --> Severity: Notice --> Undefined index: email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 16:55:20 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 16:56:51 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 16:58:59 --> Severity: Notice --> Undefined index: mail /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 16:59:32 --> Severity: Notice --> Undefined index: mail /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 16:59:57 --> Severity: Notice --> Undefined index: email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:00:03 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:00:05 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:00:05 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:00:05 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:00:17 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:00:32 --> Severity: Notice --> Undefined variable: email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:00:46 --> Severity: Notice --> Undefined variable: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:00:58 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:01:49 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:01:50 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:01:50 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:02:00 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:02:28 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:03:03 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:03:27 --> Severity: Notice --> Undefined index: email /Applications/MAMP/htdocs/CI/application/models/User_model.php 91
ERROR - 2019-03-27 17:04:14 --> Severity: error --> Exception: syntax error, unexpected '}' /Applications/MAMP/htdocs/CI/application/models/User_model.php 98
ERROR - 2019-03-27 17:04:23 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 87
ERROR - 2019-03-27 17:04:44 --> Severity: Notice --> Undefined variable: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 87
ERROR - 2019-03-27 17:05:20 --> Severity: Notice --> Undefined variable: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 87
ERROR - 2019-03-27 17:05:42 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 87
ERROR - 2019-03-27 17:05:52 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 87
ERROR - 2019-03-27 17:06:26 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 93
ERROR - 2019-03-27 17:06:27 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 93
ERROR - 2019-03-27 17:06:28 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 93
ERROR - 2019-03-27 17:06:29 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 93
ERROR - 2019-03-27 17:06:29 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 93
ERROR - 2019-03-27 17:06:30 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/CI/application/models/User_model.php 93
ERROR - 2019-03-27 17:09:20 --> Severity: Notice --> Undefined index: email /Applications/MAMP/htdocs/CI/application/models/User_model.php 93
ERROR - 2019-03-27 17:20:41 --> Severity: Notice --> Undefined index: email /Applications/MAMP/htdocs/CI/application/models/User_model.php 93
