<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-07 03:53:28 --> 404 Page Not Found: Form/index
ERROR - 2019-03-07 04:30:44 --> 404 Page Not Found: Home/borrowinfo
ERROR - 2019-03-07 04:30:55 --> 404 Page Not Found: Home/borrowinfo
ERROR - 2019-03-07 04:34:33 --> 404 Page Not Found: Home/info
ERROR - 2019-03-07 04:45:02 --> Severity: error --> Exception: Call to undefined method User_model::borrow() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 209
ERROR - 2019-03-07 04:45:19 --> Severity: error --> Exception: Call to undefined method User_model::borrow() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 209
ERROR - 2019-03-07 04:49:53 --> Severity: Notice --> Undefined variable: sql /Applications/MAMP/htdocs/CI/application/controllers/Home.php 208
ERROR - 2019-03-07 04:49:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 04:50:32 --> Severity: Notice --> Undefined variable: sql /Applications/MAMP/htdocs/CI/application/controllers/Home.php 208
ERROR - 2019-03-07 04:50:32 --> Severity: Notice --> Undefined variable: sql /Applications/MAMP/htdocs/CI/application/models/User_model.php 71
ERROR - 2019-03-07 04:50:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 04:50:42 --> Severity: Notice --> Undefined variable: sql /Applications/MAMP/htdocs/CI/application/models/User_model.php 71
ERROR - 2019-03-07 04:50:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 05:30:18 --> Severity: Notice --> Undefined variable: sql /Applications/MAMP/htdocs/CI/application/models/User_model.php 71
ERROR - 2019-03-07 05:30:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 06:26:47 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `lib_book_action` (`user_id`, `username`, `password`, `role_id`, `telephone`, `professional`, `Email`, `is_delete`, `books_in_borrow`, `last_login_time`) VALUES ('2', 'Tony', '12344321', '0', '12345678901', NULL, 'tongue4032@163.com', '0', '0', '2019-03-01 10:59:41')
ERROR - 2019-03-07 06:32:20 --> Severity: Notice --> Undefined index: uid /Applications/MAMP/htdocs/CI/application/models/User_model.php 71
ERROR - 2019-03-07 06:32:21 --> 404 Page Not Found: Home/borrow_query
ERROR - 2019-03-07 06:33:44 --> 404 Page Not Found: Home/borrow_query
ERROR - 2019-03-07 06:34:40 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`library`.`lib_book_action`, CONSTRAINT `barcode` FOREIGN KEY (`barcode`) REFERENCES `lib_bookinfo` (`barcode`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: insert lib_book_action set user_id=''
ERROR - 2019-03-07 06:35:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'user_id=''' at line 1 - Invalid query: insert lib_book_action user_id=''
ERROR - 2019-03-07 06:37:43 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/application/models/User_model.php 71
ERROR - 2019-03-07 06:37:54 --> 404 Page Not Found: Home/inf
ERROR - 2019-03-07 06:38:01 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/application/models/User_model.php 71
ERROR - 2019-03-07 06:38:28 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/application/models/User_model.php 71
ERROR - 2019-03-07 06:42:25 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/application/models/User_model.php 71
ERROR - 2019-03-07 06:46:40 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/application/models/User_model.php 71
ERROR - 2019-03-07 06:49:12 --> Query error: Unknown column 'username' in 'field list' - Invalid query: INSERT INTO `lib_book_action` (`user_id`, `username`, `password`, `role_id`, `telephone`, `professional`, `Email`, `is_delete`, `books_in_borrow`, `last_login_time`) VALUES ('1', 'user', '123321', '0', '13129207435', NULL, '2046817306@qq.com', '0', '0', '2019-02-28 15:35:00')
ERROR - 2019-03-07 06:59:55 --> 404 Page Not Found: Hom/index
ERROR - 2019-03-07 07:00:09 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/database/DB_driver.php 1477
ERROR - 2019-03-07 07:00:09 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `lib_book_action` (`user_id`) VALUES (Array)
ERROR - 2019-03-07 07:00:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 07:02:00 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/database/DB_driver.php 1477
ERROR - 2019-03-07 07:02:00 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `lib_book_action` (`user_id`) VALUES (Array)
ERROR - 2019-03-07 07:02:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 07:02:39 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/database/DB_driver.php 1477
ERROR - 2019-03-07 07:02:39 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `lib_book_action` (`user`) VALUES (Array)
ERROR - 2019-03-07 07:02:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 07:02:45 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/database/DB_driver.php 1477
ERROR - 2019-03-07 07:02:45 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `lib_book_action` (`user`) VALUES (Array)
ERROR - 2019-03-07 07:02:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 07:14:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '101) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_book_action` (101) VALUES ('')
ERROR - 2019-03-07 07:16:50 --> Severity: error --> Exception: syntax error, unexpected '$barcode' (T_VARIABLE) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 212
ERROR - 2019-03-07 07:16:55 --> Severity: error --> Exception: syntax error, unexpected '$barcode' (T_VARIABLE) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 212
ERROR - 2019-03-07 07:17:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '101) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_book_action` (101) VALUES ('')
ERROR - 2019-03-07 07:17:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:207) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 07:18:43 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' /Applications/MAMP/htdocs/CI/application/models/User_model.php 71
ERROR - 2019-03-07 07:19:23 --> 404 Page Not Found: Home/info
ERROR - 2019-03-07 07:21:31 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' /Applications/MAMP/htdocs/CI/application/models/User_model.php 72
ERROR - 2019-03-07 07:21:56 --> 404 Page Not Found: Home/info
ERROR - 2019-03-07 07:32:18 --> 404 Page Not Found: Home/info
ERROR - 2019-03-07 07:32:37 --> 404 Page Not Found: Home/info
ERROR - 2019-03-07 07:37:07 --> 404 Page Not Found: Home/info
ERROR - 2019-03-07 07:37:45 --> 404 Page Not Found: Home/info
ERROR - 2019-03-07 07:43:01 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-03-07 07:43:01 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-03-07 07:43:54 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-03-07 07:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-03-07 07:44:22 --> 404 Page Not Found: Home/homepage
ERROR - 2019-03-07 07:48:18 --> 404 Page Not Found: Home/home
ERROR - 2019-03-07 08:25:48 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/info.php 35
ERROR - 2019-03-07 08:25:48 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/info.php 35
ERROR - 2019-03-07 08:27:12 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/info.php 35
ERROR - 2019-03-07 08:27:12 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/info.php 35
ERROR - 2019-03-07 08:33:05 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/CI/application/views/info.php 36
ERROR - 2019-03-07 08:33:05 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/CI/application/views/info.php 37
ERROR - 2019-03-07 08:33:05 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/CI/application/views/info.php 38
ERROR - 2019-03-07 08:33:05 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/CI/application/views/info.php 39
ERROR - 2019-03-07 08:45:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:227) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 08:45:35 --> Severity: Compile Error --> Cannot redeclare Home::info() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 227
ERROR - 2019-03-07 08:45:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:227) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 08:45:56 --> Severity: Compile Error --> Cannot redeclare Home::info() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 227
ERROR - 2019-03-07 08:46:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:227) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 08:46:05 --> Severity: Compile Error --> Cannot redeclare Home::info() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 227
ERROR - 2019-03-07 08:46:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:227) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 08:46:07 --> Severity: Compile Error --> Cannot redeclare Home::info() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 227
ERROR - 2019-03-07 08:46:57 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/info.php 35
ERROR - 2019-03-07 08:46:57 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/info.php 35
ERROR - 2019-03-07 08:47:52 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/info.php 38
ERROR - 2019-03-07 08:47:52 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/info.php 39
ERROR - 2019-03-07 08:47:52 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/info.php 40
ERROR - 2019-03-07 08:47:52 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/info.php 38
ERROR - 2019-03-07 08:47:52 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/info.php 39
ERROR - 2019-03-07 08:47:52 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/info.php 40
ERROR - 2019-03-07 08:48:21 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/info.php 40
ERROR - 2019-03-07 08:48:21 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/info.php 40
ERROR - 2019-03-07 08:50:31 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/info.php 38
ERROR - 2019-03-07 08:50:31 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/info.php 38
ERROR - 2019-03-07 09:00:11 --> 404 Page Not Found: Home/1
ERROR - 2019-03-07 09:00:21 --> 404 Page Not Found: Home/1
ERROR - 2019-03-07 09:00:53 --> 404 Page Not Found: Home/1
ERROR - 2019-03-07 09:52:36 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/CI/system/database/DB_query_builder.php 2442
ERROR - 2019-03-07 09:52:36 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `lib_book_action`
WHERE `barcode` = Array
ERROR - 2019-03-07 09:52:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-03-07 09:59:19 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/info.php 41
ERROR - 2019-03-07 09:59:19 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/info.php 41
ERROR - 2019-03-07 10:01:54 --> Query error: Unknown column 'author' in 'field list' - Invalid query: INSERT INTO `lib_book_action` (`barcode`, `bookname`, `author`, `username`, `borrow_time`) VALUES ('101', '流浪地球', '朔方', 'user', '2019-03-07')
ERROR - 2019-03-07 10:06:57 --> 404 Page Not Found: Give_back/index
ERROR - 2019-03-07 10:21:02 --> 404 Page Not Found: Give_back/index
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:21:29 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/CI/application/views/info.php 44
ERROR - 2019-03-07 10:27:29 --> Severity: Notice --> Undefined variable: time /Applications/MAMP/htdocs/CI/application/controllers/Home.php 244
ERROR - 2019-03-07 10:29:57 --> Severity: Notice --> Undefined variable: time /Applications/MAMP/htdocs/CI/application/controllers/Home.php 244
ERROR - 2019-03-07 10:30:03 --> Severity: Notice --> Undefined variable: time /Applications/MAMP/htdocs/CI/application/controllers/Home.php 244
ERROR - 2019-03-07 10:30:09 --> Severity: Notice --> Undefined variable: time /Applications/MAMP/htdocs/CI/application/controllers/Home.php 244
