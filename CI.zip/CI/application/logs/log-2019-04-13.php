<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-13 15:12:28 --> 404 Page Not Found: Docs-assets/ico
