<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-05 02:46:27 --> 404 Page Not Found: 2/index
ERROR - 2019-03-05 02:46:32 --> 404 Page Not Found: 2/index
ERROR - 2019-03-05 02:47:25 --> 404 Page Not Found: Test/index
ERROR - 2019-03-05 02:57:26 --> 404 Page Not Found: Home/return
ERROR - 2019-03-05 03:33:16 --> 404 Page Not Found: Home/borrowinfo
ERROR - 2019-03-05 03:52:06 --> 404 Page Not Found: Home/login
ERROR - 2019-03-05 03:52:16 --> 404 Page Not Found: Home/login
ERROR - 2019-03-05 03:52:19 --> 404 Page Not Found: Home/login
ERROR - 2019-03-05 03:52:30 --> 404 Page Not Found: Login/index
ERROR - 2019-03-05 03:52:53 --> 404 Page Not Found: Home/login
ERROR - 2019-03-05 10:56:05 --> 404 Page Not Found: Home/homepage
ERROR - 2019-03-05 10:56:15 --> 404 Page Not Found: Home/homepage
ERROR - 2019-03-05 10:56:27 --> 404 Page Not Found: Home/home
ERROR - 2019-03-05 10:56:40 --> 404 Page Not Found: Home/home
