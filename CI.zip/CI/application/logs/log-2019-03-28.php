<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-28 02:06:25 --> Severity: Notice --> Undefined index: email /Applications/MAMP/htdocs/CI/application/models/User_model.php 93
ERROR - 2019-03-28 02:08:37 --> Severity: error --> Exception: Too few arguments to function User_model::modify(), 2 passed in /Applications/MAMP/htdocs/CI/application/controllers/Home.php on line 293 and exactly 3 expected /Applications/MAMP/htdocs/CI/application/models/User_model.php 86
ERROR - 2019-03-28 02:11:37 --> Severity: Notice --> Undefined variable: password /Applications/MAMP/htdocs/CI/application/models/User_model.php 25
ERROR - 2019-03-28 02:11:48 --> Severity: Notice --> Undefined variable: password /Applications/MAMP/htdocs/CI/application/models/User_model.php 25
ERROR - 2019-03-28 02:12:02 --> Severity: Notice --> Undefined variable: password /Applications/MAMP/htdocs/CI/application/models/User_model.php 25
ERROR - 2019-03-28 08:16:50 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 210
