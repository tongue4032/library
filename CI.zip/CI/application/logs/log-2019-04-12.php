<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-12 14:40:12 --> 404 Page Not Found: Docs-assets/ico
