<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-01 03:36:21 --> 404 Page Not Found: Docs-assets/ico
