<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-18 05:06:47 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /Applications/MAMP/htdocs/CI/application/controllers/Home.php 226
ERROR - 2019-04-18 05:07:39 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /Applications/MAMP/htdocs/CI/application/controllers/Home.php 226
ERROR - 2019-04-18 05:08:08 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /Applications/MAMP/htdocs/CI/application/controllers/Home.php 226
ERROR - 2019-04-18 05:08:16 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /Applications/MAMP/htdocs/CI/application/controllers/Home.php 226
ERROR - 2019-04-18 05:12:48 --> 404 Page Not Found: Search/index
