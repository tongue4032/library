<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-11 03:38:50 --> 404 Page Not Found: Home/login
ERROR - 2019-03-11 03:39:20 --> 404 Page Not Found: Home/login
ERROR - 2019-03-11 04:04:12 --> 404 Page Not Found: Admin/index.phpAdminhome
ERROR - 2019-03-11 04:04:17 --> 404 Page Not Found: Admin/Adminhome
ERROR - 2019-03-11 04:04:21 --> 404 Page Not Found: Admin/index
ERROR - 2019-03-11 04:45:00 --> 404 Page Not Found: Admin/index
ERROR - 2019-03-11 04:45:02 --> 404 Page Not Found: Admin/index
ERROR - 2019-03-11 04:45:46 --> 404 Page Not Found: Admin/index
ERROR - 2019-03-11 05:01:15 --> 404 Page Not Found: Admin/index
ERROR - 2019-03-11 05:51:54 --> 404 Page Not Found: Admin/index
ERROR - 2019-03-11 05:52:15 --> 404 Page Not Found: Admin/index
ERROR - 2019-03-11 05:52:18 --> 404 Page Not Found: Admin/index
ERROR - 2019-03-11 07:09:05 --> 404 Page Not Found: Admin/index
ERROR - 2019-03-11 07:18:01 --> 404 Page Not Found: Admin/index
ERROR - 2019-03-11 09:23:58 --> 404 Page Not Found: AD/index
ERROR - 2019-03-11 09:24:53 --> 404 Page Not Found: AD/index
ERROR - 2019-03-11 09:25:09 --> 404 Page Not Found: AD/index
ERROR - 2019-03-11 11:36:03 --> 404 Page Not Found: AD/index
ERROR - 2019-03-11 12:07:33 --> 404 Page Not Found: AD/index
ERROR - 2019-03-11 13:44:22 --> 404 Page Not Found: /index
ERROR - 2019-03-11 14:13:28 --> Severity: error --> Exception: syntax error, unexpected 'funtion' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) /Applications/MAMP/htdocs/CI/application/controllers/Welcome.php 14
ERROR - 2019-03-11 14:13:53 --> 404 Page Not Found: Welcome/index
ERROR - 2019-03-11 14:13:57 --> 404 Page Not Found: Welcome/index
ERROR - 2019-03-11 14:14:34 --> Severity: error --> Exception: syntax error, unexpected 'funtion' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 14
ERROR - 2019-03-11 14:14:50 --> Severity: error --> Exception: syntax error, unexpected 'funtion' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 14
ERROR - 2019-03-11 14:16:35 --> 404 Page Not Found: Welcome/index
ERROR - 2019-03-11 14:16:51 --> 404 Page Not Found: Welcome/index
ERROR - 2019-03-11 14:16:53 --> 404 Page Not Found: Welcome/index
ERROR - 2019-03-11 14:17:24 --> 404 Page Not Found: Welcome/index
ERROR - 2019-03-11 14:17:47 --> 404 Page Not Found: Welcome/index
ERROR - 2019-03-11 14:18:18 --> 404 Page Not Found: Welcome/index
ERROR - 2019-03-11 14:18:21 --> 404 Page Not Found: Welcome/index
ERROR - 2019-03-11 14:32:38 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:32:38 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:32:38 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:33:10 --> 404 Page Not Found: Home/css
ERROR - 2019-03-11 14:33:10 --> 404 Page Not Found: Home/css
ERROR - 2019-03-11 14:33:10 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:33:27 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:35:00 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:35:38 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:35:56 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:36:30 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:39:51 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:40:14 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:48:22 --> Severity: Notice --> Use of undefined constant Math - assumed 'Math' /Applications/MAMP/htdocs/CI/application/views/phone_register.php 64
ERROR - 2019-03-11 14:48:22 --> Severity: error --> Exception: Call to undefined function random() /Applications/MAMP/htdocs/CI/application/views/phone_register.php 64
ERROR - 2019-03-11 14:49:17 --> Severity: Notice --> Use of undefined constant Math - assumed 'Math' /Applications/MAMP/htdocs/CI/application/views/phone_register.php 64
ERROR - 2019-03-11 14:49:17 --> Severity: error --> Exception: Call to undefined function random() /Applications/MAMP/htdocs/CI/application/views/phone_register.php 64
ERROR - 2019-03-11 14:53:25 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:53:26 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:53:26 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:53:49 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:54:32 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:56:19 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:57:21 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:58:20 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:58:36 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:58:48 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:59:13 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:59:16 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:59:26 --> 404 Page Not Found: Home/dev.ci.com
ERROR - 2019-03-11 14:59:55 --> 404 Page Not Found: Home/Home
ERROR - 2019-03-11 15:12:58 --> 404 Page Not Found: Devcicom/Home
ERROR - 2019-03-11 15:13:53 --> 404 Page Not Found: Devcicom/Home
ERROR - 2019-03-11 15:13:59 --> 404 Page Not Found: Devcicom/Home
ERROR - 2019-03-11 15:14:36 --> 404 Page Not Found: Devcicom/Home
ERROR - 2019-03-11 15:14:40 --> 404 Page Not Found: Devcicom/Home
ERROR - 2019-03-11 15:15:29 --> 404 Page Not Found: Devcicom/Home
ERROR - 2019-03-11 15:16:14 --> 404 Page Not Found: Devcicom/Home
