<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-31 03:29:27 --> 404 Page Not Found: Docs-assets/ico
