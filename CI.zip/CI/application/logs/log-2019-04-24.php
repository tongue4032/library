<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-24 04:44:59 --> 404 Page Not Found: Book/index
ERROR - 2019-04-24 09:54:50 --> Query error: Table 'library.lib_book_action' doesn't exist - Invalid query: SELECT *
FROM `lib_book_action`
WHERE `user_id` = '1'
ERROR - 2019-04-24 10:10:26 --> Severity: Notice --> Use of undefined constant TBL_BOOK_ACTION - assumed 'TBL_BOOK_ACTION' /Applications/MAMP/htdocs/CI/application/models/Book_model.php 37
ERROR - 2019-04-24 10:10:26 --> Query error: Table 'library.tbl_book_action' doesn't exist - Invalid query: SELECT *
FROM `TBL_BOOK_ACTION`
WHERE `user_id` = '1'
ERROR - 2019-04-24 10:10:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-04-24 10:39:27 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 27
ERROR - 2019-04-24 10:39:27 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 27
ERROR - 2019-04-24 10:40:41 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 30
ERROR - 2019-04-24 10:40:41 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 31
ERROR - 2019-04-24 10:40:41 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 32
ERROR - 2019-04-24 10:40:41 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 33
ERROR - 2019-04-24 10:40:41 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 33
ERROR - 2019-04-24 10:40:41 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 33
ERROR - 2019-04-24 10:40:41 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 30
ERROR - 2019-04-24 10:40:41 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 31
ERROR - 2019-04-24 10:40:41 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 32
ERROR - 2019-04-24 10:40:41 --> Severity: Warning --> Illegal string offset 'barcode' /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 33
ERROR - 2019-04-24 10:40:41 --> Severity: Warning --> Illegal string offset 'bookname' /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 33
ERROR - 2019-04-24 10:40:41 --> Severity: Warning --> Illegal string offset 'author' /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 33
ERROR - 2019-04-24 10:40:41 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 30
ERROR - 2019-04-24 10:40:41 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 31
ERROR - 2019-04-24 10:40:41 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 32
ERROR - 2019-04-24 10:40:41 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 33
ERROR - 2019-04-24 10:40:41 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 33
ERROR - 2019-04-24 10:40:41 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 33
ERROR - 2019-04-24 10:43:50 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 27
ERROR - 2019-04-24 10:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 27
ERROR - 2019-04-24 10:44:19 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 27
ERROR - 2019-04-24 10:44:19 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 27
ERROR - 2019-04-24 10:44:30 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 27
ERROR - 2019-04-24 10:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 27
ERROR - 2019-04-24 10:47:06 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 27
ERROR - 2019-04-24 10:47:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/Book_views/query.php 27
ERROR - 2019-04-24 15:20:51 --> 404 Page Not Found: Images/b.jpg
ERROR - 2019-04-24 15:20:51 --> 404 Page Not Found: Images/.jpg
ERROR - 2019-04-24 15:20:51 --> 404 Page Not Found: Images/e.jpg
ERROR - 2019-04-24 15:20:52 --> 404 Page Not Found: Images/er.jpg
ERROR - 2019-04-24 15:20:52 --> 404 Page Not Found: Images/err.jpg
ERROR - 2019-04-24 15:20:52 --> 404 Page Not Found: Images/erro.jpg
ERROR - 2019-04-24 15:55:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:55:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:55:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:55:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:55:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:55:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:55:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:55:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:55:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:55:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:55:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:55:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:55:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:56:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:56:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '13) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (13) VALUES ('')
ERROR - 2019-04-24 15:57:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:58:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:58:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (0) VALUES ('')
ERROR - 2019-04-24 15:58:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (0) VALUES ('')
ERROR - 2019-04-24 15:58:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (1) VALUES ('')
ERROR - 2019-04-24 15:58:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0) VALUES ('')' at line 1 - Invalid query: INSERT INTO `lib_borrow` (0) VALUES ('')
ERROR - 2019-04-24 16:37:01 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/CI/application/controllers/Book.php 52
ERROR - 2019-04-24 16:37:05 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/CI/application/controllers/Book.php 52
ERROR - 2019-04-24 16:38:00 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/controllers/Book.php 52
ERROR - 2019-04-24 17:06:17 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-24 17:06:56 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-24 17:08:11 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/controllers/Book.php 54
ERROR - 2019-04-24 17:09:02 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-24 17:09:02 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/controllers/Book.php 54
ERROR - 2019-04-24 17:09:24 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-24 17:34:29 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-24 17:56:41 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-24 17:57:04 --> Severity: Notice --> Undefined index: press /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-24 17:59:30 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-24 19:45:28 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/controllers/Book.php 50
ERROR - 2019-04-24 19:53:24 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/models/Book_model.php 39
ERROR - 2019-04-24 19:53:24 --> Query error: Unknown column 'time' in 'field list' - Invalid query: INSERT INTO `lib_borrow` (`username`, `time`, `bookname`) VALUES ('user', '2019-04-24', NULL)
ERROR - 2019-04-24 19:53:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
