<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-26 09:14:28 --> Severity: error --> Exception: syntax error, unexpected ')' /Applications/MAMP/htdocs/CI/application/controllers/Home.php 55
ERROR - 2019-03-26 09:27:24 --> Severity: Notice --> Undefined index: token /Applications/MAMP/htdocs/CI/application/controllers/Home.php 173
ERROR - 2019-03-26 09:27:24 --> Severity: Notice --> Undefined index: token /Applications/MAMP/htdocs/CI/application/controllers/Home.php 182
