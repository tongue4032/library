<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-23 05:23:33 --> Severity: error --> Exception: Undefined class constant 'TBL_BOOKINFO' /Applications/MAMP/htdocs/CI/application/models/Book_model.php 17
ERROR - 2019-04-23 05:30:36 --> Severity: error --> Exception: Undefined class constant 'TBL_BOOK_ACTION' /Applications/MAMP/htdocs/CI/application/models/Book_model.php 28
ERROR - 2019-04-23 09:23:14 --> Severity: error --> Exception: Too few arguments to function Secure_model::check_permission(), 0 passed in /Applications/MAMP/htdocs/CI/application/controllers/Secure.php on line 170 and exactly 1 expected /Applications/MAMP/htdocs/CI/application/models/Secure_model.php 52
ERROR - 2019-04-23 09:24:10 --> Severity: error --> Exception: Too few arguments to function Secure_model::check_permission(), 0 passed in /Applications/MAMP/htdocs/CI/application/controllers/Secure.php on line 170 and exactly 1 expected /Applications/MAMP/htdocs/CI/application/models/Secure_model.php 52
ERROR - 2019-04-23 10:53:26 --> Severity: Notice --> A session had already been started - ignoring session_start() /Applications/MAMP/htdocs/CI/system/libraries/Session/Session.php 143
ERROR - 2019-04-23 10:53:27 --> Severity: Notice --> A session had already been started - ignoring session_start() /Applications/MAMP/htdocs/CI/system/libraries/Session/Session.php 143
ERROR - 2019-04-23 10:53:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/application/libraries/Captcha.php 74
ERROR - 2019-04-23 12:18:39 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' /Applications/MAMP/htdocs/CI/application/libraries/Mailer.php 29
