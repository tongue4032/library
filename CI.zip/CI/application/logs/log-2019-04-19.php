<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-19 09:59:49 --> 404 Page Not Found: Docs-assets/ico
