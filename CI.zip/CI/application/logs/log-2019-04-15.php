<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-15 03:41:18 --> 404 Page Not Found: Docs-assets/ico
