<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-16 04:56:21 --> 404 Page Not Found: Common/js
ERROR - 2019-04-16 04:56:22 --> 404 Page Not Found: Common/js
ERROR - 2019-04-16 04:56:23 --> 404 Page Not Found: Common/js
ERROR - 2019-04-16 05:48:37 --> 404 Page Not Found: Admin/home
ERROR - 2019-04-16 12:25:21 --> 404 Page Not Found: Search/index
ERROR - 2019-04-16 12:31:49 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-04-16 12:31:49 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-04-16 12:42:21 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-04-16 12:42:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-04-16 12:43:54 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-04-16 12:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-04-16 19:24:29 --> 404 Page Not Found: Docs-assets/ico
