<?php
if (! defined('BASEPATH')) exit('No direct script access allowed');

class home extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->library('session');	
		$this->load->helper('url');
		$this->load->model('user_model');
    	$this->load->library('form_validation');

	}
	
	public function index(){
		$this->load->view('homepage');
	}

	public function captcha(){
		// $this->load->view('yanzhengma');
		$this->load->library('captcha');
  		$code = $this->captcha->getCaptcha();
  		$this->session->set_userdata('code', $code);
  		$this->captcha->showImg();
	}
	public function username_login(){
		$this->load->view('username_login');
	}	
	public function email_login(){
		$this->load->view('email_login');
	}	
	public function telephone_login(){
		$this->load->view('telephone_login');
	}	
	public function register(){
		$this->load->view('register');
	}
	public function forget(){
		$this->load->view('forget');
	}
	public function reset(){
		$data['token'] = $this->input->get('token');
		$_SESSION['token'] = $data['token'];
		$this->load->view('reset');
	}
	public function phone_register(){
		$this->load->view('phone_register');
	}
	public function query(){
		$this->load->view('query');
	}
	public function user_info(){
		$this->load->view('user_info');
	}
	public function modify(){
		$user_id = $this->input->get('user_id',Null);
		$data = array('user_id' => $user_id );
		$this->load->view('modify',$data);
	}

	//用户登录
	public function do_username_login(){
	 	$username = $this->input->post('username');
		$password = $this->input->post('password');
		$pwd = md5($password);
		$user = $this->user_model->get_user($username,$pwd);
		if($user){
		    $this->session->set_userdata('user',$user);
			echo json_encode(array('code' => 1, 'message' => 'Welcome!'));
		}else{
			echo json_encode(array('code' => 0, 'message' => 'Incorrect admin name or password!'));
		}
	}

	public function do_email_login(){
	 	$email = $this->input->post('email');
		$password = $this->input->post('password');
		$pwd = md5($password);
		$user = $this->user_model->get_email($email,$pwd);
		if($user){
			$this->session->set_userdata('user',$user);
			echo json_encode(array('code' => 1,'message' => 'Welcome!'));
		}else{
			echo json_encode(array('code' => 0, 'message' => 'Incorrect email address or password!'));
		}
	}

	public function do_telephone_login(){
	 	$telephone = $this->input->post('telephone');
		$password = $this->input->post('password');
		$pwd = md5($password);
		$user = $this->user_model->get_telephone($telephone,$pwd);
        if($user){
            $this->session->set_userdata('user',$user);
            echo json_encode(array('code' => 1,'message' => 'Welcome!'));
        }else{
            echo json_encode(array('code' => 0, 'message' => 'Incorrect mobile number or password!'));
        }
	}
	


	//用户注册
    public function do_register(){
		#设置规则
    	$this->form_validation->set_rules('username','Username');
    	$this->form_validation->set_rules('password','Password','min_length[6]|max_length[10]','alpha_dash');	
		$this->form_validation->set_rules('repassword','Confirm Password','matches[password]');
		$this->form_validation->set_value('email','Eamil','valid_email');

		if($this->form_validation->run() == false){
			#未通过
			echo validation_errors();
		}else{
			#通过
			$code = $this->input->post('captcha');
			$code2 = strtolower($this->session->userdata('code'));
			if(strtolower($code) != $code2){
				echo json_encode(array('code' => 0, 'message' => 'Verification Code Error, Please Re-enter'));
			}else{
				$data['username'] = $this->input->post('username',true);
				$data['password'] = md5($this->input->post('password',true));
				$data['email'] = $this->input->post('email',true);			
				$register = $this->user_model->add_user($data);
				if($register){
					echo json_encode(array('code' => 1, 'message' => 'Register Successful!Please Return Login!'));
				}
			}
    	}
    }



    //手机注册
	public function do_phone_register(){
		#设置规则
    	$this->form_validation->set_rules('username','Username');
    	$this->form_validation->set_rules('number','Number','numeric|exact_length(11)');
    	$this->form_validation->set_rules('password','Password','min_length[6]|max_length[10]','alpha_dash');	
		$this->form_validation->set_rules('repassword','Confirm Password','matches[password]');
		$this->form_validation->set_value('email','Eamil','valid_email');

		if($this->form_validation->run() == false){
			#未通过
			echo validation_errors();
		}else{
			#通过
			$code = $this->input->post('captcha');
			$code2 = strtolower($this->session->userdata('code'));
			if(strtolower($code) != $code2){
                echo json_encode(array('code' => 0, 'message' => 'Verification Code Error, Please Re-enter'));
			}else{
				$data['username'] = $this->input->post('username',true);
				$data['telephone'] = $this->input->post('telephone',true);
				$data['password'] = md5($this->input->post('password',true));
				$data['email'] = $this->input->post('email',true);			
				$register = $this->user_model->add_user($data);
                if($register){
                    echo json_encode(array('code' => 1, 'message' => 'Register Successful!Please Return Login!'));
                }
			}
    	}
    }


    //注销登录
    public function logout(){
    	$this->session->unset_userdata('user');
    	echo "<script>window.location='./index'</script>";
    }

    //发送邮件
    public function sendemail(){
    	$code = $this->input->post('captcha');
		$code2 = strtolower($this->session->userdata('code'));
		if(strtolower($code) != $code2){
			echo "<script>alert('Verification Code Error, Please Re-enter');window.location='./forget'</script>";
		}else{
        	$email = $this->input->post('email');
       		$this->user_model->sendemail($email);
       	}
    }


    //重置密码
    public function update(){
    	$_SESSION['token'];
    	$data = $this->input->post();
    	$this->form_validation->set_rules('password','Password','min_length[6]|max_length[10]','alpha_dash');
    	$this->form_validation->set_rules('repassword','Confirm Password','matches[password]');
    	if($this->form_validation->run() == false){
    		echo validation_errors();
    	}else{
            $code = $this->input->post('captcha');
            $code2 = strtolower($this->session->userdata('code'));
            if(strtolower($code) != $code2){
                echo json_encode(array('code' => 0, 'message' => 'Verification Code Error, Please Re-enter'));
            }else {
                $password = md5($this->input->post('password',true));
                $repassword = md5($this->input->post('repassword',true));
                $data = array(
                    'password' => $password,
                    'repassword' => $repassword
                );
                $token = $_SESSION['token'];
                $reset = $this->user_model->Update($data, $token);
                if ($reset) {
                    echo json_encode(array('code' => 1, 'message' => 'Register Successful!Please Return Login!'));
                }
            }
    	}
    }


    //搜索图书
    public function search(){
	    $type = $this->input->post('type');
    	$info = $this->input->post('info');
    	$data = array(
    	    'type' => $type,
            'info' => $info
        );
		$data['books'] = $this->user_model->search_book($data);
		if($data['books']){
		    $this->load->view('query',$data);
		}else{
		    echo json_encode(array('code' => 1, 'message' => 'Query failure!'));
        }
	}


	//借阅
	public function borrow(){
		$user = $this->session->userdata('user');
		if(empty($user)){
			echo "<script>alert('If you are not logged in, please log back in!');window.location='./username_login'</script>";
		}else{
			$username = $user['username'];
			$user_id = $user['user_id'];
			$barcode = $this->input->get('barcode',Null);
			$bookname = $this->input->get('bookname',Null);
			$author = $this->input->get('author',Null);
			$time = date('Y-m-d');
			$data = array(
				'barcode' => $barcode,
				'bookname' => $bookname,
				'author' => $author,
				'user_id' => $user_id,
				'username' => $username,
				'borrow_time' => $time
			);
			if(!empty($this->user_model->get($barcode,$user_id))){
				echo "<script>alert('This book has been borrowed, please choose again!');window.location='/Home'</script>";
//				echo json_encode(array('code' => 0, 'message' => 'This book has been borrowed, please choose again!'));
			}else{
				if($this->user_model->borrow($data)){
					echo "<script>alert('Borrowing successful!');window.location='/Home/info'</script>";
//					echo json_encode(array('code' => 1, 'message' => 'Borrowing successful!'));
				}
			}

		}
	}

	//归还
	public function give_back(){
		$barcode = $this->input->get('barcode',Null);
		$bookname = $this->input->get('bookname',Null);
		$author = $this->input->get('author',Null);
		$username = $this->input->get('username',Null);
		$borrow_time = $this->input->get('borrow_time',Null);
		$data = array(
			'barcode' => $barcode,
			'bookname' => $bookname,
			'author' => $author,
			'username' => $username,
			'borrow_time' => $borrow_time
		);
		if($this->user_model->give_back($data)){
			echo "<script>alert('Give back successful!');window.location='/Home/info'</script>";
		}else{
			echo "<script>alert('Give back failure！');window.location='/Home/info'</script>";
		}
	}


	//信息
	public function info(){
		$user = $this->session->userdata('user');
		$condition = array(
			'user_id' => $user['user_id']
		);
		$data['book'] = $this->user_model->show_info($condition);
		$this->load->view('info',$data);
	}

	public function modify_user_info(){
		$user_id = $this->input->post('user_id');
		$username = $this->input->post('username');
		$pwd = $this->input->post('password');
		$password = md5($pwd);
		$telephone = $this->input->post('telephone');
		$email = $this->input->post('email');
		// var_dump($email);
		$data = array(
			'username' => $username,
			'password' => $password,
			'telephone' => $telephone,
			'email' => $email
		);
		// var_dump($data);
		if($this->user_model->modify($data,$user_id)){
//            echo "<script>alert('Update Successful!Please login again to check.');window.location='/Home/username_login'</script>";
            echo json_encode(array('code' => 1, 'message' => 'Update Successful!Please login again to check.'));
        }else{
//            echo "<script>alert('Error,Please Check Again');window.location='/Home/user_info'</script>";
            echo json_encode(array('code' => 0, 'message' => 'Error,Please Check Again!'));
        }
	}
}









