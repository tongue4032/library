<?php if (! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->library('session');
	}
	const TBL_USER = 'lib_user';
	const TBL_BOOKINFO = 'lib_bookinfo';
	const TBL_BOOK_ACTION = 'lib_book_action';

	public function add_user($data){
		return $this->db->insert(self::TBL_USER,$data);
	}

	public function get_user($username,$pwd){
		$condition['username'] = $username;
		$condition['password'] = $pwd;
		$query = $this->db->where($condition)->get(self::TBL_USER);
		return $query->row_array();
	}
	public function get_email($email,$pwd){
		$condition['email'] = $email;
		$condition['password'] = $pwd;
		$query = $this->db->where($condition)->get(self::TBL_USER);
		return $query->row_array();
	}
	public function get_telephone($telephone,$pwd){
		$condition['telephone'] = $telephone;
		$condition['password'] = $pwd;
		$query = $this->db->where($condition)->get(self::TBL_USER);
		return $query->row_array();
	}

	public function sendemail($email){
		$this->db->select('user_id,username,password');//进行邮箱验证
        $sql = $this->db->get_where('lib_user',"email='$email'")->row_array();
        $id = $sql['user_id'];
        if(!$id){//该邮箱尚未注册！
           echo "<script>alert('This email address is not registered. Please check your email address.');window.location='./register'</script>";
           exit;
        }else{
           $get_pass_time = time(); //获取当前时间
           $uid = $sql['user_id'];//用户id
           $token = rand(1000,9999);//组合验证码
           $this->db->query("update lib_user set password='".$token."'where email='".$email."'");
           $smtp_email_to = $email; //收件人邮箱
           $url = "http://dev.ci.com/Home/reset?email=".$email."&token=".$token;//构造重置密码地址的URL
           $email_subject = "www.onelibrary.com - Retrieve password";//邮件主题
           $email_body = "Dear,".$email."：<br/>You submitted a password recovery request at ONELibrary.Please click the link below to reset the password(the link is valid within 24 hours)<br/><a href='".$url."'target='_blank'>".$url."</a>"; //邮件内容
            //加载Mailer类调用sendMail方法传参
           $this->load->library('Mailer');
           $this->mailer->sendMail($email_subject,$email_body,$smtp_email_to);           //更新数据时间
        }
	}

	public function Update($data,$token){
		return $this->db->query("update lib_user set password='".$data['password']."' where password='".$token."'");
	}

	public function search_book($data){
//		$condition['bookname'] = $bookname;
        $type = $data['type'];
        $info = $data['info'];
        if($type == 'Bookname') {
            $conditon['bookname'] = $info;
            $query = $this->db->where($conditon)->get(self::TBL_BOOKINFO);
            return $query->result_array();
        }
        if($type == 'Author'){
            $conditon['author'] = $info;
            $query = $this->db->where($conditon)->get(self::TBL_BOOKINFO);
            return $query->result_array();
        }
	}

	public function get($barcode,$user_id){
		$query = $this->db->get_where(self::TBL_BOOK_ACTION,array('barcode' => $barcode,'user_id' => $user_id));
		return $query->row_array();
	}

	public function borrow($data){
		return $this->db->insert(self::TBL_BOOK_ACTION,$data);
	}

	public function show_info($data){
		$query = $this->db->get_where(self::TBL_BOOK_ACTION,$data);
		return $query->result_array();
	}

	public function give_back($data){
		return $this->db->delete(self::TBL_BOOK_ACTION, $data); 
	}

	public function modify($data,$user_id){
		// $Email = $data['Email'];
		// var_dump($Email);
		$data = array(
			'username' => $data['username'],
			'password' => $data['password'],
			'telephone' => $data['telephone'],
			'email' => $data['email']  
		);
		$this->db->where("user_id='".$user_id."'");
		return $this->db->update('lib_user',$data);
	}
}











