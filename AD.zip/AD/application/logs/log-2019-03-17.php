<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-17 02:46:13 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 02:46:35 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 02:46:43 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 02:48:34 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 02:49:07 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 02:52:34 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 02:52:36 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:07:04 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:07:06 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:07:11 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:26:33 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:28:58 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:29:12 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:29:19 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:31:36 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:31:41 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:31:44 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:34:14 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:34:58 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:34:59 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:35:00 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:35:01 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:35:31 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:35:46 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:36:08 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:36:13 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:36:15 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:36:17 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:36:42 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:37:27 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:37:34 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:37:36 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 03:57:49 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 04:07:48 --> Severity: error --> Exception: syntax error, unexpected ')' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 22
ERROR - 2019-03-17 04:08:08 --> Severity: error --> Exception: syntax error, unexpected ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 23
ERROR - 2019-03-17 04:08:20 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-17 04:08:20 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-17 04:12:51 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-17 04:12:51 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-17 04:13:08 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-17 04:13:08 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-17 04:26:24 --> Severity: error --> Exception: Too few arguments to function Admin_model::show_book(), 0 passed in /Applications/MAMP/htdocs/AD/application/controllers/Admin.php on line 22 and exactly 1 expected /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 22
ERROR - 2019-03-17 06:32:10 --> Severity: error --> Exception: Too few arguments to function Admin_model::show_book(), 0 passed in /Applications/MAMP/htdocs/AD/application/controllers/Admin.php on line 22 and exactly 1 expected /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 22
ERROR - 2019-03-17 08:39:35 --> Severity: error --> Exception: Too few arguments to function Admin::show_books(), 0 passed in /Applications/MAMP/htdocs/AD/system/core/CodeIgniter.php on line 532 and exactly 1 expected /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 21
ERROR - 2019-03-17 08:39:52 --> Severity: error --> Exception: Too few arguments to function Admin_model::show_book(), 0 passed in /Applications/MAMP/htdocs/AD/application/controllers/Admin.php on line 22 and exactly 1 expected /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 22
ERROR - 2019-03-17 08:40:25 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 23
ERROR - 2019-03-17 09:45:52 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 09:46:39 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 09:46:41 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 09:47:52 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 09:47:54 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 09:47:54 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 09:49:54 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:17:57 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:44:37 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:44:39 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:44:40 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:44:40 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:44:41 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:44:41 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:12 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:14 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:15 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:15 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:15 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:16 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:16 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:16 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:16 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:17 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:17 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:17 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:17 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:17 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:17 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:17 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:45:40 --> 404 Page Not Found: Admin/show_books
ERROR - 2019-03-17 12:46:47 --> 404 Page Not Found: Admin/show_books
ERROR - 2019-03-17 12:46:56 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:52:23 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:54:51 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:55:23 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:55:39 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:55:46 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:56:01 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:56:12 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:56:20 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:56:30 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:56:38 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 12:57:01 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:57:30 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:58:05 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:58:13 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 12:58:23 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:58:29 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 12:59:15 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:59:16 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 12:59:41 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 12:59:47 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 13:00:39 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 13:00:40 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 13:00:40 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 13:00:40 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 13:00:40 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 13:00:41 --> Severity: Notice --> Undefined variable: links /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 13:00:41 --> 404 Page Not Found: Common/css
ERROR - 2019-03-17 15:07:12 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 15:07:31 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 15:07:57 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 15:08:18 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 15:08:47 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
ERROR - 2019-03-17 15:08:49 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 145
