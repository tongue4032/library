<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-27 06:49:51 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:49:52 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:49:53 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:49:54 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:49:54 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:50:01 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:50:01 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:57:13 --> Severity: Notice --> Use of undefined constant id - assumed 'id' /Applications/MAMP/htdocs/AD/application/controllers/User.php 41
ERROR - 2019-04-27 06:57:15 --> Severity: Notice --> Use of undefined constant id - assumed 'id' /Applications/MAMP/htdocs/AD/application/controllers/User.php 41
ERROR - 2019-04-27 06:57:16 --> Severity: Notice --> Use of undefined constant id - assumed 'id' /Applications/MAMP/htdocs/AD/application/controllers/User.php 41
ERROR - 2019-04-27 06:57:16 --> Severity: Notice --> Use of undefined constant id - assumed 'id' /Applications/MAMP/htdocs/AD/application/controllers/User.php 41
ERROR - 2019-04-27 06:57:21 --> Severity: Notice --> Use of undefined constant id - assumed 'id' /Applications/MAMP/htdocs/AD/application/controllers/User.php 41
