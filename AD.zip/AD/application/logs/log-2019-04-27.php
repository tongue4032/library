<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-27 06:49:51 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:49:52 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:49:53 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:49:54 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:49:54 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:50:01 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:50:01 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-04-27 06:57:13 --> Severity: Notice --> Use of undefined constant id - assumed 'id' /Applications/MAMP/htdocs/AD/application/controllers/User.php 41
ERROR - 2019-04-27 06:57:15 --> Severity: Notice --> Use of undefined constant id - assumed 'id' /Applications/MAMP/htdocs/AD/application/controllers/User.php 41
ERROR - 2019-04-27 06:57:16 --> Severity: Notice --> Use of undefined constant id - assumed 'id' /Applications/MAMP/htdocs/AD/application/controllers/User.php 41
ERROR - 2019-04-27 06:57:16 --> Severity: Notice --> Use of undefined constant id - assumed 'id' /Applications/MAMP/htdocs/AD/application/controllers/User.php 41
ERROR - 2019-04-27 06:57:21 --> Severity: Notice --> Use of undefined constant id - assumed 'id' /Applications/MAMP/htdocs/AD/application/controllers/User.php 41
ERROR - 2019-04-27 10:15:59 --> 404 Page Not Found: Permissions/role_admin
ERROR - 2019-04-27 10:16:01 --> 404 Page Not Found: Permissions/role_admin
ERROR - 2019-04-27 10:16:12 --> 404 Page Not Found: Permissions/role_admin
ERROR - 2019-04-27 10:16:12 --> 404 Page Not Found: Permissions/role_admin
ERROR - 2019-04-27 10:16:13 --> 404 Page Not Found: Permissions/role_admin
ERROR - 2019-04-27 10:16:17 --> 404 Page Not Found: Permissions/role_admin
ERROR - 2019-04-27 10:34:55 --> 404 Page Not Found: Permission/show_roles
ERROR - 2019-04-27 10:35:43 --> 404 Page Not Found: Permission/show_roles
ERROR - 2019-04-27 10:36:10 --> 404 Page Not Found: Permission/show_roles
ERROR - 2019-04-27 10:37:25 --> 404 Page Not Found: Permission/show_roles
ERROR - 2019-04-27 10:37:30 --> 404 Page Not Found: Permission/roles
ERROR - 2019-04-27 10:37:49 --> 404 Page Not Found: Permission/roles
ERROR - 2019-04-27 10:38:47 --> 404 Page Not Found: Permission/roles
ERROR - 2019-04-27 10:38:52 --> 404 Page Not Found: Permission/show_roles
ERROR - 2019-04-27 10:41:01 --> 404 Page Not Found: Permission/show_roles
ERROR - 2019-04-27 10:41:52 --> 404 Page Not Found: Permission/show_roles
ERROR - 2019-04-27 10:42:14 --> 404 Page Not Found: Permission/role_admins
ERROR - 2019-04-27 10:55:51 --> Severity: Notice --> Undefined index: admin_name /Applications/MAMP/htdocs/AD/application/views/Permissions/role.php 31
ERROR - 2019-04-27 10:55:57 --> Severity: Notice --> Undefined index: admin_name /Applications/MAMP/htdocs/AD/application/views/Permissions/role_users.php 30
ERROR - 2019-04-27 10:56:00 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 63
ERROR - 2019-04-27 10:56:04 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 63
ERROR - 2019-04-27 10:56:05 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 63
ERROR - 2019-04-27 10:56:59 --> Severity: Notice --> Undefined index: admin_name /Applications/MAMP/htdocs/AD/application/views/Permissions/role_users.php 30
ERROR - 2019-04-27 10:57:02 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 63
ERROR - 2019-04-27 10:57:04 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 63
ERROR - 2019-04-27 10:57:56 --> Severity: Notice --> Undefined index: admin_name /Applications/MAMP/htdocs/AD/application/views/Permissions/role_users.php 30
ERROR - 2019-04-27 10:57:59 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 63
ERROR - 2019-04-27 10:59:11 --> Severity: Notice --> Undefined index: admin_name /Applications/MAMP/htdocs/AD/application/views/Permissions/role_users.php 30
ERROR - 2019-04-27 10:59:13 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 63
ERROR - 2019-04-27 11:03:27 --> Severity: Notice --> Undefined index: admin_name /Applications/MAMP/htdocs/AD/application/views/Permissions/role_users.php 30
ERROR - 2019-04-27 11:03:29 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 63
ERROR - 2019-04-27 11:03:30 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 63
ERROR - 2019-04-27 11:03:30 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 63
ERROR - 2019-04-27 11:03:30 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 63
ERROR - 2019-04-27 11:03:30 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 63
ERROR - 2019-04-27 11:04:21 --> Severity: Notice --> Undefined index: admin_name /Applications/MAMP/htdocs/AD/application/views/Permissions/role_users.php 30
ERROR - 2019-04-27 11:07:05 --> Severity: Notice --> Undefined index: admin_name /Applications/MAMP/htdocs/AD/application/views/Permissions/role_users.php 30
ERROR - 2019-04-27 11:08:19 --> Severity: Notice --> Undefined index: admin_name /Applications/MAMP/htdocs/AD/application/views/Permissions/role_admins.php 30
ERROR - 2019-04-27 11:12:02 --> Severity: Notice --> Undefined variable: user_id /Applications/MAMP/htdocs/AD/application/views/Permissions/role.php 106
ERROR - 2019-04-27 11:12:02 --> Severity: Notice --> Undefined variable: username /Applications/MAMP/htdocs/AD/application/views/Permissions/role.php 108
ERROR - 2019-04-27 11:12:02 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/Permissions/role.php 114
ERROR - 2019-04-27 11:12:02 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/Permissions/role.php 114
