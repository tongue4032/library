<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-25 02:18:28 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-25 02:21:40 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-25 02:26:26 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 133
ERROR - 2019-03-25 02:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 133
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 135
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 136
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 137
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 138
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 135
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 136
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 137
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 138
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 135
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 136
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 137
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 138
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 135
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 136
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 137
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 138
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:29:45 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:30:00 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 135
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 136
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 137
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 138
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 135
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 136
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 137
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 138
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 135
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 136
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 137
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 138
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 135
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 136
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 137
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 138
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:29 --> Severity: Notice --> Undefined variable: suer /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:36:30 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:37:02 --> Severity: Notice --> Undefined index: email /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:37:02 --> Severity: Notice --> Undefined index: email /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:37:02 --> Severity: Notice --> Undefined index: email /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:37:02 --> Severity: Notice --> Undefined index: email /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-25 02:37:02 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:37:29 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:37:47 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:38:21 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:38:24 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:38:32 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:39:45 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:40:13 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:40:40 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:40:44 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:41:21 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:41:22 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 02:58:06 --> 404 Page Not Found: Admin/delete_user
ERROR - 2019-03-25 03:30:31 --> 404 Page Not Found: Admin/show_admins
ERROR - 2019-03-25 03:32:39 --> 404 Page Not Found: Common/images
ERROR - 2019-03-25 03:32:46 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 03:33:02 --> 404 Page Not Found: Common/images
ERROR - 2019-03-25 03:33:03 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 03:33:27 --> 404 Page Not Found: Common/images
ERROR - 2019-03-25 03:33:27 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 03:33:43 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 03:33:51 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 03:33:53 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 03:38:23 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::where() /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 35
ERROR - 2019-03-25 03:39:06 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:09 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:10 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:11 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:12 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:13 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:13 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:14 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:14 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:15 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:16 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:16 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:34 --> Severity: Notice --> Use of undefined constant password - assumed 'password' /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 35
ERROR - 2019-03-25 03:39:34 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:34 --> Severity: Notice --> Use of undefined constant password - assumed 'password' /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 35
ERROR - 2019-03-25 03:39:34 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:35 --> Severity: Notice --> Use of undefined constant password - assumed 'password' /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 35
ERROR - 2019-03-25 03:39:35 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:36 --> Severity: Notice --> Use of undefined constant password - assumed 'password' /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 35
ERROR - 2019-03-25 03:39:36 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:37 --> Severity: Notice --> Use of undefined constant password - assumed 'password' /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 35
ERROR - 2019-03-25 03:39:37 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:39:38 --> Severity: Notice --> Use of undefined constant password - assumed 'password' /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 35
ERROR - 2019-03-25 03:39:38 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:42:14 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:42:14 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:42:15 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:42:16 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:42:17 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:42:36 --> Severity: Notice --> Undefined variable: pwd /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 36
ERROR - 2019-03-25 03:42:37 --> Severity: Notice --> Undefined variable: pwd /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 36
ERROR - 2019-03-25 03:42:38 --> Severity: Notice --> Undefined variable: pwd /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 36
ERROR - 2019-03-25 03:42:39 --> Severity: Notice --> Undefined variable: pwd /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 36
ERROR - 2019-03-25 03:44:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date='2011-08-00'
ERROR - 2019-03-25 03:44:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date='2011-08-00'
ERROR - 2019-03-25 03:51:27 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::where() /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 35
ERROR - 2019-03-25 03:52:19 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 2442
ERROR - 2019-03-25 03:52:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: DELETE FROM `lib_user`
WHERE `user_id` = '9'
AND `username` = ''
AND `telephone` IS NULL
AND `Email` = '2046817306@me.com'
AND `register_date` = '2019-03-25 09:49:33'
AND `password` = 
ERROR - 2019-03-25 03:52:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 03:52:49 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:52:52 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:52:53 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:52:54 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 1261
ERROR - 2019-03-25 03:53:54 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 154
ERROR - 2019-03-25 03:54:03 --> Severity: error --> Exception: Undefined class constant 'TBL_USER' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 154
ERROR - 2019-03-25 03:54:24 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 2442
ERROR - 2019-03-25 03:54:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND `telephone` IS NULL
AND `Email` = '2046817306@me.com'
AND `register_date` = ' at line 5 - Invalid query: DELETE FROM `lib_user`
WHERE `user_id` = '9'
AND `username` = ''
AND `password` = 
AND `telephone` IS NULL
AND `Email` = '2046817306@me.com'
AND `register_date` = '2019-03-25 09:49:33'
ERROR - 2019-03-25 03:54:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 03:54:56 --> Severity: error --> Exception: syntax error, unexpected ',' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 148
ERROR - 2019-03-25 03:55:04 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 2442
ERROR - 2019-03-25 03:55:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND `telephone` IS NULL
AND `Email` = '2046817306@me.com'
AND `register_date` = ' at line 5 - Invalid query: DELETE FROM `lib_user`
WHERE `user_id` = '9'
AND `username` = ''
AND `password` = 
AND `telephone` IS NULL
AND `Email` = '2046817306@me.com'
AND `register_date` = '2019-03-25 09:49:33'
ERROR - 2019-03-25 03:55:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 04:25:00 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 04:27:06 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 04:27:22 --> 404 Page Not Found: Admin/show_admins
ERROR - 2019-03-25 04:29:31 --> 404 Page Not Found: Admin/show_admins
ERROR - 2019-03-25 04:30:00 --> 404 Page Not Found: Admin/show_admins
ERROR - 2019-03-25 04:31:43 --> 404 Page Not Found: Admin/show_admins
ERROR - 2019-03-25 04:31:49 --> 404 Page Not Found: Admin/show_admins
ERROR - 2019-03-25 04:43:37 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 04:43:47 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 04:45:49 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 04:45:53 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 04:46:00 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 04:46:43 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 04:47:07 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 04:47:38 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 04:47:48 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 04:47:55 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:47:55 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:47:55 --> Severity: Notice --> Undefined index: telephone /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:47:55 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:47:55 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:47:55 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:47:55 --> Severity: Notice --> Undefined index: telephone /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:47:55 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:48:00 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:48:00 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:48:00 --> Severity: Notice --> Undefined index: telephone /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:48:00 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:48:00 --> Severity: Notice --> Undefined index: user_id /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:48:00 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:48:00 --> Severity: Notice --> Undefined index: telephone /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:48:00 --> Severity: Notice --> Undefined index: Email /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 04:49:56 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-03-25 04:50:02 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 07:11:45 --> Severity: error --> Exception: syntax error, unexpected '}', expecting variable (T_VARIABLE) or '{' or '$' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 176
ERROR - 2019-03-25 07:12:49 --> Severity: error --> Exception: syntax error, unexpected '}', expecting variable (T_VARIABLE) or '{' or '$' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 176
ERROR - 2019-03-25 07:16:55 --> Severity: Notice --> Undefined variable: barcode /Applications/MAMP/htdocs/AD/application/views/change_admin.php 129
ERROR - 2019-03-25 07:16:55 --> Severity: Notice --> Undefined variable: bookname /Applications/MAMP/htdocs/AD/application/views/change_admin.php 131
ERROR - 2019-03-25 07:16:55 --> Severity: Notice --> Undefined variable: author /Applications/MAMP/htdocs/AD/application/views/change_admin.php 136
ERROR - 2019-03-25 07:17:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='admin' author='Super Administrator' press='' publish_date=''' at line 1 - Invalid query: update lib_bookinfo set barcode='1' bookname='admin' author='Super Administrator' press='' publish_date=''
ERROR - 2019-03-25 07:23:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='admin' author='Super Administrator' press='' publish_date=''' at line 1 - Invalid query: update lib_bookinfo set barcode='1' bookname='admin' author='Super Administrator' press='' publish_date=''
ERROR - 2019-03-25 07:23:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin1' professional='Administrator'' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin1' professional='Administrator'
ERROR - 2019-03-25 07:39:05 --> Severity: Notice --> Undefined index: admin_id /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 188
ERROR - 2019-03-25 07:39:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin' professional='Administrator' where ''' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin' professional='Administrator' where ''
ERROR - 2019-03-25 07:39:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 07:39:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin' professional='Administrator'' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin' professional='Administrator'
ERROR - 2019-03-25 07:47:35 --> Severity: Notice --> Undefined index: token /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 188
ERROR - 2019-03-25 07:47:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin' professional='Administrator' where admin=''' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin' professional='Administrator' where admin=''
ERROR - 2019-03-25 07:47:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 07:48:54 --> Severity: Notice --> Undefined index: token /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 188
ERROR - 2019-03-25 07:48:54 --> Severity: Notice --> Undefined index: token /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 189
ERROR - 2019-03-25 07:48:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin' professional='Administrator' where admin=''' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin' professional='Administrator' where admin=''
ERROR - 2019-03-25 07:48:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 07:49:11 --> Severity: Notice --> Undefined index: token /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 188
ERROR - 2019-03-25 07:49:11 --> Severity: Notice --> Undefined index: token /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 190
ERROR - 2019-03-25 07:49:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin' professional='Administrator' where admin=''' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin' professional='Administrator' where admin=''
ERROR - 2019-03-25 07:49:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 07:51:11 --> Severity: Notice --> Undefined index: token /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 188
ERROR - 2019-03-25 07:51:11 --> Severity: Notice --> Undefined index: token /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 190
ERROR - 2019-03-25 07:51:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin' professional='Administrator' where ''' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin' professional='Administrator' where ''
ERROR - 2019-03-25 07:51:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 07:51:46 --> Severity: Notice --> Undefined variable: token /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 196
ERROR - 2019-03-25 07:51:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin' professional='Administrator' where ''' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin' professional='Administrator' where ''
ERROR - 2019-03-25 07:51:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 07:52:00 --> Severity: error --> Exception: Too few arguments to function Admin_model::change_admin(), 1 passed in /Applications/MAMP/htdocs/AD/application/controllers/Admin.php on line 196 and exactly 2 expected /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 60
ERROR - 2019-03-25 07:52:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin' professional='Administrator'' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin' professional='Administrator'
ERROR - 2019-03-25 07:53:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin' professional='Administrator'' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin' professional='Administrator'
ERROR - 2019-03-25 07:56:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin' professional='Administrator'' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin' professional='Administrator'
ERROR - 2019-03-25 07:57:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin1' professional='Administrator'' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin1' professional='Administrator'
ERROR - 2019-03-25 07:58:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin1' professional='Administrator' where admin_id=1''' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin1' professional='Administrator' where admin_id=1''
ERROR - 2019-03-25 07:58:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin1' professional='Administrator'' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin1' professional='Administrator'
ERROR - 2019-03-25 07:58:47 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 138
ERROR - 2019-03-25 07:58:47 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 07:58:47 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 138
ERROR - 2019-03-25 07:58:47 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 07:58:49 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 138
ERROR - 2019-03-25 07:58:49 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 07:58:49 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 138
ERROR - 2019-03-25 07:58:49 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-25 07:59:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'admin_name='admin1' professional='Administrator'' at line 1 - Invalid query: update lib_admin set admin_id='1' admin_name='admin1' professional='Administrator'
ERROR - 2019-03-25 08:05:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'professional='Administrator' where admin_id='1'' at line 1 - Invalid query: update lib_admin set admin_name='admin' professional='Administrator' where admin_id='1'
ERROR - 2019-03-25 08:07:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'professional='Administrator' where admin_id=''' at line 1 - Invalid query: update lib_admin set admin_name='admin' professional='Administrator' where admin_id=''
ERROR - 2019-03-25 08:09:50 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 188
ERROR - 2019-03-25 08:09:50 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 61
ERROR - 2019-03-25 08:09:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'professional='Administrator' where admin_id='Array'' at line 1 - Invalid query: update lib_admin set admin_name='admin' professional='Administrator' where admin_id='Array'
ERROR - 2019-03-25 08:09:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 08:10:43 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 188
ERROR - 2019-03-25 08:10:43 --> Severity: Notice --> Undefined variable: admins /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 189
ERROR - 2019-03-25 08:10:43 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 61
ERROR - 2019-03-25 08:10:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'professional='Administrator' where admin_id='Array'' at line 1 - Invalid query: update lib_admin set admin_name='admin' professional='Administrator' where admin_id='Array'
ERROR - 2019-03-25 08:10:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 08:11:19 --> Severity: Notice --> Undefined variable: admins /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 189
ERROR - 2019-03-25 08:11:19 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 61
ERROR - 2019-03-25 08:11:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'professional='Administrator' where admin_id='Array'' at line 1 - Invalid query: update lib_admin set admin_name='admin' professional='Administrator' where admin_id='Array'
ERROR - 2019-03-25 08:11:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 08:11:49 --> Severity: Notice --> Undefined index: admin_id /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 189
ERROR - 2019-03-25 08:11:49 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 61
ERROR - 2019-03-25 08:11:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'professional='Administrator' where admin_id='Array'' at line 1 - Invalid query: update lib_admin set admin_name='admin' professional='Administrator' where admin_id='Array'
ERROR - 2019-03-25 08:11:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 08:12:19 --> Severity: Warning --> Illegal offset type /Applications/MAMP/htdocs/AD/system/core/Input.php 190
ERROR - 2019-03-25 08:12:19 --> Severity: Warning --> Illegal offset type /Applications/MAMP/htdocs/AD/system/core/Input.php 190
ERROR - 2019-03-25 08:12:19 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 61
ERROR - 2019-03-25 08:12:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'professional='Administrator' where admin_id='Array'' at line 1 - Invalid query: update lib_admin set admin_name='admin' professional='Administrator' where admin_id='Array'
ERROR - 2019-03-25 08:12:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 08:14:13 --> Severity: Notice --> Undefined variable: admins /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 189
ERROR - 2019-03-25 08:14:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'professional='Administrator' where admin_id=''' at line 1 - Invalid query: update lib_admin set admin_name='admin' professional='Administrator' where admin_id=''
ERROR - 2019-03-25 08:14:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 08:14:57 --> Severity: Notice --> Undefined variable: admin /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 189
ERROR - 2019-03-25 08:14:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'professional='Administrator' where admin_id=''' at line 1 - Invalid query: update lib_admin set admin_name='admin' professional='Administrator' where admin_id=''
ERROR - 2019-03-25 08:14:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 08:15:12 --> Severity: Notice --> Undefined variable: ad /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 189
ERROR - 2019-03-25 08:15:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'professional='Administrator' where admin_id=''' at line 1 - Invalid query: update lib_admin set admin_name='admin' professional='Administrator' where admin_id=''
ERROR - 2019-03-25 08:15:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 08:16:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'professional='Administrator'' at line 1 - Invalid query: update lib_admin set admin_name='admin' professional='Administrator'
ERROR - 2019-03-25 08:22:44 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 175
ERROR - 2019-03-25 08:22:46 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 175
ERROR - 2019-03-25 08:22:50 --> Severity: Notice --> Undefined variable: user /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 175
ERROR - 2019-03-25 08:28:53 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-03-25 08:34:29 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-03-25 08:34:33 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2019-03-25 08:45:00 --> Severity: Warning --> require(You do not have permission to do this!): failed to open stream: No such file or directory /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 210
ERROR - 2019-03-25 08:45:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 08:45:00 --> Severity: Compile Error --> require(): Failed opening required 'You do not have permission to do this!' (include_path='.:/Applications/MAMP/bin/php/php7.1.12/lib/php') /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 210
ERROR - 2019-03-25 08:45:18 --> Severity: error --> Exception: syntax error, unexpected '}' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 211
ERROR - 2019-03-25 08:45:30 --> Severity: error --> Exception: syntax error, unexpected '}' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 211
ERROR - 2019-03-25 08:45:32 --> Severity: error --> Exception: syntax error, unexpected '}' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 211
ERROR - 2019-03-25 08:45:35 --> Severity: error --> Exception: syntax error, unexpected '}' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 211
ERROR - 2019-03-25 08:45:35 --> Severity: error --> Exception: syntax error, unexpected '}' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 211
ERROR - 2019-03-25 08:45:41 --> Severity: error --> Exception: syntax error, unexpected ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 210
ERROR - 2019-03-25 08:48:39 --> Severity: error --> Exception: syntax error, unexpected ''hhhhh'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 210
ERROR - 2019-03-25 08:49:11 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ',' or ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 210
ERROR - 2019-03-25 08:59:06 --> Severity: Notice --> Undefined variable: user_id /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 217
ERROR - 2019-03-25 08:59:06 --> Severity: Notice --> Undefined variable: username /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 218
ERROR - 2019-03-25 08:59:06 --> Severity: Notice --> Undefined variable: telephone /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 219
ERROR - 2019-03-25 08:59:06 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: DELETE FROM `lib_admin`
WHERE `user_id` IS NULL
AND `username` IS NULL
AND `telephone` IS NULL
AND `register_date` = '2019-03-25 15:57:52'
ERROR - 2019-03-25 08:59:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 09:20:38 --> Severity: error --> Exception: syntax error, unexpected '}', expecting '(' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 240
ERROR - 2019-03-25 09:23:27 --> Severity: error --> Exception: syntax error, unexpected '}', expecting '(' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 240
ERROR - 2019-03-25 10:19:55 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:21:42 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:23:11 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:23:13 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:23:30 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:23:30 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:23:31 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:23:32 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:25:16 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:27:27 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:29:39 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:30:10 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:31:42 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:32:35 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:34:09 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:34:16 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:34:27 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:34:42 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:34:56 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:35:38 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:39:57 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:40:26 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:45:25 --> Severity: Notice --> Undefined variable: users /Applications/MAMP/htdocs/AD/application/views/role_admins.php 136
ERROR - 2019-03-25 10:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/role_admins.php 136
ERROR - 2019-03-25 10:48:23 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:49:08 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:49:19 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:51:55 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:52:08 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:52:10 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:53:20 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:53:21 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:53:23 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:53:43 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:53:46 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 10:53:48 --> 404 Page Not Found: Common/css
ERROR - 2019-03-25 11:07:17 --> Severity: Notice --> Undefined variable: admin_id /Applications/MAMP/htdocs/AD/application/views/role.php 129
ERROR - 2019-03-25 11:07:17 --> Severity: Notice --> Undefined variable: admin_name /Applications/MAMP/htdocs/AD/application/views/role.php 131
ERROR - 2019-03-25 11:07:17 --> Severity: Notice --> Undefined variable: professional /Applications/MAMP/htdocs/AD/application/views/role.php 136
ERROR - 2019-03-25 11:14:24 --> Severity: 4096 --> Object of class Admin could not be converted to string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 272
ERROR - 2019-03-25 11:14:24 --> Severity: Notice --> Undefined variable:  /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 272
ERROR - 2019-03-25 11:14:24 --> Severity: Notice --> Trying to get property of non-object /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 272
ERROR - 2019-03-25 11:14:24 --> Severity: error --> Exception: Call to a member function view() on null /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 272
ERROR - 2019-03-25 11:14:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-25 11:16:27 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 274
ERROR - 2019-03-25 11:21:37 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 274
ERROR - 2019-03-25 11:22:17 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 274
ERROR - 2019-03-25 11:23:11 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 274
ERROR - 2019-03-25 11:23:13 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 274
ERROR - 2019-03-25 15:07:03 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 288
ERROR - 2019-03-25 15:07:33 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 318
