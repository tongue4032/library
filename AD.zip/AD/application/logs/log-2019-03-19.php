<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-19 02:16:25 --> 404 Page Not Found: Admin/show_books
ERROR - 2019-03-19 02:16:32 --> 404 Page Not Found: Admin/show_books
ERROR - 2019-03-19 02:17:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-19 02:17:59 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-19 02:17:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-19 02:19:14 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-19 02:19:14 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-19 02:19:29 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-19 02:19:36 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-19 02:20:07 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-19 02:20:07 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-19 02:20:34 --> 404 Page Not Found: Admin/list_news
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: username /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 12:14:17 --> Severity: Notice --> Undefined index: borrow_time /Applications/MAMP/htdocs/AD/application/views/show_books.php 141
ERROR - 2019-03-19 14:13:48 --> Severity: error --> Exception: syntax error, unexpected 'Null' (T_STRING), expecting ',' or ')' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 78
ERROR - 2019-03-19 14:14:08 --> 404 Page Not Found: Home/delete
ERROR - 2019-03-19 14:14:45 --> 404 Page Not Found: Home/delete
ERROR - 2019-03-19 14:15:51 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:15:56 --> Severity: Notice --> Undefined property: Admin::$user_model /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-03-19 14:15:56 --> Severity: error --> Exception: Call to a member function delete() on null /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-03-19 14:15:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-19 14:16:10 --> 404 Page Not Found: Show_books/index
ERROR - 2019-03-19 14:16:28 --> 404 Page Not Found: Show_books/index
ERROR - 2019-03-19 14:19:04 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:19:14 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:19:17 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:19:20 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:19:22 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:19:23 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:19:26 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:19:27 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:19:28 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:19:29 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:19:30 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:19:32 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:19:33 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:19:34 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:20:45 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:20:47 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:21:44 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:21:51 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:21:53 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:22:03 --> 404 Page Not Found: Common/css
ERROR - 2019-03-19 14:22:06 --> 404 Page Not Found: Common/css
