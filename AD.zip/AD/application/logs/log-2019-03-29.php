<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-29 04:33:57 --> Severity: Warning --> A non-numeric value encountered /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 46
ERROR - 2019-03-29 04:33:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-7, 7' at line 3 - Invalid query: SELECT *
FROM `lib_bookinfo`
 LIMIT -7, 7
ERROR - 2019-03-29 04:33:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-29 04:35:17 --> Severity: Warning --> A non-numeric value encountered /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 46
ERROR - 2019-03-29 04:35:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-7, 7' at line 3 - Invalid query: SELECT *
FROM `lib_bookinfo`
 LIMIT -7, 7
ERROR - 2019-03-29 04:35:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-29 04:35:26 --> Severity: Warning --> A non-numeric value encountered /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 46
ERROR - 2019-03-29 04:35:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-7, 7' at line 3 - Invalid query: SELECT *
FROM `lib_bookinfo`
 LIMIT -7, 7
ERROR - 2019-03-29 04:35:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-29 04:36:23 --> Severity: Warning --> A non-numeric value encountered /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 68
ERROR - 2019-03-29 04:36:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8, 8' at line 3 - Invalid query: SELECT *
FROM `lib_user`
 LIMIT -8, 8
ERROR - 2019-03-29 04:36:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-29 04:37:35 --> Severity: Warning --> A non-numeric value encountered /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 68
ERROR - 2019-03-29 04:37:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8, 8' at line 3 - Invalid query: SELECT *
FROM `lib_user`
 LIMIT -8, 8
ERROR - 2019-03-29 04:37:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-29 04:37:38 --> Severity: Warning --> A non-numeric value encountered /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 68
ERROR - 2019-03-29 04:37:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8, 8' at line 3 - Invalid query: SELECT *
FROM `lib_user`
 LIMIT -8, 8
ERROR - 2019-03-29 04:37:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-29 04:47:41 --> Severity: Warning --> A non-numeric value encountered /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 68
ERROR - 2019-03-29 04:47:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-8, 8' at line 3 - Invalid query: SELECT *
FROM `lib_user`
 LIMIT -8, 8
ERROR - 2019-03-29 04:47:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-29 04:50:08 --> 404 Page Not Found: Common/css
ERROR - 2019-03-29 04:54:51 --> 404 Page Not Found: Common/css
ERROR - 2019-03-29 04:54:54 --> 404 Page Not Found: Common/css
ERROR - 2019-03-29 04:57:33 --> 404 Page Not Found: Common/css
ERROR - 2019-03-29 04:58:02 --> 404 Page Not Found: Common/css
ERROR - 2019-03-29 04:58:20 --> 404 Page Not Found: Common/css
ERROR - 2019-03-29 05:01:17 --> 404 Page Not Found: Common/css
ERROR - 2019-03-29 05:01:21 --> 404 Page Not Found: Common/css
ERROR - 2019-03-29 05:03:12 --> 404 Page Not Found: Common/css
