<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-22 09:43:18 --> Severity: Warning --> include_once(PHPMailer/class.smtp.php): failed to open stream: No such file or directory /Applications/MAMP/htdocs/CI/application/libraries/Mailer.php 7
ERROR - 2019-02-22 09:43:18 --> Severity: Warning --> include_once(): Failed opening 'PHPMailer/class.smtp.php' for inclusion (include_path='.:/Applications/MAMP/bin/php/php7.1.12/lib/php') /Applications/MAMP/htdocs/CI/application/libraries/Mailer.php 7
ERROR - 2019-02-22 09:43:18 --> Severity: Warning --> include_once(PHPMailer/class.phpmailer.php): failed to open stream: No such file or directory /Applications/MAMP/htdocs/CI/application/libraries/Mailer.php 8
ERROR - 2019-02-22 09:43:18 --> Severity: Warning --> include_once(): Failed opening 'PHPMailer/class.phpmailer.php' for inclusion (include_path='.:/Applications/MAMP/bin/php/php7.1.12/lib/php') /Applications/MAMP/htdocs/CI/application/libraries/Mailer.php 8
ERROR - 2019-02-22 09:43:18 --> Severity: error --> Exception: Class 'PHPMailer' not found /Applications/MAMP/htdocs/CI/application/libraries/Mailer.php 9
ERROR - 2019-02-22 09:43:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-22 09:45:11 --> 404 Page Not Found: Home/update
ERROR - 2019-02-22 11:03:44 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 113
ERROR - 2019-02-22 11:34:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = 'Tony1411'' at line 1 - Invalid query: UPDATE `lib_user` SET 0 = 'Tony1411'
ERROR - 2019-02-22 11:36:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = 'Tony1411'
WHERE `lib_user` = '2046817306@qq.com'' at line 1 - Invalid query: UPDATE `lib_user` SET 0 = 'Tony1411'
WHERE `lib_user` = '2046817306@qq.com'
ERROR - 2019-02-22 11:37:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = 'Tony1411'
WHERE `lib_user` IS NULL' at line 1 - Invalid query: UPDATE `lib_user` SET 0 = 'Tony1411'
WHERE `lib_user` IS NULL
ERROR - 2019-02-22 11:37:27 --> Severity: Notice --> Undefined variable: password /Applications/MAMP/htdocs/CI/application/models/User_model.php 22
ERROR - 2019-02-22 11:37:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = 'Tony1411'
WHERE `lib_user` IS NULL' at line 1 - Invalid query: UPDATE `lib_user` SET 0 = 'Tony1411'
WHERE `lib_user` IS NULL
ERROR - 2019-02-22 11:37:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-22 11:38:23 --> Severity: Notice --> Undefined variable: email /Applications/MAMP/htdocs/CI/application/controllers/Home.php 102
ERROR - 2019-02-22 11:38:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = 'Tony1411'
WHERE `lib_user` IS NULL' at line 1 - Invalid query: UPDATE `lib_user` SET 0 = 'Tony1411'
WHERE `lib_user` IS NULL
ERROR - 2019-02-22 11:38:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-22 11:38:33 --> Severity: error --> Exception: Too few arguments to function User_model::updateUser(), 1 passed in /Applications/MAMP/htdocs/CI/application/controllers/Home.php on line 102 and exactly 2 expected /Applications/MAMP/htdocs/CI/application/models/User_model.php 21
ERROR - 2019-02-22 11:39:10 --> Severity: Notice --> Undefined variable: password /Applications/MAMP/htdocs/CI/application/models/User_model.php 22
ERROR - 2019-02-22 11:39:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = 'Tony1411'
WHERE `lib_user` IS NULL' at line 1 - Invalid query: UPDATE `lib_user` SET 0 = 'Tony1411'
WHERE `lib_user` IS NULL
ERROR - 2019-02-22 11:39:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-22 11:40:20 --> Severity: Notice --> Undefined variable: password /Applications/MAMP/htdocs/CI/application/models/User_model.php 22
ERROR - 2019-02-22 11:40:20 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2019-02-22 11:40:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-22 11:41:03 --> Severity: Notice --> Undefined variable: password /Applications/MAMP/htdocs/CI/application/models/User_model.php 22
ERROR - 2019-02-22 11:41:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `lib_user` IS NULL' at line 2 - Invalid query: SELECT *
WHERE `lib_user` IS NULL
ERROR - 2019-02-22 11:41:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-22 11:41:20 --> Severity: Notice --> Undefined variable: password /Applications/MAMP/htdocs/CI/application/models/User_model.php 22
ERROR - 2019-02-22 11:41:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `lib_user` IS NULL' at line 2 - Invalid query: SELECT *
WHERE `lib_user` IS NULL
ERROR - 2019-02-22 11:41:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-22 11:42:54 --> Query error: Table 'library.tony1411' doesn't exist - Invalid query: SELECT *
FROM `Tony1411`
WHERE `lib_user` IS NULL
ERROR - 2019-02-22 11:43:16 --> Query error: Table 'library.tony1411' doesn't exist - Invalid query: SELECT *
FROM `Tony1411`
WHERE `lib_user` IS NULL
ERROR - 2019-02-22 11:43:20 --> Query error: Table 'library.tony1411' doesn't exist - Invalid query: SELECT *
FROM `Tony1411`
WHERE `lib_user` IS NULL
ERROR - 2019-02-22 11:43:57 --> Query error: Table 'library.tony1411' doesn't exist - Invalid query: SELECT *
FROM `Tony1411`
WHERE `lib_user` = 'password'
ERROR - 2019-02-22 11:44:54 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/CI/system/database/DB_query_builder.php 2442
ERROR - 2019-02-22 11:44:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = 'Tony1411'
WHERE `lib_user` =' at line 1 - Invalid query: UPDATE `lib_user` SET 0 = 'Tony1411'
WHERE `lib_user` = 
ERROR - 2019-02-22 11:44:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-22 13:45:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = 'Tony1411'
WHERE `lib_user` = 'Tony1411'' at line 1 - Invalid query: UPDATE `lib_user` SET 0 = 'Tony1411'
WHERE `lib_user` = 'Tony1411'
ERROR - 2019-02-22 13:45:32 --> Query error: Table 'library.email' doesn't exist - Invalid query: SELECT *
FROM `email`
ERROR - 2019-02-22 13:45:55 --> Query error: Table 'library.library' doesn't exist - Invalid query: SELECT *
FROM `library`
 LIMIT 0
ERROR - 2019-02-22 13:45:56 --> Query error: Table 'library.library' doesn't exist - Invalid query: SELECT *
FROM `library`
 LIMIT 0
ERROR - 2019-02-22 13:46:08 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/CI/application/views/reset.php 33
ERROR - 2019-02-22 13:47:35 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/CI/application/views/reset.php 33
ERROR - 2019-02-22 13:50:39 --> Query error: Table 'library.email' doesn't exist - Invalid query: SELECT *
FROM `email`
WHERE `lib_user` IS NULL
ERROR - 2019-02-22 13:51:13 --> Query error: Table 'library.email' doesn't exist - Invalid query: SELECT *
FROM `email`
WHERE `lib_user` = 'email'
ERROR - 2019-02-22 13:51:44 --> Query error: Table 'library.email' doesn't exist - Invalid query: SELECT *
FROM `email`
WHERE `email` IS NULL
ERROR - 2019-02-22 13:52:08 --> Severity: Notice --> Undefined variable: email /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 14:36:15 --> Severity: Notice --> Undefined variable: email /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 14:39:13 --> Severity: Notice --> Undefined variable: email /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 14:39:14 --> Severity: Notice --> Undefined variable: email /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 14:39:14 --> Severity: Notice --> Undefined variable: email /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 14:39:14 --> Severity: Notice --> Undefined variable: email /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 14:50:14 --> Severity: Notice --> Undefined variable: email /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 14:50:15 --> Severity: Notice --> Undefined variable: email /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 14:50:34 --> Severity: Notice --> Undefined variable: email /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 14:50:35 --> Severity: Notice --> Undefined variable: email /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 14:50:35 --> Severity: Notice --> Undefined variable: email /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 15:28:35 --> Severity: Notice --> Undefined variable: mail /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 15:28:36 --> Severity: Notice --> Undefined variable: mail /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 15:28:36 --> Severity: Notice --> Undefined variable: mail /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 15:28:37 --> Severity: Notice --> Undefined variable: mail /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 15:43:59 --> Severity: Notice --> Undefined variable: mail /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 15:44:01 --> Severity: Notice --> Undefined variable: mail /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 15:44:13 --> Severity: Notice --> Undefined variable: mail /Applications/MAMP/htdocs/CI/application/views/reset.php 32
ERROR - 2019-02-22 22:43:27 --> Severity: Notice --> Undefined variable: mail /Applications/MAMP/htdocs/CI/application/views/reset.php 32
