<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-16 02:53:29 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 02:53:45 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 02:54:04 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 02:54:15 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 02:54:29 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 02:55:03 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 03:32:30 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 03:33:48 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 03:34:27 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 03:34:58 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 03:35:32 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 03:35:47 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 03:36:03 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 03:36:19 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 03:38:46 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 03:39:01 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:01:16 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:02:34 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:11:11 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:11:13 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:11:14 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:11:49 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:12:04 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:13:09 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:14:02 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:15:37 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:15:39 --> 404 Page Not Found: Home/add
ERROR - 2019-03-16 05:15:44 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:19:06 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:19:11 --> 404 Page Not Found: Home/add
ERROR - 2019-03-16 05:19:15 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:19:56 --> 404 Page Not Found: Common/css
ERROR - 2019-03-16 05:47:48 --> 404 Page Not Found: Home/add
ERROR - 2019-03-16 05:48:02 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 52
ERROR - 2019-03-16 05:49:05 --> 404 Page Not Found: Home/add
ERROR - 2019-03-16 05:59:31 --> Severity: error --> Exception: syntax error, unexpected '$author' (T_VARIABLE) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 53
ERROR - 2019-03-16 06:00:20 --> 404 Page Not Found: Home/add
ERROR - 2019-03-16 06:01:10 --> Severity: Notice --> Undefined property: Admin::$textarea /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 56
ERROR - 2019-03-16 06:01:10 --> Severity: error --> Exception: Call to a member function post() on null /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 56
ERROR - 2019-03-16 06:01:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-16 06:06:42 --> Query error: Unknown column 'barcode' in 'field list' - Invalid query: INSERT INTO `lib_admin` (`barcode`, `bookname`, `author`, `press`, `publish_date`, `content`) VALUES ('115', '时间简史', '史蒂芬·霍金', '湖南科技出版社', '2014-06-00 ', '史蒂芬·霍金的《时间简史》自1988年首版以来的岁月里，已成为全球科学著作的里程碑。它被翻译成40种文字，销售了近1000万册，成为国际出版史上的奇观。该书内容是关于宇宙本性的*前沿知识，但是从...')
ERROR - 2019-03-16 06:07:47 --> 404 Page Not Found: Home/show_books
ERROR - 2019-03-16 06:08:41 --> 404 Page Not Found: Home/show_books
ERROR - 2019-03-16 06:08:42 --> 404 Page Not Found: Home/show_books
ERROR - 2019-03-16 06:08:52 --> 404 Page Not Found: Home/show_books
ERROR - 2019-03-16 06:09:06 --> 404 Page Not Found: Home/show_books
