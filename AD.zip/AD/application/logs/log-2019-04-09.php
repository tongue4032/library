<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-09 04:50:44 --> 404 Page Not Found: Common/css
