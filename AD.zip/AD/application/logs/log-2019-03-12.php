<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-12 01:30:30 --> 404 Page Not Found: Admin/admin
ERROR - 2019-03-12 01:31:24 --> 404 Page Not Found: Admin/admin
ERROR - 2019-03-12 01:31:36 --> 404 Page Not Found: Do_login/index
ERROR - 2019-03-12 01:33:55 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-12 01:34:33 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-12 01:34:42 --> 404 Page Not Found: Admin/admin
ERROR - 2019-03-12 01:35:55 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-12 01:36:16 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-12 01:36:54 --> 404 Page Not Found: Do_login/index
ERROR - 2019-03-12 01:37:21 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-12 01:38:30 --> Severity: error --> Exception: Call to undefined function required() /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 25
ERROR - 2019-03-12 01:38:48 --> 404 Page Not Found: Common/css
ERROR - 2019-03-12 01:39:36 --> 404 Page Not Found: Admin/admin
ERROR - 2019-03-12 01:40:15 --> 404 Page Not Found: Admin/admin
ERROR - 2019-03-12 01:40:43 --> 404 Page Not Found: Do_login/index
ERROR - 2019-03-12 01:41:58 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-12 01:42:31 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-12 01:58:44 --> 404 Page Not Found: Admin/admin
ERROR - 2019-03-12 01:59:20 --> 404 Page Not Found: Logout/index
ERROR - 2019-03-12 02:00:38 --> 404 Page Not Found: Logout/index
ERROR - 2019-03-12 02:01:10 --> 404 Page Not Found: Logout/index
ERROR - 2019-03-12 02:01:51 --> 404 Page Not Found: Admin/admin
