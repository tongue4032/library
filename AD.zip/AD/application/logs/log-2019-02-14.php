<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-14 03:36:02 --> 404 Page Not Found: Style3css/index
ERROR - 2019-02-14 03:39:23 --> Severity: error --> Exception: syntax error, unexpected '" type="' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /Applications/MAMP/htdocs/CI/application/views/forget.php 19
ERROR - 2019-02-14 03:39:23 --> Severity: error --> Exception: syntax error, unexpected '" type="' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /Applications/MAMP/htdocs/CI/application/views/forget.php 19
ERROR - 2019-02-14 03:39:23 --> Severity: error --> Exception: syntax error, unexpected '" type="' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /Applications/MAMP/htdocs/CI/application/views/forget.php 19
ERROR - 2019-02-14 08:05:11 --> 404 Page Not Found: Home/css
ERROR - 2019-02-14 08:05:11 --> 404 Page Not Found: Home/Home
ERROR - 2019-02-14 08:05:11 --> 404 Page Not Found: Home/css
ERROR - 2019-02-14 08:05:22 --> 404 Page Not Found: Home/css
ERROR - 2019-02-14 08:05:22 --> 404 Page Not Found: Home/css
ERROR - 2019-02-14 08:05:22 --> 404 Page Not Found: Home/Home
ERROR - 2019-02-14 08:06:42 --> 404 Page Not Found: Home/Home
ERROR - 2019-02-14 08:06:44 --> 404 Page Not Found: Home/Home
ERROR - 2019-02-14 08:09:53 --> 404 Page Not Found: Home/Home
ERROR - 2019-02-14 08:11:02 --> 404 Page Not Found: Home/Home
