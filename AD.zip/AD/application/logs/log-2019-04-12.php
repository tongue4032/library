<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-12 06:07:20 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 06:07:25 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 06:17:55 --> Severity: Notice --> Undefined property: Admin::$amdin_model /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 320
ERROR - 2019-04-12 06:17:55 --> Severity: error --> Exception: Call to a member function get_type() on null /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 320
ERROR - 2019-04-12 06:17:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-12 06:18:12 --> Severity: error --> Exception: syntax error, unexpected ')' /Applications/MAMP/htdocs/AD/application/views/add_admins.php 112
ERROR - 2019-04-12 06:18:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-12 06:18:35 --> Severity: error --> Exception: syntax error, unexpected ')' /Applications/MAMP/htdocs/AD/application/views/add_admins.php 112
ERROR - 2019-04-12 06:18:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-12 06:19:38 --> Severity: error --> Exception: syntax error, unexpected ')' /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 06:19:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-12 06:20:12 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 06:21:40 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 06:21:40 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 06:21:41 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 06:40:05 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 06:40:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 06:40:06 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 06:58:54 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 06:58:54 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 06:58:54 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 06:59:11 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 06:59:11 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 06:59:12 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 07:00:16 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:00:16 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:00:17 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 07:00:17 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:00:17 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:00:18 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 07:42:51 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:42:51 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:42:52 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 07:43:06 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:43:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:43:06 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 07:46:12 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:46:12 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:53:22 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:53:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:54:00 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:54:16 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:56:32 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 07:56:32 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 115
ERROR - 2019-04-12 07:56:32 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 116
ERROR - 2019-04-12 07:57:08 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 07:58:37 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 115
ERROR - 2019-04-12 07:58:38 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 07:59:31 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 115
ERROR - 2019-04-12 07:59:32 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 08:01:41 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 08:01:41 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 08:01:41 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 08:02:15 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 08:02:15 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 08:02:15 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 08:02:15 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 08:02:15 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 08:02:16 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 08:02:18 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 08:02:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 08:02:19 --> 404 Page Not Found: Common/css
ERROR - 2019-04-12 14:40:22 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 14:40:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 114
ERROR - 2019-04-12 14:41:37 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 112
ERROR - 2019-04-12 14:41:37 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 112
ERROR - 2019-04-12 14:41:52 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/add_admins.php 112
ERROR - 2019-04-12 14:41:52 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/add_admins.php 112
