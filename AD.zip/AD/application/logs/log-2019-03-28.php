<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-28 04:10:57 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 25
ERROR - 2019-03-28 04:11:12 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 25
ERROR - 2019-03-28 04:11:40 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 25
ERROR - 2019-03-28 04:11:42 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 25
ERROR - 2019-03-28 04:11:50 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 25
ERROR - 2019-03-28 04:12:14 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 39
ERROR - 2019-03-28 04:12:36 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:12:40 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:12:54 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:13:01 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:13:10 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:13:32 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:13:57 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:14:00 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:14:24 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:15:14 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:15:28 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:15:35 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:15:55 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:15:59 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:16:09 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:24:03 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:25:07 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:25:07 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:25:07 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:25:07 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:25:07 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:25:07 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:25:07 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:25:07 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:25:07 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:25:07 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:25:07 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:25:07 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:25:07 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:25:27 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 144
ERROR - 2019-03-28 04:26:19 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:26:19 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:26:19 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:26:19 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:26:19 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:26:19 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:26:19 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:26:19 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:26:19 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:26:19 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:26:19 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:26:19 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:26:19 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/show_books.php 143
ERROR - 2019-03-28 04:26:48 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 04:38:16 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 33
ERROR - 2019-03-28 04:42:03 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/test.php 7
ERROR - 2019-03-28 04:42:16 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/test.php 7
ERROR - 2019-03-28 04:42:17 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/test.php 7
ERROR - 2019-03-28 04:42:22 --> 404 Page Not Found: Admin/test
ERROR - 2019-03-28 04:43:04 --> 404 Page Not Found: Admin/test
ERROR - 2019-03-28 04:43:09 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/test.php 7
ERROR - 2019-03-28 04:46:06 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 146
ERROR - 2019-03-28 05:02:05 --> Severity: Notice --> Undefined property: Admin::$test_model /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 24
ERROR - 2019-03-28 05:02:05 --> Severity: error --> Exception: Call to a member function book_select_all() on null /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 24
ERROR - 2019-03-28 05:02:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-28 05:02:17 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::where() /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 129
ERROR - 2019-03-28 05:02:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-28 05:11:39 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-28 05:11:39 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-28 05:12:55 --> 404 Page Not Found: Admin/test
ERROR - 2019-03-28 05:13:28 --> 404 Page Not Found: Admin/test
ERROR - 2019-03-28 05:14:35 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 36
ERROR - 2019-03-28 05:35:14 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 38
ERROR - 2019-03-28 05:35:14 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/test.php 7
ERROR - 2019-03-28 05:55:02 --> Severity: error --> Exception: Unsupported operand types /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php 180
ERROR - 2019-03-28 05:55:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-28 05:55:41 --> Severity: error --> Exception: Unsupported operand types /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php 180
ERROR - 2019-03-28 05:55:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-28 05:58:00 --> Severity: Notice --> Undefined property: Admin::$admin_modelmodel /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 36
ERROR - 2019-03-28 05:58:00 --> Severity: error --> Exception: Call to a member function get_all() on null /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 36
ERROR - 2019-03-28 05:58:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-28 05:58:13 --> Severity: error --> Exception: Unsupported operand types /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php 180
ERROR - 2019-03-28 05:58:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-28 06:07:50 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 06:08:31 --> 404 Page Not Found: Admin/dev.ad.com
ERROR - 2019-03-28 06:08:40 --> 404 Page Not Found: Test/page
ERROR - 2019-03-28 06:08:58 --> 404 Page Not Found: Admin/test
ERROR - 2019-03-28 06:09:10 --> 404 Page Not Found: Admin/test
ERROR - 2019-03-28 06:09:17 --> 404 Page Not Found: Admin/Admin
ERROR - 2019-03-28 06:09:31 --> 404 Page Not Found: Admin/test
ERROR - 2019-03-28 06:09:35 --> 404 Page Not Found: Admin/test
ERROR - 2019-03-28 06:10:39 --> 404 Page Not Found: Admin/test
ERROR - 2019-03-28 06:27:06 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-28 06:27:06 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 134
ERROR - 2019-03-28 06:31:17 --> Severity: Notice --> Undefined variable: limit /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 43
ERROR - 2019-03-28 06:31:45 --> Severity: Notice --> Undefined variable: limit /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 43
ERROR - 2019-03-28 06:33:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-5, 5' at line 3 - Invalid query: SELECT *
FROM `lib_bookinfo`
 LIMIT -5, 5
ERROR - 2019-03-28 06:33:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-28 06:34:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-5, 5' at line 3 - Invalid query: SELECT *
FROM `lib_bookinfo`
 LIMIT -5, 5
ERROR - 2019-03-28 06:34:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-28 06:35:58 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:40:12 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:41:49 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:41:51 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:44:49 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:45:06 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:45:45 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:46:42 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:46:47 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:46:49 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:47:49 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:47:50 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:47:53 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:47:54 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:47:55 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:47:56 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:47:57 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:47:58 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:48:59 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:49:09 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:51:58 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:52:02 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:53:35 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:53:57 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:53:59 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:54:02 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:54:39 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:54:53 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:54:55 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:55:15 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:55:29 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:55:30 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:56:21 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:56:56 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:57:06 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:57:07 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:58:27 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 06:58:50 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:00:16 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:00:19 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:01:40 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:01:43 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:08:17 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:08:26 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:08:28 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:13:33 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:13:37 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:13:43 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:13:45 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:14:38 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:14:40 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:15:23 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:44:54 --> Severity: error --> Exception: Call to undefined method Admin_model::get_all() /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 30
ERROR - 2019-03-28 07:44:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-28 07:45:48 --> Severity: Notice --> Undefined variable: users /Applications/MAMP/htdocs/AD/application/views/show_users.php 135
ERROR - 2019-03-28 07:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 135
ERROR - 2019-03-28 07:47:05 --> Severity: error --> Exception: Call to undefined method Admin_model::get_all() /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 30
ERROR - 2019-03-28 07:47:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-28 07:47:47 --> Severity: error --> Exception: Call to undefined method Admin_model::get_all() /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 30
ERROR - 2019-03-28 07:47:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-28 07:48:06 --> Severity: error --> Exception: Call to undefined method Admin_model::get_all() /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 30
ERROR - 2019-03-28 07:48:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-28 07:48:09 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:48:24 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:48:25 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:48:27 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:48:28 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:48:37 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:48:39 --> 404 Page Not Found: Common/css
ERROR - 2019-03-28 07:55:18 --> Severity: error --> Exception: Call to undefined method Admin_model::show_user() /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 317
ERROR - 2019-03-28 07:55:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
