<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-26 03:57:10 --> Severity: Warning --> A non-numeric value encountered /Applications/MAMP/htdocs/AD/application/controllers/Book.php 28
ERROR - 2019-04-26 03:57:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-7, 7' at line 3 - Invalid query: SELECT *
FROM `lib_bookinfo`
 LIMIT -7, 7
ERROR - 2019-04-26 03:57:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 03:58:16 --> Severity: Warning --> A non-numeric value encountered /Applications/MAMP/htdocs/AD/application/controllers/Book.php 28
ERROR - 2019-04-26 03:58:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-7, 7' at line 3 - Invalid query: SELECT *
FROM `lib_bookinfo`
 LIMIT -7, 7
ERROR - 2019-04-26 03:58:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 03:58:25 --> Severity: Warning --> A non-numeric value encountered /Applications/MAMP/htdocs/AD/application/controllers/Book.php 28
ERROR - 2019-04-26 03:58:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-7, 7' at line 3 - Invalid query: SELECT *
FROM `lib_bookinfo`
 LIMIT -7, 7
ERROR - 2019-04-26 03:58:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 04:06:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 04:07:27 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/Books/change.php 104
ERROR - 2019-04-26 09:28:46 --> 404 Page Not Found: Admin/role_admins
ERROR - 2019-04-26 09:28:55 --> 404 Page Not Found: Admin/role_users
ERROR - 2019-04-26 09:31:25 --> 404 Page Not Found: Admin/role_users
ERROR - 2019-04-26 14:17:19 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:19 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:20 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:20 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:20 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:20 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:20 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:21 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:21 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:21 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:21 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:21 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:21 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:42 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:42 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-26 14:17:42 --> Severity: error --> Exception: Function name must be a string /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 89
ERROR - 2019-04-26 14:17:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
