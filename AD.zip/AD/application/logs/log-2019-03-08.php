<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-08 03:02:24 --> 404 Page Not Found: Test/index
ERROR - 2019-03-08 03:09:01 --> 404 Page Not Found: Test/index
ERROR - 2019-03-08 03:09:06 --> 404 Page Not Found: Test/index
ERROR - 2019-03-08 06:42:39 --> 404 Page Not Found: Test/index
ERROR - 2019-03-08 06:44:12 --> 404 Page Not Found: TI/index
ERROR - 2019-03-08 06:55:40 --> 404 Page Not Found: IT/index
ERROR - 2019-03-08 06:58:02 --> 404 Page Not Found: IT/home
ERROR - 2019-03-08 07:04:35 --> 404 Page Not Found: IT/home
ERROR - 2019-03-08 07:36:12 --> 404 Page Not Found: IT/index
ERROR - 2019-03-08 07:43:28 --> 404 Page Not Found: IT/index
ERROR - 2019-03-08 07:44:58 --> 404 Page Not Found: IT/index
