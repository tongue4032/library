<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-18 11:30:58 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:38:15 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:41:21 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:41:37 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:42:39 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:43:48 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:43:50 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:45:22 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:45:25 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:45:26 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:46:42 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:17 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:18 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:18 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:19 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:20 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:21 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:22 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:23 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:24 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:24 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:25 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:26 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:27 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:47:27 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 11:48:13 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 12:08:58 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 12:44:52 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 12:46:08 --> 404 Page Not Found: Common/css
ERROR - 2019-03-18 14:05:58 --> Unable to load the requested class: Pagintion
ERROR - 2019-03-18 14:06:22 --> Unable to load the requested class: Pagintion
ERROR - 2019-03-18 14:06:30 --> Unable to load the requested class: Pagintion
ERROR - 2019-03-18 14:06:42 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /Applications/MAMP/htdocs/AD/application/views/show_books.php 144
ERROR - 2019-03-18 14:06:42 --> Severity: error --> Exception: Call to a member function create_links() on null /Applications/MAMP/htdocs/AD/application/views/show_books.php 144
ERROR - 2019-03-18 14:06:55 --> Severity: Notice --> Undefined property: CI_Loader::$pagination /Applications/MAMP/htdocs/AD/application/views/show_books.php 144
ERROR - 2019-03-18 14:06:55 --> Severity: error --> Exception: Call to a member function create_links() on null /Applications/MAMP/htdocs/AD/application/views/show_books.php 144
