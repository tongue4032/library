<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-04 03:40:57 --> Severity: Notice --> Undefined property: CI_Loader::$barcode /Applications/MAMP/htdocs/CI/application/views/query.php 34
ERROR - 2019-03-04 03:40:57 --> Severity: Notice --> Undefined property: CI_Loader::$bookname /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-03-04 03:40:57 --> Severity: Notice --> Undefined property: CI_Loader::$author /Applications/MAMP/htdocs/CI/application/views/query.php 36
ERROR - 2019-03-04 03:41:18 --> 404 Page Not Found: Borrow/index
ERROR - 2019-03-04 03:51:11 --> 404 Page Not Found: Borrow/index
ERROR - 2019-03-04 04:20:09 --> Severity: Notice --> Undefined variable: barcode /Applications/MAMP/htdocs/CI/application/models/User_model.php 63
ERROR - 2019-03-04 04:20:09 --> Severity: Notice --> Undefined variable: author /Applications/MAMP/htdocs/CI/application/models/User_model.php 64
ERROR - 2019-03-04 04:21:16 --> Severity: error --> Exception: Call to undefined method CI_Session::set_bookdata() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 195
ERROR - 2019-03-04 04:21:58 --> 404 Page Not Found: Home/query
ERROR - 2019-03-04 04:22:27 --> 404 Page Not Found: Borrow/index
ERROR - 2019-03-04 04:26:47 --> 404 Page Not Found: Borrow/index
ERROR - 2019-03-04 04:27:43 --> 404 Page Not Found: Borrow/index
ERROR - 2019-03-04 04:37:35 --> 404 Page Not Found: Borrow/index
ERROR - 2019-03-04 07:16:50 --> 404 Page Not Found: Borrow/index
ERROR - 2019-03-04 07:35:56 --> 404 Page Not Found: Borrow/index
ERROR - 2019-03-04 08:59:20 --> 404 Page Not Found: Homepage/index
ERROR - 2019-03-04 09:08:55 --> 404 Page Not Found: Borrow/index
ERROR - 2019-03-04 10:11:55 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF) /Applications/MAMP/htdocs/CI/application/views/query.php 43
ERROR - 2019-03-04 10:12:15 --> Severity: error --> Exception: syntax error, unexpected ':' /Applications/MAMP/htdocs/CI/application/views/query.php 43
ERROR - 2019-03-04 10:12:24 --> Severity: error --> Exception: syntax error, unexpected end of file /Applications/MAMP/htdocs/CI/application/views/query.php 54
ERROR - 2019-03-04 10:12:36 --> Severity: error --> Exception: syntax error, unexpected end of file /Applications/MAMP/htdocs/CI/application/views/query.php 53
ERROR - 2019-03-04 10:12:53 --> Severity: error --> Exception: syntax error, unexpected ':' /Applications/MAMP/htdocs/CI/application/views/query.php 43
ERROR - 2019-03-04 10:13:00 --> Severity: error --> Exception: syntax error, unexpected end of file /Applications/MAMP/htdocs/CI/application/views/query.php 53
ERROR - 2019-03-04 10:14:02 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /Applications/MAMP/htdocs/CI/application/views/query.php 37
ERROR - 2019-03-04 10:14:08 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /Applications/MAMP/htdocs/CI/application/views/query.php 37
ERROR - 2019-03-04 10:15:55 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) /Applications/MAMP/htdocs/CI/application/views/query.php 38
ERROR - 2019-03-04 10:17:04 --> 404 Page Not Found: Borrow/index
ERROR - 2019-03-04 10:17:53 --> 404 Page Not Found: Borrow/index
ERROR - 2019-03-04 10:18:05 --> 404 Page Not Found: Borrow/index
ERROR - 2019-03-04 11:54:07 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/CI/application/views/query.php 39
ERROR - 2019-03-04 11:54:07 --> Severity: Notice --> Undefined index: bookname /Applications/MAMP/htdocs/CI/application/views/query.php 40
ERROR - 2019-03-04 11:54:07 --> Severity: Notice --> Undefined index: author /Applications/MAMP/htdocs/CI/application/views/query.php 41
ERROR - 2019-03-04 11:58:27 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-03-04 11:58:27 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-03-04 12:00:18 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-03-04 12:00:18 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-03-04 12:00:21 --> Severity: Notice --> Undefined variable: books /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-03-04 12:00:21 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/CI/application/views/query.php 35
ERROR - 2019-03-04 12:02:04 --> Severity: error --> Exception: Call to undefined method Home::load_view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 197
ERROR - 2019-03-04 12:02:45 --> Severity: error --> Exception: Call to undefined method Home::load_view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 197
ERROR - 2019-03-04 12:02:58 --> Severity: error --> Exception: Call to undefined method Home::load_view() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 197
