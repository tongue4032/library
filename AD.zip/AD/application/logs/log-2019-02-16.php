<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-16 04:02:43 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-16 04:02:43 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-16 04:03:09 --> 404 Page Not Found: Home/main.css
ERROR - 2019-02-16 04:03:09 --> 404 Page Not Found: Home/main.js
ERROR - 2019-02-16 04:39:17 --> 404 Page Not Found: Home/main.css
ERROR - 2019-02-16 04:39:17 --> 404 Page Not Found: Home/main.js
ERROR - 2019-02-16 04:47:55 --> 404 Page Not Found: Home/main.css
ERROR - 2019-02-16 04:47:55 --> 404 Page Not Found: Home/main.js
ERROR - 2019-02-16 04:48:21 --> 404 Page Not Found: Home/home
ERROR - 2019-02-16 04:49:33 --> 404 Page Not Found: Home/home
ERROR - 2019-02-16 04:49:38 --> 404 Page Not Found: Maincss/index
ERROR - 2019-02-16 04:49:38 --> 404 Page Not Found: Mainjs/index
ERROR - 2019-02-16 04:50:08 --> 404 Page Not Found: Home/main.js
ERROR - 2019-02-16 04:50:08 --> 404 Page Not Found: Home/main.css
ERROR - 2019-02-16 04:54:08 --> 404 Page Not Found: Home/main.js
ERROR - 2019-02-16 04:54:08 --> 404 Page Not Found: Home/main.css
ERROR - 2019-02-16 04:54:23 --> 404 Page Not Found: Home/main.css
ERROR - 2019-02-16 04:56:07 --> 404 Page Not Found: Home/main.css
ERROR - 2019-02-16 04:56:07 --> 404 Page Not Found: Home/main.js
ERROR - 2019-02-16 04:56:09 --> 404 Page Not Found: Home/main.js
ERROR - 2019-02-16 04:56:09 --> 404 Page Not Found: Home/main.css
ERROR - 2019-02-16 05:45:47 --> 404 Page Not Found: Home/%E2%80%8E%E2%81%A8..
ERROR - 2019-02-16 05:45:48 --> 404 Page Not Found: Home/%E2%80%8E%E2%81%A8..
ERROR - 2019-02-16 05:46:56 --> 404 Page Not Found: Home/%E2%80%8E%E2%81%A8..
ERROR - 2019-02-16 05:47:28 --> 404 Page Not Found: Home/%E2%80%8E%E2%81%A8.
ERROR - 2019-02-16 05:49:48 --> 404 Page Not Found: Home/%E2%80%8E%E2%81%A8.
