<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-03 03:26:19 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 03:27:16 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 03:27:29 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 03:27:29 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 03:28:42 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 03:28:44 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 03:28:49 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 03:29:56 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 03:31:07 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 03:37:00 --> Severity: Notice --> Use of undefined constant console - assumed 'console' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 143
ERROR - 2019-04-03 03:43:19 --> Severity: error --> Exception: syntax error, unexpected '123' (T_LNUMBER), expecting ',' or ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 143
ERROR - 2019-04-03 04:26:51 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:27:57 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:29:06 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:29:26 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:29:31 --> 404 Page Not Found: Admin/Admin
ERROR - 2019-04-03 04:29:53 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:29:57 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:30:13 --> 404 Page Not Found: Admin/Admin
ERROR - 2019-04-03 04:31:06 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:31:58 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:32:13 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:40:30 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ',' or ')' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 196
ERROR - 2019-04-03 04:41:01 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 196
ERROR - 2019-04-03 04:44:49 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:44:52 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:45:09 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:45:19 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:45:30 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:45:32 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:45:34 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:45:36 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:45:42 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:45:45 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:45:47 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:45:53 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 04:45:55 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 05:14:46 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 214
ERROR - 2019-04-03 05:15:58 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 214
ERROR - 2019-04-03 05:19:54 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 05:20:01 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 05:20:10 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 05:20:12 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 05:27:07 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 05:27:11 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 05:27:20 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 05:27:23 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 05:28:11 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:12:15 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:12:17 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:12:20 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:12:32 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:12:34 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:17:27 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:17:30 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:17:32 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:17:36 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:21:22 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 335
ERROR - 2019-04-03 08:22:47 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:22:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:22:54 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:22:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:22:57 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:22:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:22:58 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:22:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:22:59 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:22:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:23:00 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:23:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:23:03 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:23:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:23:06 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:23:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:23:54 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:23:57 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:23:58 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:23:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:24:02 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:24:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:24:05 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:24:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:24:07 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:24:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:24:09 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:24:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:35 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:36 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:37 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:38 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:38 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:38 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:39 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:39 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:39 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:39 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:40 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:40 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:40 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:40 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:40 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:41 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:41 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:41 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:41 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:41 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:42 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:42 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:42 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:42 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:43 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:43 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:43 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:43 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:43 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:44 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:44 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:44 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:45 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:47 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:48 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:48 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:48 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:48 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:49 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:49 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:49 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:49 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:49 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:50 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:50 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:50 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:50 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:51 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:51 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:51 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:51 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:52 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:52 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:52 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:52 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:53 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:53 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:53 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:53 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:53 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:54 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:54 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:54 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:54 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:55 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:55 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:55 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:55 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:56 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:56 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:56 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:28:57 --> Query error: Column 'admin_name' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`, `professional`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL)
ERROR - 2019-04-03 08:28:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-03 08:29:24 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:30:47 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:31:06 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:31:13 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 08:31:15 --> 404 Page Not Found: Common/css
ERROR - 2019-04-03 09:31:01 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 416
ERROR - 2019-04-03 10:12:44 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 494
ERROR - 2019-04-03 10:12:46 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 494
ERROR - 2019-04-03 10:12:50 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 494
ERROR - 2019-04-03 10:12:51 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 494
ERROR - 2019-04-03 10:12:52 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 494
ERROR - 2019-04-03 10:12:52 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 494
ERROR - 2019-04-03 10:12:54 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 494
ERROR - 2019-04-03 10:12:56 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 494
ERROR - 2019-04-03 10:13:08 --> Severity: error --> Exception: syntax error, unexpected '；' (T_STRING), expecting ',' or ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 493
ERROR - 2019-04-03 10:15:00 --> 404 Page Not Found: Admin/login
