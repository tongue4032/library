<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-15 04:09:12 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 344
ERROR - 2019-04-15 04:09:13 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 344
ERROR - 2019-04-15 04:09:14 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 344
ERROR - 2019-04-15 04:09:14 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 344
ERROR - 2019-04-15 04:57:38 --> Query error: Unknown column 'role_id' in 'field list' - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `role_id`) VALUES ('admin14', '0192023a7bbd73250516f069df18b500', 'Administrator ')
ERROR - 2019-04-15 04:57:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-15 05:05:08 --> Severity: Notice --> Undefined variable: role_id /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 342
ERROR - 2019-04-15 05:05:08 --> Query error: Column 'professional' cannot be null - Invalid query: INSERT INTO `lib_admin` (`admin_name`, `admin_pwd`, `professional`) VALUES ('admin14', '0192023a7bbd73250516f069df18b500', NULL)
ERROR - 2019-04-15 05:05:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-15 05:06:04 --> Severity: Notice --> Undefined variable: role_id /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 342
ERROR - 2019-04-15 05:26:19 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 05:27:03 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 05:28:00 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 05:40:07 --> Severity: Notice --> Undefined property: Admin::$amdin_model /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 410
ERROR - 2019-04-15 05:40:07 --> Severity: error --> Exception: Call to a member function get_userType() on null /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 410
ERROR - 2019-04-15 05:40:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-15 05:42:59 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/roles.php 113
ERROR - 2019-04-15 05:42:59 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/roles.php 113
ERROR - 2019-04-15 05:44:05 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/roles.php 113
ERROR - 2019-04-15 05:44:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/roles.php 113
ERROR - 2019-04-15 05:45:13 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/views/roles.php 113
ERROR - 2019-04-15 05:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/roles.php 113
ERROR - 2019-04-15 08:44:03 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 411
ERROR - 2019-04-15 08:46:47 --> Severity: Notice --> Undefined variable: type /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 411
ERROR - 2019-04-15 08:57:40 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:57:40 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:57:45 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:57:45 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:51 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:51 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:53 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:53 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:53 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:53 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:53 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:53 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:53 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:53 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:53 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:53 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:59 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 08:59:59 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:30 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:30 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:31 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:31 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:31 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:31 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:32 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:32 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:32 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:32 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:32 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:32 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:33 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:33 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:33 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:33 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:33 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:33 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:33 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:03:33 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:05:24 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:05:24 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/views/role.php 115
ERROR - 2019-04-15 09:05:24 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/views/role.php 115
ERROR - 2019-04-15 09:05:24 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:05:24 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/views/role.php 115
ERROR - 2019-04-15 09:05:24 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/views/role.php 115
ERROR - 2019-04-15 09:06:15 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:06:15 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:06:30 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:06:30 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:06:32 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 09:06:37 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 09:06:49 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:06:49 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:06:51 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 09:08:41 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:08:41 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/role.php 114
ERROR - 2019-04-15 09:45:45 --> 404 Page Not Found: Admin/modify_name
ERROR - 2019-04-15 09:53:15 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 09:54:22 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 09:55:32 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 09:56:34 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 09:56:52 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 09:57:09 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 10:10:53 --> Severity: Notice --> Undefined variable: professional /Applications/MAMP/htdocs/AD/application/views/modifyAdmin.php 108
ERROR - 2019-04-15 10:10:53 --> Severity: Notice --> Undefined variable: admin_name /Applications/MAMP/htdocs/AD/application/views/modifyAdmin.php 113
ERROR - 2019-04-15 10:10:53 --> Severity: Notice --> Undefined variable: admin_pwd /Applications/MAMP/htdocs/AD/application/views/modifyAdmin.php 115
ERROR - 2019-04-15 10:11:49 --> Severity: Notice --> Undefined variable: admin_name /Applications/MAMP/htdocs/AD/application/views/modifyAdmin.php 113
ERROR - 2019-04-15 10:11:49 --> Severity: Notice --> Undefined variable: admin_pwd /Applications/MAMP/htdocs/AD/application/views/modifyAdmin.php 115
ERROR - 2019-04-15 10:23:35 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 493
ERROR - 2019-04-15 10:28:20 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 11:33:45 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 11:33:46 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 11:33:56 --> 404 Page Not Found: Common/css
ERROR - 2019-04-15 11:34:12 --> 404 Page Not Found: Common/css
