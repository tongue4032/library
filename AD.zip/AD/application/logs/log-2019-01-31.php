<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-31 17:09:02 --> 404 Page Not Found: Home/yanzhengma
ERROR - 2019-01-31 17:09:04 --> 404 Page Not Found: Home/yanzhengma
ERROR - 2019-01-31 17:10:19 --> 404 Page Not Found: Register/yanzhengma
ERROR - 2019-01-31 17:10:20 --> 404 Page Not Found: Register/yanzhengma
ERROR - 2019-01-31 17:10:26 --> 404 Page Not Found: Register/yanzhengma
ERROR - 2019-01-31 17:10:33 --> 404 Page Not Found: Login/yanzhengma
ERROR - 2019-01-31 17:15:58 --> 404 Page Not Found: Register/yanzhengma
ERROR - 2019-01-31 17:15:59 --> 404 Page Not Found: Register/yanzhengma
ERROR - 2019-01-31 17:15:59 --> 404 Page Not Found: Register/yanzhengma
ERROR - 2019-01-31 17:15:59 --> 404 Page Not Found: Register/yanzhengma
ERROR - 2019-01-31 17:15:59 --> 404 Page Not Found: Register/yanzhengma
ERROR - 2019-01-31 17:25:09 --> 404 Page Not Found: Home/yanzhengma
ERROR - 2019-01-31 17:25:09 --> 404 Page Not Found: Home/yanzhengma
ERROR - 2019-01-31 17:25:10 --> 404 Page Not Found: Home/yanzhengma
