<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-26 03:27:32 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:28:02 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:28:40 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:29:03 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:30:05 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:30:07 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:30:22 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:30:56 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:31:00 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:32:43 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:34:22 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:36:51 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:36:55 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:37:25 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:38:08 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:38:20 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:38:52 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:39:30 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:41:30 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:41:49 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:43:25 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:43:35 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:44:05 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:44:33 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:44:50 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:46:42 --> 404 Page Not Found: Common/images
ERROR - 2019-03-26 03:46:44 --> 404 Page Not Found: Common/images
ERROR - 2019-03-26 03:46:46 --> 404 Page Not Found: Common/images
ERROR - 2019-03-26 03:48:01 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:48:15 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:48:25 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:48:40 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:49:10 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:49:18 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:50:42 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:53:21 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:53:36 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:54:28 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:56:10 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:56:23 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:56:50 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:57:36 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:57:44 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:58:02 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:58:04 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:59:04 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:59:30 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 03:59:58 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 04:00:42 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 04:01:04 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 04:01:10 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 04:01:15 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 04:01:38 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 04:02:50 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 04:03:56 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 04:04:43 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 04:10:04 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 04:11:29 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 04:11:31 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 04:11:51 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 05:02:27 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 05:03:52 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 05:04:01 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 05:04:17 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 05:04:29 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 05:05:49 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 05:06:18 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 05:06:25 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 05:08:16 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 05:08:39 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 05:35:57 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 06:02:18 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 06:03:22 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 06:03:38 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 06:03:50 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 06:04:46 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 06:05:07 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 07:15:27 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 07:15:43 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 07:16:33 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 07:16:44 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 07:16:55 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 07:17:28 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 07:17:42 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 07:18:03 --> 404 Page Not Found: Common/css
ERROR - 2019-03-26 07:58:28 --> 404 Page Not Found: Admin/js
ERROR - 2019-03-26 07:58:28 --> 404 Page Not Found: Followjs/index
ERROR - 2019-03-26 07:58:28 --> 404 Page Not Found: Admin/js
ERROR - 2019-03-26 07:58:28 --> 404 Page Not Found: Followjs/index
ERROR - 2019-03-26 07:58:30 --> 404 Page Not Found: Admin/js
ERROR - 2019-03-26 07:58:30 --> 404 Page Not Found: Followjs/index
ERROR - 2019-03-26 07:58:30 --> 404 Page Not Found: Admin/js
ERROR - 2019-03-26 07:58:30 --> 404 Page Not Found: Followjs/index
ERROR - 2019-03-26 08:00:35 --> 404 Page Not Found: Admin/js
ERROR - 2019-03-26 08:00:35 --> 404 Page Not Found: Followjs/index
ERROR - 2019-03-26 08:00:35 --> 404 Page Not Found: Admin/js
ERROR - 2019-03-26 08:00:35 --> 404 Page Not Found: Followjs/index
ERROR - 2019-03-26 08:02:30 --> 404 Page Not Found: Admin/js
ERROR - 2019-03-26 08:02:30 --> 404 Page Not Found: Followjs/index
ERROR - 2019-03-26 08:02:30 --> 404 Page Not Found: Admin/js
ERROR - 2019-03-26 08:02:30 --> 404 Page Not Found: Followjs/index
ERROR - 2019-03-26 09:40:23 --> Severity: Notice --> Undefined index: create_date /Applications/MAMP/htdocs/AD/application/views/admin_info.php 148
ERROR - 2019-03-26 09:52:58 --> 404 Page Not Found: Admin/modify_name
ERROR - 2019-03-26 09:53:16 --> 404 Page Not Found: Admin/modify_name
ERROR - 2019-03-26 09:57:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/controllers/Admin.php:343) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-26 09:57:33 --> Severity: Compile Error --> Cannot redeclare Admin::change_book() /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 343
ERROR - 2019-03-26 09:57:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/controllers/Admin.php:366) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-26 09:57:58 --> Severity: Compile Error --> Cannot redeclare Admin::change_book() /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 366
ERROR - 2019-03-26 09:58:56 --> Severity: Notice --> Undefined variable: barcode /Applications/MAMP/htdocs/AD/application/views/modify_name.php 129
ERROR - 2019-03-26 09:58:56 --> Severity: Notice --> Undefined variable: bookname /Applications/MAMP/htdocs/AD/application/views/modify_name.php 131
ERROR - 2019-03-26 09:58:56 --> Severity: Notice --> Undefined variable: author /Applications/MAMP/htdocs/AD/application/views/modify_name.php 136
ERROR - 2019-03-26 09:58:56 --> Severity: Notice --> Undefined variable: press /Applications/MAMP/htdocs/AD/application/views/modify_name.php 138
ERROR - 2019-03-26 09:58:56 --> Severity: Notice --> Undefined variable: publish_date /Applications/MAMP/htdocs/AD/application/views/modify_name.php 143
ERROR - 2019-03-26 10:01:08 --> Severity: Notice --> Undefined variable: barcode /Applications/MAMP/htdocs/AD/application/views/modify_name.php 129
ERROR - 2019-03-26 10:01:08 --> Severity: Notice --> Undefined variable: bookname /Applications/MAMP/htdocs/AD/application/views/modify_name.php 131
ERROR - 2019-03-26 10:01:08 --> Severity: Notice --> Undefined variable: author /Applications/MAMP/htdocs/AD/application/views/modify_name.php 136
ERROR - 2019-03-26 10:01:08 --> Severity: Notice --> Undefined variable: press /Applications/MAMP/htdocs/AD/application/views/modify_name.php 138
ERROR - 2019-03-26 10:01:08 --> Severity: Notice --> Undefined variable: publish_date /Applications/MAMP/htdocs/AD/application/views/modify_name.php 143
ERROR - 2019-03-26 10:01:21 --> Severity: Notice --> Undefined variable: bookname /Applications/MAMP/htdocs/AD/application/views/modify_name.php 131
ERROR - 2019-03-26 10:01:21 --> Severity: Notice --> Undefined variable: author /Applications/MAMP/htdocs/AD/application/views/modify_name.php 136
ERROR - 2019-03-26 10:01:21 --> Severity: Notice --> Undefined variable: press /Applications/MAMP/htdocs/AD/application/views/modify_name.php 138
ERROR - 2019-03-26 10:01:21 --> Severity: Notice --> Undefined variable: publish_date /Applications/MAMP/htdocs/AD/application/views/modify_name.php 143
ERROR - 2019-03-26 10:01:33 --> Severity: Notice --> Undefined variable: author /Applications/MAMP/htdocs/AD/application/views/modify_name.php 136
ERROR - 2019-03-26 10:01:33 --> Severity: Notice --> Undefined variable: press /Applications/MAMP/htdocs/AD/application/views/modify_name.php 138
ERROR - 2019-03-26 10:01:33 --> Severity: Notice --> Undefined variable: publish_date /Applications/MAMP/htdocs/AD/application/views/modify_name.php 143
ERROR - 2019-03-26 10:07:06 --> 404 Page Not Found: Admin/do_modify
ERROR - 2019-03-26 10:11:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='' author='' press='' publish_date=''' at line 1 - Invalid query: update lib_bookinfo set barcode='' bookname='' author='' press='' publish_date=''
