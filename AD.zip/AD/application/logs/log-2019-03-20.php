<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-20 06:20:30 --> Severity: Notice --> Undefined variable: data /Applications/MAMP/htdocs/AD/application/views/change.php 129
ERROR - 2019-03-20 06:24:25 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 06:24:50 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 06:26:54 --> Query error: Table 'library.content' doesn't exist - Invalid query: SELECT *
FROM `content`
ERROR - 2019-03-20 06:27:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 06:33:52 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 06:42:51 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 06:43:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 06:46:27 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 06:50:23 --> 404 Page Not Found: Admin/change
ERROR - 2019-03-20 06:54:22 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 07:32:57 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 07:33:24 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 07:33:26 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 07:33:26 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 07:33:40 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 07:42:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-20 08:03:20 --> Severity: Notice --> Undefined property: Admin::$user_model /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 106
ERROR - 2019-03-20 08:03:20 --> Severity: error --> Exception: Call to a member function change() on null /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 106
ERROR - 2019-03-20 08:03:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-20 08:03:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date=''
ERROR - 2019-03-20 08:06:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date=''where barcode='114'
ERROR - 2019-03-20 08:07:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date=''where 'lib_bookinfo''
ERROR - 2019-03-20 08:07:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date='' where 'lib_bookinfo''
ERROR - 2019-03-20 08:08:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date=''
ERROR - 2019-03-20 08:09:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date='2011-08-09'
ERROR - 2019-03-20 08:10:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date='2011-08-09' where lib_bookinfo'
ERROR - 2019-03-20 08:11:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date='2011-08-09' where lib_bookinfo114'
ERROR - 2019-03-20 08:12:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date='2011-08-09' where lib_bookinfo='114'
ERROR - 2019-03-20 08:12:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date='2011-08-09' where barcode='114'
ERROR - 2019-03-20 08:13:06 --> Severity: Notice --> Undefined variable: token /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 30
ERROR - 2019-03-20 08:13:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date='2011-08-09' where barcode=''
ERROR - 2019-03-20 08:13:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-20 12:17:33 --> Severity: error --> Exception: Too few arguments to function Admin_model::change(), 1 passed in /Applications/MAMP/htdocs/AD/application/controllers/Admin.php on line 106 and exactly 2 expected /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 29
ERROR - 2019-03-20 12:39:54 --> Severity: error --> Exception: Too few arguments to function Admin_model::change(), 1 passed in /Applications/MAMP/htdocs/AD/application/controllers/Admin.php on line 106 and exactly 2 expected /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 29
ERROR - 2019-03-20 12:40:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date='2011-08-09' where barcode='5171'
ERROR - 2019-03-20 12:40:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='忘得睡' press='瞎蒙人民出版社' publish_date='2011-08-09'
ERROR - 2019-03-20 12:55:54 --> Severity: Notice --> Undefined variable: admin_id /Applications/MAMP/htdocs/AD/application/views/admin_info.php 128
ERROR - 2019-03-20 12:56:07 --> Severity: Notice --> Undefined variable: admin_id /Applications/MAMP/htdocs/AD/application/views/admin_info.php 128
ERROR - 2019-03-20 13:03:26 --> 404 Page Not Found: Common/css
ERROR - 2019-03-20 13:05:02 --> 404 Page Not Found: Common/css
ERROR - 2019-03-20 13:26:37 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:26:37 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:27:26 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:27:26 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:30:34 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:30:34 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:39:05 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:40:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:40:22 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:40:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:40:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:40:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:40:32 --> Severity: Notice --> Undefined variable: users /Applications/MAMP/htdocs/AD/application/views/show_users.php 135
ERROR - 2019-03-20 13:40:32 --> Severity: Notice --> Undefined variable: users /Applications/MAMP/htdocs/AD/application/views/show_users.php 136
ERROR - 2019-03-20 13:40:32 --> Severity: Notice --> Undefined variable: users /Applications/MAMP/htdocs/AD/application/views/show_users.php 137
ERROR - 2019-03-20 13:40:32 --> Severity: Notice --> Undefined variable: users /Applications/MAMP/htdocs/AD/application/views/show_users.php 138
ERROR - 2019-03-20 13:40:32 --> Severity: Notice --> Undefined variable: users /Applications/MAMP/htdocs/AD/application/views/show_users.php 139
ERROR - 2019-03-20 13:40:32 --> Severity: Notice --> Undefined variable: users /Applications/MAMP/htdocs/AD/application/views/show_users.php 140
ERROR - 2019-03-20 13:40:32 --> Severity: Notice --> Undefined variable: users /Applications/MAMP/htdocs/AD/application/views/show_users.php 140
ERROR - 2019-03-20 13:40:32 --> Severity: Notice --> Undefined variable: users /Applications/MAMP/htdocs/AD/application/views/show_users.php 140
ERROR - 2019-03-20 13:40:32 --> Severity: Notice --> Undefined variable: users /Applications/MAMP/htdocs/AD/application/views/show_users.php 140
ERROR - 2019-03-20 13:40:32 --> Severity: Notice --> Undefined variable: users /Applications/MAMP/htdocs/AD/application/views/show_users.php 140
ERROR - 2019-03-20 13:41:41 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:42:11 --> Severity: error --> Exception: syntax error, unexpected '<' /Applications/MAMP/htdocs/AD/application/views/show_users.php 136
ERROR - 2019-03-20 13:42:19 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
ERROR - 2019-03-20 13:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_users.php 134
