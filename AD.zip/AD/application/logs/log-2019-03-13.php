<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-13 07:12:08 --> 404 Page Not Found: Admin/admin
ERROR - 2019-03-13 07:43:43 --> 404 Page Not Found: Common/css
ERROR - 2019-03-13 07:43:49 --> 404 Page Not Found: Admin/admin
ERROR - 2019-03-13 07:44:22 --> 404 Page Not Found: Admin/admin
ERROR - 2019-03-13 07:44:32 --> 404 Page Not Found: Logout/index
ERROR - 2019-03-13 07:45:33 --> 404 Page Not Found: Admin/admin
ERROR - 2019-03-13 07:46:11 --> 404 Page Not Found: Admin/admin
ERROR - 2019-03-13 07:55:23 --> 404 Page Not Found: Common/css
ERROR - 2019-03-13 07:56:10 --> 404 Page Not Found: Common/css
ERROR - 2019-03-13 07:56:39 --> 404 Page Not Found: Common/css
ERROR - 2019-03-13 08:00:26 --> 404 Page Not Found: Admin/admin-info
ERROR - 2019-03-13 08:00:46 --> 404 Page Not Found: Admin/admin-info
ERROR - 2019-03-13 08:00:48 --> 404 Page Not Found: Admin/admin-info
ERROR - 2019-03-13 08:01:08 --> 404 Page Not Found: Admin/ui-elements.html
ERROR - 2019-03-13 08:02:24 --> 404 Page Not Found: Common/css
ERROR - 2019-03-13 08:05:42 --> 404 Page Not Found: Admin/empty.html
ERROR - 2019-03-13 08:19:45 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/index.php 79
ERROR - 2019-03-13 08:43:36 --> 404 Page Not Found: Common/css
ERROR - 2019-03-13 08:43:49 --> 404 Page Not Found: Common/css
ERROR - 2019-03-13 08:44:06 --> 404 Page Not Found: Common/css
