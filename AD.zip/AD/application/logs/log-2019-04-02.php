<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-02 04:29:33 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 04:29:33 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 04:29:33 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 123
ERROR - 2019-04-02 04:29:55 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 04:29:55 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 04:29:55 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 123
ERROR - 2019-04-02 04:31:02 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 04:31:02 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 04:31:02 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 123
ERROR - 2019-04-02 04:36:23 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 04:36:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 04:36:23 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 123
ERROR - 2019-04-02 04:42:35 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:44:19 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:45:07 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:45:09 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:45:38 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:48:41 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:49:36 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:49:38 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:50:09 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:50:44 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:51:00 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:51:01 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:51:02 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:51:03 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:51:04 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:51:05 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:51:05 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 04:51:17 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 05:01:21 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 05:02:24 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 05:02:25 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 05:02:26 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 05:02:27 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 05:02:27 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 05:02:28 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 05:02:29 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 05:02:50 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 05:02:51 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 05:02:52 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 05:02:53 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 05:02:53 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 09:40:32 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 09:40:32 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 09:40:32 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 123
ERROR - 2019-04-02 09:42:09 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 09:42:09 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 09:42:09 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 123
ERROR - 2019-04-02 09:42:58 --> Severity: Notice --> Undefined variable: page_size /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 143
ERROR - 2019-04-02 09:42:58 --> Severity: Notice --> Undefined variable: offset /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 143
ERROR - 2019-04-02 09:42:58 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 09:42:58 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/show_books.php 110
ERROR - 2019-04-02 09:42:58 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 123
ERROR - 2019-04-02 09:43:08 --> Severity: error --> Exception: Too few arguments to function Admin_model::book_select_all(), 0 passed in /Applications/MAMP/htdocs/AD/application/controllers/Admin.php on line 143 and exactly 2 expected /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 128
ERROR - 2019-04-02 09:43:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-02 09:44:37 --> Severity: Notice --> Undefined variable: page_size /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 143
ERROR - 2019-04-02 09:44:37 --> Severity: Notice --> Undefined variable: offset /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 143
ERROR - 2019-04-02 09:44:37 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 123
ERROR - 2019-04-02 09:46:03 --> Severity: Notice --> Undefined variable: link /Applications/MAMP/htdocs/AD/application/views/show_books.php 123
ERROR - 2019-04-02 09:53:00 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 09:53:47 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 09:54:29 --> 404 Page Not Found: Common/css
ERROR - 2019-04-02 09:55:30 --> 404 Page Not Found: Common/css
