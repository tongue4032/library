<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-25 08:33:33 --> 404 Page Not Found: Admin/role_users
ERROR - 2019-04-25 08:33:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 08:58:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 08:59:21 --> Severity: Notice --> Undefined property: Secure::$admin_model /Applications/MAMP/htdocs/AD/application/controllers/Secure.php 25
ERROR - 2019-04-25 08:59:21 --> Severity: error --> Exception: Call to a member function get_user() on null /Applications/MAMP/htdocs/AD/application/controllers/Secure.php 25
ERROR - 2019-04-25 08:59:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 09:00:32 --> 404 Page Not Found: Secure/Secure
ERROR - 2019-04-25 09:00:45 --> 404 Page Not Found: Secure/Secure
ERROR - 2019-04-25 09:00:50 --> 404 Page Not Found: Secure/Secure
ERROR - 2019-04-25 09:01:06 --> 404 Page Not Found: Secure/Secure
ERROR - 2019-04-25 09:23:36 --> 404 Page Not Found: Admin/show_books
ERROR - 2019-04-25 09:23:41 --> Query error: Table 'library.tbl_admin' doesn't exist - Invalid query: select count(*) as total from TBL_ADMIN
ERROR - 2019-04-25 09:23:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 09:25:46 --> 404 Page Not Found: Admins/show_admins
ERROR - 2019-04-25 09:25:51 --> 404 Page Not Found: Admins/show_admins
ERROR - 2019-04-25 09:25:58 --> 404 Page Not Found: Admin/show_books
ERROR - 2019-04-25 09:26:24 --> 404 Page Not Found: Admin/show_books
ERROR - 2019-04-25 09:29:05 --> 404 Page Not Found: Admin/Home
ERROR - 2019-04-25 09:36:38 --> Severity: error --> Exception: Call to undefined method Admin_model::get_type() /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 107
ERROR - 2019-04-25 09:36:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 09:38:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 09:39:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 09:39:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 09:40:27 --> 404 Page Not Found: Admin/Home
ERROR - 2019-04-25 09:40:34 --> 404 Page Not Found: Admin/Home
ERROR - 2019-04-25 09:40:39 --> 404 Page Not Found: Admin/Home
ERROR - 2019-04-25 09:41:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 09:42:22 --> Severity: Notice --> Undefined property: Book::$admin_model /Applications/MAMP/htdocs/AD/application/controllers/Book.php 29
ERROR - 2019-04-25 09:42:22 --> Severity: error --> Exception: Call to a member function get_all() on null /Applications/MAMP/htdocs/AD/application/controllers/Book.php 29
ERROR - 2019-04-25 09:42:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 09:43:10 --> Query error: Table 'library.tbl_bookinfo' doesn't exist - Invalid query: select count(*) as total from TBl_BOOKINFO
ERROR - 2019-04-25 09:43:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 09:43:30 --> 404 Page Not Found: Admin/add_book
ERROR - 2019-04-25 09:43:44 --> 404 Page Not Found: Admin/Home
ERROR - 2019-04-25 09:45:09 --> 404 Page Not Found: Admin/role_users
ERROR - 2019-04-25 09:55:28 --> 404 Page Not Found: Books/show_books
ERROR - 2019-04-25 11:06:42 --> 404 Page Not Found: Admin/admin_info
ERROR - 2019-04-25 11:07:25 --> Query error: Table 'library.tbl_user' doesn't exist - Invalid query: select count(*) as total from TBL_USER
ERROR - 2019-04-25 11:07:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 11:20:23 --> 404 Page Not Found: User/show_books
ERROR - 2019-04-25 11:21:22 --> 404 Page Not Found: Users/show_books
ERROR - 2019-04-25 11:21:39 --> 404 Page Not Found: Users/show_books
ERROR - 2019-04-25 11:21:55 --> 404 Page Not Found: Users/show_books
ERROR - 2019-04-25 11:22:01 --> 404 Page Not Found: Users/show_books
ERROR - 2019-04-25 11:22:29 --> 404 Page Not Found: Users/show_books
ERROR - 2019-04-25 11:22:32 --> 404 Page Not Found: Books/show_books
ERROR - 2019-04-25 11:23:12 --> 404 Page Not Found: Books/show_books
ERROR - 2019-04-25 11:23:32 --> 404 Page Not Found: Admin/show_books
ERROR - 2019-04-25 11:25:27 --> Query error: Table 'library.tbl_user' doesn't exist - Invalid query: select count(*) as total from TBL_USER
ERROR - 2019-04-25 11:25:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 11:26:01 --> 404 Page Not Found: Admin/show_users
ERROR - 2019-04-25 11:27:39 --> Severity: error --> Exception: Call to undefined method Permission_model::get_user_all() /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 23
ERROR - 2019-04-25 11:27:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 11:29:16 --> Severity: error --> Exception: Call to undefined method Permission_model::user_select_all() /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 31
ERROR - 2019-04-25 11:29:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 11:30:48 --> 404 Page Not Found: Permission/role_users
ERROR - 2019-04-25 11:31:24 --> Severity: error --> Exception: Call to undefined method Permission_model::get_admin_all() /Applications/MAMP/htdocs/AD/application/controllers/Permissions.php 45
ERROR - 2019-04-25 11:31:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-25 11:32:19 --> 404 Page Not Found: Permission/role_admins
ERROR - 2019-04-25 11:32:30 --> 404 Page Not Found: Permission/role_admins
ERROR - 2019-04-25 19:07:23 --> Severity: Warning --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/AD/application/views/Books/show_books.php 112
