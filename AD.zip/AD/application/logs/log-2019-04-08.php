<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-08 04:23:05 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 113
ERROR - 2019-04-08 04:23:18 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ',' or ')' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 113
ERROR - 2019-04-08 04:28:28 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:11:43 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:11:48 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:11:50 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:11:57 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:12:11 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:12:34 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:13:26 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:14:17 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:14:55 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:15:11 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:15:46 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:18:49 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:18:53 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:27:28 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:28:24 --> 404 Page Not Found: Common/css
ERROR - 2019-04-08 05:29:00 --> 404 Page Not Found: Common/css
