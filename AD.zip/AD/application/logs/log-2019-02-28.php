<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-28 02:25:13 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting ';' or '{' /Applications/MAMP/htdocs/CI/application/libraries/Captcha.php 27
ERROR - 2019-02-28 02:25:20 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting ';' or '{' /Applications/MAMP/htdocs/CI/application/libraries/Captcha.php 27
ERROR - 2019-02-28 02:25:22 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting ';' or '{' /Applications/MAMP/htdocs/CI/application/libraries/Captcha.php 27
ERROR - 2019-02-28 02:31:07 --> 404 Page Not Found: Home/yanzhengma
ERROR - 2019-02-28 02:31:44 --> 404 Page Not Found: Home/yanzhengma
ERROR - 2019-02-28 02:32:30 --> 404 Page Not Found: Home/yanzhengma
ERROR - 2019-02-28 02:46:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:94) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-02-28 02:49:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:94) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-02-28 02:50:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:94) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-02-28 02:50:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:94) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-02-28 02:51:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:94) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-02-28 02:52:48 --> Severity: error --> Exception: Call to undefined function required() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 95
ERROR - 2019-02-28 02:52:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:94) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-28 02:53:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:94) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-02-28 03:18:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/application/controllers/Home.php:94) /Applications/MAMP/htdocs/CI/system/helpers/url_helper.php 564
ERROR - 2019-02-28 09:55:42 --> Severity: error --> Exception: Too few arguments to function User_model::get_user(), 2 passed in /Applications/MAMP/htdocs/CI/application/controllers/Home.php on line 58 and exactly 4 expected /Applications/MAMP/htdocs/CI/application/models/User_model.php 15
ERROR - 2019-02-28 10:13:01 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 192
ERROR - 2019-02-28 10:13:02 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 192
ERROR - 2019-02-28 10:13:02 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /Applications/MAMP/htdocs/CI/application/controllers/Home.php 192
ERROR - 2019-02-28 10:14:49 --> Severity: Notice --> Undefined property: Home::$select /Applications/MAMP/htdocs/CI/application/controllers/Home.php 19
ERROR - 2019-02-28 10:14:49 --> Severity: error --> Exception: Call to a member function option() on null /Applications/MAMP/htdocs/CI/application/controllers/Home.php 19
ERROR - 2019-02-28 10:14:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-28 10:16:19 --> Severity: Notice --> Undefined property: Home::$label /Applications/MAMP/htdocs/CI/application/controllers/Home.php 19
ERROR - 2019-02-28 10:16:19 --> Severity: error --> Exception: Call to a member function select() on null /Applications/MAMP/htdocs/CI/application/controllers/Home.php 19
ERROR - 2019-02-28 10:16:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-28 10:18:11 --> Severity: Notice --> Undefined property: Home::$label /Applications/MAMP/htdocs/CI/application/controllers/Home.php 20
ERROR - 2019-02-28 10:18:11 --> Severity: error --> Exception: Call to a member function select() on null /Applications/MAMP/htdocs/CI/application/controllers/Home.php 20
ERROR - 2019-02-28 10:18:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-28 10:18:21 --> Severity: Notice --> Undefined property: Home::$label /Applications/MAMP/htdocs/CI/application/controllers/Home.php 20
ERROR - 2019-02-28 10:18:21 --> Severity: error --> Exception: Call to a member function select() on null /Applications/MAMP/htdocs/CI/application/controllers/Home.php 20
ERROR - 2019-02-28 10:18:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-28 10:19:05 --> Severity: error --> Exception: Call to undefined method CI_Input::label() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 20
ERROR - 2019-02-28 10:32:05 --> 404 Page Not Found: Home/check
ERROR - 2019-02-28 10:37:59 --> Query error: Unknown column 'phone' in 'where clause' - Invalid query: SELECT *
FROM `lib_user`
WHERE `username` = '13129207435'
AND `email` = '13129207435'
AND `phone` = '13129207435'
AND `password` = '123321'
ERROR - 2019-02-28 10:54:53 --> 404 Page Not Found: Home/login
ERROR - 2019-02-28 10:54:54 --> 404 Page Not Found: Home/login
ERROR - 2019-02-28 10:54:54 --> 404 Page Not Found: Home/login
ERROR - 2019-02-28 10:54:54 --> 404 Page Not Found: Home/login
ERROR - 2019-02-28 10:54:55 --> 404 Page Not Found: Home/login
ERROR - 2019-02-28 10:55:07 --> 404 Page Not Found: Home/login
ERROR - 2019-02-28 11:43:56 --> 404 Page Not Found: Home/do_telephone_login
ERROR - 2019-02-28 15:00:19 --> 404 Page Not Found: Home/search
ERROR - 2019-02-28 15:00:47 --> 404 Page Not Found: Home/search
ERROR - 2019-02-28 15:01:13 --> 404 Page Not Found: Home/search
ERROR - 2019-02-28 15:01:56 --> 404 Page Not Found: Home/search
ERROR - 2019-02-28 15:02:53 --> 404 Page Not Found: Home/search
ERROR - 2019-02-28 15:02:59 --> 404 Page Not Found: Home/search
ERROR - 2019-02-28 15:36:28 --> 404 Page Not Found: Home/login
ERROR - 2019-02-28 16:11:22 --> 404 Page Not Found: Home/login
