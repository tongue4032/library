<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-27 02:46:39 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 02:48:20 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 02:48:22 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 02:48:23 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 02:48:24 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 02:49:24 --> Query error: Table 'library.content' doesn't exist - Invalid query: SELECT *
FROM `content`
ERROR - 2019-03-27 02:49:43 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 02:50:05 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 02:50:30 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 02:51:05 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:12:13 --> Severity: error --> Exception: Call to undefined method CI_Session::set_bookdata() /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 25
ERROR - 2019-03-27 03:16:51 --> Severity: error --> Exception: Call to a member function get() on array /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 101
ERROR - 2019-03-27 03:18:29 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 25
ERROR - 2019-03-27 03:18:58 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 25
ERROR - 2019-03-27 03:25:37 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 102
ERROR - 2019-03-27 03:27:39 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 102
ERROR - 2019-03-27 03:29:02 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 109
ERROR - 2019-03-27 03:30:01 --> Severity: Notice --> Undefined index: barcode /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 102
ERROR - 2019-03-27 03:32:07 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 102
ERROR - 2019-03-27 03:33:08 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 102
ERROR - 2019-03-27 03:33:39 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 102
ERROR - 2019-03-27 03:34:45 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 102
ERROR - 2019-03-27 03:34:55 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 102
ERROR - 2019-03-27 03:35:21 --> Severity: Notice --> Undefined index: string(content) /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 102
ERROR - 2019-03-27 03:37:07 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 102
ERROR - 2019-03-27 03:37:34 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:38:17 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:38:17 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:38:18 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:38:18 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:38:19 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:38:19 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:38:19 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:38:19 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:42:39 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:42:47 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:43:12 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:43:44 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:43:45 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:43:45 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:43:45 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:43:45 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:43:46 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:43:54 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 03:47:02 --> 404 Page Not Found: Common/css
ERROR - 2019-03-27 03:47:51 --> 404 Page Not Found: Common/css
ERROR - 2019-03-27 03:48:01 --> 404 Page Not Found: Common/css
ERROR - 2019-03-27 03:48:18 --> 404 Page Not Found: Common/css
ERROR - 2019-03-27 03:48:36 --> 404 Page Not Found: Common/css
ERROR - 2019-03-27 03:48:38 --> 404 Page Not Found: Common/css
ERROR - 2019-03-27 03:48:52 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 101
ERROR - 2019-03-27 03:48:53 --> 404 Page Not Found: Common/css
ERROR - 2019-03-27 03:49:30 --> 404 Page Not Found: Common/css
ERROR - 2019-03-27 03:50:01 --> Severity: Notice --> Trying to get property of non-object /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 101
ERROR - 2019-03-27 03:51:08 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 101
ERROR - 2019-03-27 03:54:01 --> Severity: Notice --> Undefined offset: 0 /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 101
ERROR - 2019-03-27 03:58:25 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 101
ERROR - 2019-03-27 03:58:52 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 101
ERROR - 2019-03-27 04:01:17 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:03:47 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:03:52 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:04:49 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:05:31 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:06:32 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:08:17 --> Severity: Notice --> Undefined variable: barcode /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 22
ERROR - 2019-03-27 04:08:17 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:08:31 --> Severity: Notice --> Undefined variable: barcode /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 22
ERROR - 2019-03-27 04:08:31 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:09:00 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:09:26 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:10:00 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:10:52 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:11:23 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:12:13 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 99
ERROR - 2019-03-27 04:12:13 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:12:23 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:15:12 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 22
ERROR - 2019-03-27 04:15:12 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:16:32 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:21:01 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:21:03 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:21:09 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:21:25 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:21:29 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:22:23 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:22:24 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:23:11 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:23:42 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:23:53 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:23:55 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:23:58 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:24:43 --> Severity: Notice --> Undefined variable: book /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 101
ERROR - 2019-03-27 04:24:43 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:25:15 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 101
ERROR - 2019-03-27 04:25:15 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 110
ERROR - 2019-03-27 04:25:15 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:25:39 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 101
ERROR - 2019-03-27 04:25:39 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 110
ERROR - 2019-03-27 04:25:39 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:25:46 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 110
ERROR - 2019-03-27 04:25:46 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:25:54 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:26:17 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 101
ERROR - 2019-03-27 04:26:28 --> Severity: Notice --> Undefined variable: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:27:30 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 108
ERROR - 2019-03-27 04:27:38 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:27:43 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:27:58 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:28:15 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:28:24 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:28:53 --> Severity: error --> Exception: Call to undefined function string() /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:29:57 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:30:04 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:30:21 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:32:38 --> Severity: Notice --> Undefined offset: 6 /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 99
ERROR - 2019-03-27 04:32:52 --> Severity: Notice --> Undefined offset: 6 /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 99
ERROR - 2019-03-27 04:32:58 --> Severity: Notice --> Undefined index: content /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 99
ERROR - 2019-03-27 04:33:14 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:33:39 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:41:37 --> Query error: Table 'library.content' doesn't exist - Invalid query: SELECT `lib_bookinfo`
FROM `content`
WHERE `barcode` = '101'
ERROR - 2019-03-27 04:42:13 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 2442
ERROR - 2019-03-27 04:42:13 --> Query error: Table 'library.content' doesn't exist - Invalid query: SELECT *
FROM `content`
WHERE `lib_bookinfo` = Array
ERROR - 2019-03-27 04:42:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-27 04:42:33 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/system/database/DB_query_builder.php 2442
ERROR - 2019-03-27 04:42:33 --> Query error: Unknown column 'lib_bookinfo' in 'where clause' - Invalid query: SELECT *
FROM `lib_bookinfo`
WHERE `lib_bookinfo` = Array
 LIMIT 0
ERROR - 2019-03-27 04:42:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-27 04:42:41 --> Query error: Table 'library.content' doesn't exist - Invalid query: SELECT `lib_bookinfo`
FROM `content`
WHERE `barcode` = '101'
ERROR - 2019-03-27 04:45:47 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 04:48:58 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 05:06:56 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 05:07:50 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 05:08:29 --> Severity: Notice --> Array to string conversion /Applications/MAMP/htdocs/AD/application/views/change.php 145
ERROR - 2019-03-27 07:23:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='梅德水' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='梅德水' press='瞎蒙人民出版社' publish_date='2011-08-00' where barcode=114'
ERROR - 2019-03-27 07:29:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='梅德水' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='梅德水' press='瞎蒙人民出版社' publish_date='2011-08-00' where barcode='114'
ERROR - 2019-03-27 07:33:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='梅德水' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='梅德水' press='瞎蒙人民出版社' publish_date='2011-08-00' content='《摆渡人》是一篇灵魂治愈小说，它那史诗般的动人故事、完全意想不到的情节构思、作者高超的写作技巧和多重主题的相与交融，不但使作品别具一格，值得瞩目，而且又不失其内涵和令人深思的空间，通过解析富有浓郁哲理的三重主题，引导读者体会到小说表面上看似乎是作者天马行空的想象，而其本质上是作者对现实社会、人类自身进行探索后加上自身的见解，对社会和人性的揭露，也是人类情感复杂性的真实写照。' where barcode='114'
ERROR - 2019-03-27 07:38:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'bookname='摆渡人' author='梅德水' press='瞎蒙人民出版社' publish_da' at line 1 - Invalid query: update lib_bookinfo set barcode='114' bookname='摆渡人' author='梅德水' press='瞎蒙人民出版社' publish_date='2011-08-00' content='《摆渡人》是一篇灵魂治愈小说，它那史诗般的动人故事、完全意想不到的情节构思、作者高超的写作技巧和多重主题的相与交融，不但使作品别具一格，值得瞩目，而且又不失其内涵和令人深思的空间，通过解析富有浓郁哲理的三重主题，引导读者体会到小说表面上看似乎是作者天马行空的想象，而其本质上是作者对现实社会、人类自身进行探索后加上自身的见解，对社会和人性的揭露，也是人类情感复杂性的真实写照。' where barcode='114'
ERROR - 2019-03-27 07:50:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'author='梅德水' where barcode=''' at line 1 - Invalid query: update lib_bookinfo set bookname='《摆渡》' author='梅德水' where barcode=''
ERROR - 2019-03-27 08:08:01 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::set_update() /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 62
ERROR - 2019-03-27 08:08:31 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::update_set() /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 62
ERROR - 2019-03-27 08:43:00 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 138
ERROR - 2019-03-27 08:43:00 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-27 08:43:00 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 138
ERROR - 2019-03-27 08:43:00 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-27 08:43:00 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 138
ERROR - 2019-03-27 08:43:00 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-27 08:43:04 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 138
ERROR - 2019-03-27 08:43:04 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-27 08:43:04 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 138
ERROR - 2019-03-27 08:43:04 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-27 08:43:04 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 138
ERROR - 2019-03-27 08:43:04 --> Severity: Notice --> Undefined index: register_date /Applications/MAMP/htdocs/AD/application/views/show_admins.php 139
ERROR - 2019-03-27 09:07:12 --> Severity: Notice --> Undefined index: professional /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 75
ERROR - 2019-03-27 09:07:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'professional=''' at line 1 - Invalid query: update lib_admin set admin_name='admin3' professional=''
ERROR - 2019-03-27 09:07:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-27 10:47:55 --> Severity: Notice --> Undefined variable: admin_id /Applications/MAMP/htdocs/AD/application/views/admin_info.php 128
ERROR - 2019-03-27 10:56:33 --> Severity: error --> Exception: Call to undefined method Admin_model::get_admin_info() /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 64
ERROR - 2019-03-27 10:56:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/controllers/Admin.php:63) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-03-27 10:57:45 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' /Applications/MAMP/htdocs/AD/application/models/Admin_model.php 28
ERROR - 2019-03-27 11:00:46 --> Severity: Notice --> Undefined variable: admin_id /Applications/MAMP/htdocs/AD/application/views/admin_info.php 128
