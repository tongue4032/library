<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-06 03:34:18 --> Severity: Notice --> Undefined variable: heading /Applications/MAMP/htdocs/CI/application/views/errors/cli/error_404.php 5
ERROR - 2019-03-06 03:34:18 --> Severity: Notice --> Undefined variable: message /Applications/MAMP/htdocs/CI/application/views/errors/cli/error_404.php 7
ERROR - 2019-03-06 03:34:40 --> 404 Page Not Found: Home/css
ERROR - 2019-03-06 03:34:40 --> 404 Page Not Found: Home/css
ERROR - 2019-03-06 03:35:14 --> 404 Page Not Found: Home/css
ERROR - 2019-03-06 03:35:14 --> 404 Page Not Found: Home/css
ERROR - 2019-03-06 03:35:20 --> 404 Page Not Found: Home/css
ERROR - 2019-03-06 03:35:20 --> 404 Page Not Found: Home/css
ERROR - 2019-03-06 03:35:22 --> 404 Page Not Found: Home/css
ERROR - 2019-03-06 03:35:22 --> 404 Page Not Found: Home/css
ERROR - 2019-03-06 03:35:26 --> 404 Page Not Found: Home/css
ERROR - 2019-03-06 03:35:26 --> 404 Page Not Found: Home/css
ERROR - 2019-03-06 07:16:38 --> 404 Page Not Found: admin/Home/index
ERROR - 2019-03-06 07:18:13 --> 404 Page Not Found: admin/Home/index
ERROR - 2019-03-06 07:19:27 --> 404 Page Not Found: admin/Home/index
ERROR - 2019-03-06 07:19:29 --> 404 Page Not Found: admin//index
ERROR - 2019-03-06 07:19:32 --> 404 Page Not Found: /index
ERROR - 2019-03-06 07:19:44 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /Applications/MAMP/htdocs/CI/application/controllers/admin/Adminhome.php 16
ERROR - 2019-03-06 07:20:10 --> 404 Page Not Found: admin/Adminhome/index
ERROR - 2019-03-06 07:20:30 --> 404 Page Not Found: admin/Adminhome/index
ERROR - 2019-03-06 07:20:34 --> 404 Page Not Found: admin/Adminhome/index
ERROR - 2019-03-06 07:20:35 --> 404 Page Not Found: admin/Adminhome/index
ERROR - 2019-03-06 07:21:20 --> Severity: error --> Exception: syntax error, unexpected ',' /Applications/MAMP/htdocs/CI/application/config/routes.php 52
ERROR - 2019-03-06 07:21:33 --> 404 Page Not Found: admin/Adminhome/index
ERROR - 2019-03-06 07:21:58 --> 404 Page Not Found: admin/Adminhome/index
ERROR - 2019-03-06 07:22:03 --> 404 Page Not Found: /index
ERROR - 2019-03-06 07:42:10 --> Unable to load the requested class: Captcha
ERROR - 2019-03-06 07:42:50 --> Unable to load the requested class: Captcha
ERROR - 2019-03-06 07:43:37 --> Unable to load the requested class: Captcha
ERROR - 2019-03-06 07:44:21 --> 404 Page Not Found: Home/borrowinfo
ERROR - 2019-03-06 08:03:30 --> 404 Page Not Found: Home/index
ERROR - 2019-03-06 08:03:51 --> 404 Page Not Found: Home/index
ERROR - 2019-03-06 08:04:19 --> 404 Page Not Found: Home/username_login
ERROR - 2019-03-06 08:05:30 --> 404 Page Not Found: Home/username_login
ERROR - 2019-03-06 08:05:45 --> 404 Page Not Found: Home/username_login
ERROR - 2019-03-06 08:05:47 --> 404 Page Not Found: /index
ERROR - 2019-03-06 08:05:51 --> 404 Page Not Found: /index
ERROR - 2019-03-06 08:06:23 --> 404 Page Not Found: /index
ERROR - 2019-03-06 08:06:29 --> 404 Page Not Found: /index
ERROR - 2019-03-06 08:06:32 --> 404 Page Not Found: /index
ERROR - 2019-03-06 08:06:33 --> 404 Page Not Found: /index
ERROR - 2019-03-06 08:06:45 --> 404 Page Not Found: index/Css/style4.css
ERROR - 2019-03-06 08:06:45 --> 404 Page Not Found: index/Css/font-awesome.css
ERROR - 2019-03-06 08:07:06 --> 404 Page Not Found: index/Css/font-awesome.css
ERROR - 2019-03-06 08:07:06 --> 404 Page Not Found: index/Css/style4.css
ERROR - 2019-03-06 08:07:45 --> 404 Page Not Found: admin//index
ERROR - 2019-03-06 08:08:18 --> 404 Page Not Found: admin/Adminhome/index
ERROR - 2019-03-06 08:08:30 --> 404 Page Not Found: admin/Adminhome/index
ERROR - 2019-03-06 08:35:44 --> 404 Page Not Found: Index/Home
ERROR - 2019-03-06 08:37:10 --> 404 Page Not Found: Index/Home
ERROR - 2019-03-06 08:37:32 --> 404 Page Not Found: Index/Home
ERROR - 2019-03-06 08:41:40 --> 404 Page Not Found: Admin/adminhome
ERROR - 2019-03-06 08:43:17 --> 404 Page Not Found: Admin/adminhome
ERROR - 2019-03-06 08:43:39 --> 404 Page Not Found: Admin/adminhome
ERROR - 2019-03-06 08:44:43 --> 404 Page Not Found: Home/adminhome
ERROR - 2019-03-06 08:45:31 --> Severity: error --> Exception: syntax error, unexpected ',' /Applications/MAMP/htdocs/CI/application/config/routes.php 52
ERROR - 2019-03-06 08:45:41 --> Severity: error --> Exception: syntax error, unexpected ''adminhome'' (T_CONSTANT_ENCAPSED_STRING) /Applications/MAMP/htdocs/CI/application/config/routes.php 52
ERROR - 2019-03-06 08:46:11 --> 404 Page Not Found: /index
ERROR - 2019-03-06 08:46:53 --> 404 Page Not Found: Home/admin
