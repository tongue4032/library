<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-11 04:36:56 --> 404 Page Not Found: Home/css
ERROR - 2019-02-11 04:36:56 --> 404 Page Not Found: Home/css
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-11 04:36:56 --> 404 Page Not Found: Home/index.php
ERROR - 2019-02-11 04:37:12 --> 404 Page Not Found: Home/index.php
ERROR - 2019-02-11 04:37:12 --> 404 Page Not Found: Home/css
ERROR - 2019-02-11 04:37:12 --> 404 Page Not Found: Home/css
ERROR - 2019-02-11 04:37:13 --> 404 Page Not Found: Home/css
ERROR - 2019-02-11 04:37:13 --> 404 Page Not Found: Home/css
ERROR - 2019-02-11 04:37:13 --> 404 Page Not Found: Home/index.php
ERROR - 2019-02-11 04:37:24 --> 404 Page Not Found: Home/index.php
ERROR - 2019-02-11 04:37:32 --> 404 Page Not Found: Home/css
ERROR - 2019-02-11 04:37:40 --> 404 Page Not Found: Home/css
ERROR - 2019-02-11 04:38:04 --> 404 Page Not Found: Home/css
ERROR - 2019-02-11 04:38:05 --> 404 Page Not Found: Home/css
ERROR - 2019-02-11 04:38:05 --> 404 Page Not Found: Home/index.php
ERROR - 2019-02-11 04:40:08 --> 404 Page Not Found: Home/login
ERROR - 2019-02-11 04:40:18 --> 404 Page Not Found: Home/Login
ERROR - 2019-02-11 04:41:10 --> 404 Page Not Found: Home/Login
ERROR - 2019-02-11 04:41:11 --> 404 Page Not Found: Home/Login
ERROR - 2019-02-11 05:01:02 --> Severity: error --> Exception: Call to undefined method CI_Loader::css() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 14
ERROR - 2019-02-11 08:50:14 --> Severity: error --> Exception: Call to undefined function base_url() /Applications/MAMP/htdocs/CI/application/views/register.php 19
ERROR - 2019-02-11 09:15:02 --> 404 Page Not Found: Indexphp/Home
ERROR - 2019-02-11 09:15:02 --> 404 Page Not Found: Css/font-awesome.css
ERROR - 2019-02-11 09:15:02 --> 404 Page Not Found: Css/style.css
ERROR - 2019-02-11 09:15:30 --> 404 Page Not Found: Css/style.css
ERROR - 2019-02-11 09:15:30 --> 404 Page Not Found: Indexphp/Home
ERROR - 2019-02-11 09:15:30 --> 404 Page Not Found: Css/font-awesome.css
ERROR - 2019-02-11 09:15:42 --> 404 Page Not Found: Css/font-awesome.css
ERROR - 2019-02-11 09:15:42 --> 404 Page Not Found: Indexphp/Home
ERROR - 2019-02-11 09:15:42 --> 404 Page Not Found: Css/style.css
ERROR - 2019-02-11 09:15:43 --> 404 Page Not Found: Css/style.css
ERROR - 2019-02-11 09:15:43 --> 404 Page Not Found: Css/font-awesome.css
ERROR - 2019-02-11 09:15:43 --> 404 Page Not Found: Indexphp/Home
ERROR - 2019-02-11 09:16:07 --> 404 Page Not Found: Css/style.css
ERROR - 2019-02-11 09:16:07 --> 404 Page Not Found: Indexphp/Home
ERROR - 2019-02-11 09:16:07 --> 404 Page Not Found: Css/font-awesome.css
ERROR - 2019-02-11 09:16:08 --> 404 Page Not Found: Css/style.css
ERROR - 2019-02-11 09:16:08 --> 404 Page Not Found: Css/font-awesome.css
ERROR - 2019-02-11 09:16:08 --> 404 Page Not Found: Indexphp/Home
ERROR - 2019-02-11 09:16:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-02-11 09:16:45 --> 404 Page Not Found: Indexphp/Home
ERROR - 2019-02-11 09:16:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-02-11 09:16:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-02-11 09:16:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-02-11 09:16:46 --> 404 Page Not Found: Indexphp/Home
ERROR - 2019-02-11 09:17:34 --> 404 Page Not Found: Css/font-awesome.css
ERROR - 2019-02-11 09:17:34 --> 404 Page Not Found: Indexphp/Home
ERROR - 2019-02-11 09:17:34 --> 404 Page Not Found: Css/style.css
ERROR - 2019-02-11 09:17:34 --> 404 Page Not Found: Indexphp/Home
ERROR - 2019-02-11 09:17:34 --> 404 Page Not Found: Css/font-awesome.css
ERROR - 2019-02-11 09:17:34 --> 404 Page Not Found: Css/style.css
ERROR - 2019-02-11 09:20:08 --> Severity: error --> Exception: Call to undefined method CI_Loader::controller() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-11 09:20:28 --> Severity: error --> Exception: Call to undefined method CI_Loader::controllers() /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-11 09:20:53 --> Severity: Notice --> Undefined property: Home::$controllers /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-11 09:20:53 --> Severity: error --> Exception: Call to a member function view() on null /Applications/MAMP/htdocs/CI/application/controllers/Home.php 13
ERROR - 2019-02-11 09:20:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/CI/system/core/Exceptions.php:271) /Applications/MAMP/htdocs/CI/system/core/Common.php 570
ERROR - 2019-02-11 09:46:48 --> 404 Page Not Found: Yanzhengma/index
ERROR - 2019-02-11 09:48:20 --> 404 Page Not Found: Home/css
ERROR - 2019-02-11 09:48:20 --> 404 Page Not Found: Home/css
ERROR - 2019-02-11 09:48:20 --> 404 Page Not Found: Home/index.php
ERROR - 2019-02-11 09:50:40 --> 404 Page Not Found: Home/css
ERROR - 2019-02-11 09:50:40 --> 404 Page Not Found: Home/index.php
ERROR - 2019-02-11 09:50:40 --> 404 Page Not Found: Home/css
