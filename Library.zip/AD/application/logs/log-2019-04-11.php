<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-11 05:23:11 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 05:27:07 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 05:27:28 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 05:38:43 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 05:39:06 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 05:40:18 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 05:45:14 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 05:46:00 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 05:46:30 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 05:50:11 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 08:30:40 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ',' or ')' /Applications/MAMP/htdocs/AD/application/controllers/Admin.php 113
ERROR - 2019-04-11 08:39:48 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 08:58:16 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 09:03:20 --> 404 Page Not Found: Admin/do_loginxxx
ERROR - 2019-04-11 09:10:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-11 09:11:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-11 09:12:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-11 09:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-11 09:13:56 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 09:14:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/AD/application/libraries/Pagination.php:1) /Applications/MAMP/htdocs/AD/system/core/Common.php 570
ERROR - 2019-04-11 09:17:23 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 09:22:34 --> 404 Page Not Found: Do_login/index
ERROR - 2019-04-11 09:22:35 --> 404 Page Not Found: Do_login/index
ERROR - 2019-04-11 09:22:37 --> 404 Page Not Found: Do_login/index
ERROR - 2019-04-11 09:22:38 --> 404 Page Not Found: Do_login/index
ERROR - 2019-04-11 09:22:39 --> 404 Page Not Found: Do_login/index
ERROR - 2019-04-11 09:22:42 --> 404 Page Not Found: Do_login/index
ERROR - 2019-04-11 09:22:42 --> 404 Page Not Found: Do_login/index
ERROR - 2019-04-11 09:22:42 --> 404 Page Not Found: Do_login/index
ERROR - 2019-04-11 09:22:42 --> 404 Page Not Found: Do_login/index
ERROR - 2019-04-11 09:22:42 --> 404 Page Not Found: Do_login/index
ERROR - 2019-04-11 09:22:43 --> 404 Page Not Found: Do_login/index
ERROR - 2019-04-11 09:22:43 --> 404 Page Not Found: Do_login/index
ERROR - 2019-04-11 09:22:47 --> 404 Page Not Found: Do_login/index
ERROR - 2019-04-11 09:31:00 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 09:33:44 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 09:34:24 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 09:35:21 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 09:35:44 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 09:35:45 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 09:35:47 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 09:35:49 --> 404 Page Not Found: Common/css
ERROR - 2019-04-11 09:36:16 --> 404 Page Not Found: Common/css
