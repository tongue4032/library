<?php
if (! defined('BASEPATH')) exit('No direct script access allowed');
class Admin extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->library('session');	
		$this->load->helper('url');
		$this->load->model('admin_model');
        $this->load->library('pagination');
        $this->load->library('form_validation');
	}
	//登录页面
	public function index(){
		$this->load->view('login');
	}

    //主页面
	public function home(){
		$this->load->view('index');
	}	

    //注销登录
    public function logout(){
        $this->session->unset_userdata('user');
        echo "<script>window.location='./index'</script>";
    }

    //管理员信息
    public function admin_info(){
        $this->load->view('admin_info');
    }

    //添加图书
    public function add_book(){
        $this->load->view('add_books');
    }
	
	//显示书库
	public function show_books(){
        $page_size = 7;
        $page = $this->uri->segment(4);
        if($page == Null){
            $page = 1;
        }
        $offset = ($page - 1) * $page_size;
        $pageall = $this->admin_model->get_all();
        $config['base_url'] = '/Admin/show_books/page/';
        $config['total_rows'] = $pageall['total'];
        $config['per_page'] = $page_size;
        $config['use_page_numbers'] = true;//URL中的数字显示第几页，否则，显示到达第几条
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';

        $data['book'] = $this->admin_model->book_select_all($page_size,$offset);
        $this->pagination->initialize($config);
        $data['link'] = $this->pagination->create_links();
		$this->load->view('show_books',$data);
	}
	
	//显示用户
    public function show_users(){
        $page_size = 8;
        $page = $this->uri->segment(4);
        if($page == Null){
            $page = 1;
        }
        $offset = ($page - 1) * $page_size;
        $pageall = $this->admin_model->get_user_all();
        $config['base_url'] = '/Admin/show_users/page/';
        $config['total_rows'] = $pageall['total'];
        $config['per_page'] = $page_size;
        $config['use_page_numbers'] = true;//URL中的数字显示第几页，否则，显示到达第几条
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';

        $data['users'] = $this->admin_model->user_select_all($page_size,$offset);
        $this->pagination->initialize($config);
        $data['link'] = $this->pagination->create_links();
        // $data['users'] = $this->admin_model->show_user();
    	$this->load->view('show_users',$data);
    }

    //显示管理员
    public function show_admins(){
        $page_size = 8;
        $page = $this->uri->segment(4);
        if($page == Null){
            $page = 1;
        }
        $offset = ($page - 1) * $page_size;
        $pageall = $this->admin_model->get_admin_all();
        $config['base_url'] = '/Admin/show_admins/page/';
        $config['total_rows'] = $pageall['total'];
        $config['per_page'] = $page_size;
        $config['use_page_numbers'] = true;//URL中的数字显示第几页，否则，显示到达第几条
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';

        $data['admins'] = $this->admin_model->admin_select_all($page_size,$offset);
        $this->pagination->initialize($config);
        $data['link'] = $this->pagination->create_links();
        // $data['admins'] = $this->admin_model->show_admin();
        $this->load->view('show_admins',$data);
    }

	//登录
	public function do_login(){
	 	$username = $this->input->post('username');
		$password = $this->input->post('password');
        $pwd = md5($password);
		$user = $this->admin_model->get_user($username,$pwd);
		if ($user) {
            $this->session->set_userdata('user', $user);
            echo json_encode(array('code' => 1, 'message' => 'Welcome!'));
        } else {
            echo json_encode(array('code' => 0, 'message' => 'Incorrect admin name or password！'));
        }
	}

    //执行添加
    public function add(){
        $this->form_validation->set_rules('barcode','Barcode','numeric');
        $this->form_validation->set_rules('bookname','Bookname','max_length[8]');
        $this->form_validation->set_rules('author','Author','max_length[10]');
        $this->form_validation->set_rules('press','Press','min_length[7]|max_length[12]');
        $this->form_validation->set_rules('publish_date','Publish_date','alpha_dash|numeric|min_length[10]');
        $this->form_validation->set_rules('content','Content','max_length[120]');

        if($this->form_validation->run() == false){
            echo validation_errors();
        }else{
        	$barcode = $this->input->post('barcode',true);
        	$bookname = $this->input->post('bookname',true);
        	$author = $this->input->post('author',true);
        	$press = $this->input->post('press',true);
        	$publish_date = $this->input->post('date',true);
        	$content = $this->input->post('content',true);
        	$data = array(
        		'barcode' => $barcode,
        		'bookname' => $bookname,
        		'author' => $author,
        		'press' => $press,
        		'publish_date' => $publish_date,
        		'content' => $content
        	);
        	$add_book = $this->admin_model->add_book($data);
        	if ($add_book) {
                echo json_encode(array('code' => 1, 'message' => 'Add successfull!'));
            }else {
        	    echo json_encode(array('code' => 0, 'message' => 'Add failure'));
            }
        }
    }

    //修改图书
    public function change_book(){
    	$barcode = $this->input->get('barcode',Null);
    	$bookname = $this->input->get('bookname',Null);
    	$author = $this->input->get('author',Null);
		$press = $this->input->get('press',Null);
		$publish_date = $this->input->get('publish_date',Null);
		$book = $this->admin_model->get($barcode);
        $content = $book['content'];
        // var_dump($content);
        // var_dump($data['book']);
		$data = array(
			'barcode' => $barcode,
			'bookname' => $bookname,
			'author' => $author,
			'press' => $press,
			'publish_date' => $publish_date,
            'content' => $content
		);

    	$this->load->view('change',$data,$content);
    }

    //执行修改
    public function change(){
        $this->form_validation->set_rules('bookname','Bookname','max_length[8]');
        $this->form_validation->set_rules('author','Author','max_length[10]');
        $this->form_validation->set_rules('press','Press','min_length[7]|max_length[12]');
        $this->form_validation->set_rules('publish_date','Publish_date','alpha_dash|numeric|min_length[10]');
        $this->form_validation->set_rules('content','Content','max_length[120]');

        if($this->form_validation->run() == false){
            echo validation_errors();
        }else{
        	$barcode = $this->input->post('barcode');
        	$bookname = $this->input->post('bookname',true);
        	$author = $this->input->post('author',true);
        	$press = $this->input->post('press',true);
        	$publish_date = $this->input->post('date',true);
            $content = $this->input->post('content',true);
        	$data = array(
        		'bookname' => $bookname,
        		'author' => $author,
        		'press' => $press,
        		'publish_date' => $publish_date,
                'content' => $content
        	);
        	$book = $this->admin_model->change_book($data,$barcode);
        	if($book) {
                echo json_encode(array('code' => 1, 'message' => 'Modify successfull!'));
            }else{
        	    echo json_encode(array('code' => 0 , 'message' => 'Modify failure！'));
            }
        }
    }

    //删除图书
    public function delete_book(){
    	$barcode = $this->input->get('barcode',Null);
    	$bookname = $this->input->get('bookname',Null);
    	$author = $this->input->get('author',Null);
		$press = $this->input->get('press',Null);
		$publish_date = $this->input->get('publish_date',Null);
		$data = array(
			'barcode' => $barcode,
			'bookname' => $bookname,
			'author' => $author,
			'press' => $press,
			'publish_date' => $publish_date
		);
		if($this->admin_model->delete_books($data)){
			echo "<script>window.location='/Admin/show_books'</script>";
		}else{
			echo "<script>window.location='/Admin/show_books'</script>";
		}
    }

    //删除用户
    public function delete_user(){
        $user_id = $this->input->get('user_id',Null);
        $username = $this->input->get('username',Null);
        $telephone = $this->input->get('telephone',Null);
        $email = $this->input->get('email',Null);
        $register_date = $this->input->get('register_date',Null);
        $data = array(
            'user_id' => $user_id,
            'username' => $username,
            'telephone' => $telephone,
            'email' => $email,
            'register_date' => $register_date
        );
        if($this->admin_model->delete_users($data)){
            // var_dump('hello');
            echo "<script>window.location='/Admin/show_users'</script>";
        }else{
            echo "<script>window.location='/Admin/show_users'</script>";
        }
    }

    //修改管理员
    public function change_admin(){
        $user = $this->session->userdata('user');
        if($user['professional'] == 'Administrator'){
            echo "<script>alert('You do not have permission to do this!');window.location='/Admin/show_admins'</script>";
        }else{
            $admin_id = $this->input->get('admin_id',Null);
            $admin_name = $this->input->get('admin_name',Null);
            $professional = $this->input->get('professional',Null);
            $data = array(
                'admin_id' => $admin_id,
                'admin_name' => $admin_name,
                'professional' => $professional
            );
            $this->load->view('change_admin',$data);
        }
    }

    //执行修改
    public function change_admins(){
        $this->form_validation->set_rules('admin_name','Admin_name','max_length[8]');

        if($this->form_validation->run() == false){
            echo validation_errors();
        }else{
            $admin_id = $this->input->post('admin_id');
            $admin_name = $this->input->post('admin_name',true);
            $data = array(
                'admin_name' => $admin_name,
            );
            $admin = $this->admin_model->change_admin($data,$admin_id);
            if($admin) {
                echo json_encode(array('code' => 1, 'message' => 'Modify successfull!'));
            }else{
                echo json_encode(array('code' => 0, 'message' => 'Modify failure!'));
            }
        }
    }

    //删除管理员
    public function delete_admins(){
        $user = $this->session->userdata('user');
        if($user['professional'] == 'Administrator'){
            echo "<script>alert('You do not have permission to do this!');window.location='/Admin/show_admins'</script>";
        }else{
            $admin_id = $this->input->get('admin_id',Null);
            $admin_name = $this->input->get('admin_name',Null);
            $professional = $this->input->get('professional',Null);
            $last_login_date = $this->input->get('last_login_date',Null);
            $data = array(
                'admin_id' => $admin_id,
                'admin_name' => $admin_name,
                'professional' => $professional,
                'last_login_date' => $last_login_date
            );
            if($this->admin_model->delete_admins($data)){
            // var_dump('hello');
                echo "<script>window.location='/Admin/show_admins'</script>";
            }else{
                echo "<script>window.location='/Admin/show_admins'</script>";
            }
        }
    }

    //添加管理员
    public function add_admin(){
        $user = $this->session->userdata('user');
        if($user['professional'] == 'Administrator'){
            echo "<script>alert('You do not have permission to do this!');window.location='/Admin/show_admins'</script>";
        }else{
            $data['type'] = $this->admin_model->get_type();
            $this->load->view('add_admins',$data);
        }
    }

    //执行添加
    public function add_admins(){
        $this->form_validation->set_rules('admin_name','Admin_name','max_length[8]');
        $this->form_validation->set_rules('admin_pwd','Admin_Password','min_length[6]|max_length[10]','alpha_dash');

        if($this->form_validation->run() == false){
            echo validation_errors();
        }else{
            $admin_name = $this->input->post('admin_name',true);
            $admin_pwd = $this->input->post('admin_pwd',true);
            $ad_pwd = md5($admin_pwd);
            $professional = $this->input->post('professional');
            $data = array(
                'admin_name' => $admin_name,
                'admin_pwd' => $ad_pwd,
                'professional' => $professional
            );
            $add = $this->admin_model->add_admin($data);
            if($add) {
                echo json_encode(array('code' => 1, 'message' => 'Add successfull!'));
            }else{
                echo json_encode(array('code' => 0, 'message' => 'Add failure!'));
            }
        }
    }

    //分配角色
    public function role_users(){
        $page_size = 7;
        $page = $this->uri->segment(4);
        if($page == Null){
            $page = 1;
        }
        $offset = ($page - 1) * $page_size;
        $pageall = $this->admin_model->get_user_all();
        $config['base_url'] = '/Admin/role_users/page/';
        $config['total_rows'] = $pageall['total'];
        $config['per_page'] = $page_size;
        $config['use_page_numbers'] = true;//URL中的数字显示第几页，否则，显示到达第几条
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';

        $data['users'] = $this->admin_model->user_select_all($page_size,$offset);
        $this->pagination->initialize($config);
        $data['link'] = $this->pagination->create_links();
        // $data['users'] = $this->admin_model->show_user();
        $this->load->view('role_users',$data);
    }

    public function role_admins(){
        $page_size = 5;
        $page = $this->uri->segment(4);
        if($page == Null){
            $page = 1;
        }
        $offset = ($page - 1) * $page_size;
        $pageall = $this->admin_model->get_admin_all();
        $config['base_url'] = '/Admin/role_admins/page/';
        $config['total_rows'] = $pageall['total'];
        $config['per_page'] = $page_size;
        $config['use_page_numbers'] = true;//URL中的数字显示第几页，否则，显示到达第几条
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';

        $data['admins'] = $this->admin_model->admin_select_all($page_size,$offset);
        $this->pagination->initialize($config);
        $data['link'] = $this->pagination->create_links();
        // $data['admins'] = $this->admin_model->show_admin();
        $this->load->view('role_admins',$data);
    }

    //修改用户角色
    public function role(){
        $user = $this->session->userdata('user');
        if($user['professional'] == 'Administrator'){
            echo "<script>alert('You do not have permission to do this!');window.location='/Admin/role_users'</script>";
        }else{
            $user_id = $this->input->get('user_id',Null);
            $username = $this->input->get('username',Null);
            $data = array(
                'user_id' => $user_id,
                'username' => $username
            );
            $data['type'] = $this->admin_model->get_userType();
            $this->load->view('role',$data);
        }
    }

    //执行修改
    public function change_user_role(){
        $this->form_validation->set_rules('professional','Professional','alpha');
        if($this->form_validation->run() == false){
            echo validation_errors();
        }else {
            $user_id = $this->input->post('user_id');
            $username = $this->input->post('username');
            $professional = $this->input->post('professional');
            $data = array(
                'username' => $username,
                'professional' => $professional
            );
            $user_role = $this->admin_model->change_user_role($data, $user_id);
            if($user_role) {
                echo json_encode(array('code' => 1, 'message' => 'Modify successfull!'));
            }else {
                echo json_encode(array('code' => 0, 'message' => 'Modify failuer!'));
            }
        }
    }

    //修改管理员角色
    public function roles(){
        $user = $this->session->userdata('user');
        if($user['professional'] == 'Administrator'){
            echo "<script>alert('You do not have permission to do this!');window.location='/Admin/role_admins'</script>";
        }else{
            $admin_id = $this->input->get('admin_id',Null);
            $admin_name = $this->input->get('admin_name',Null);
            $data = array(
                'admin_id' => $admin_id,
                'admin_name' => $admin_name
            );
            $data['type'] = $this->admin_model->get_type();
            $this->load->view('roles',$data);
        }
    }

    //执行修改
    public function change_admin_role(){
        $this->form_validation->set_rules('professional','Professional','trim|alpha_numeric_spaces');
        if($this->form_validation->run() == false){
            echo validation_errors();
        }else{
            $admin_id = $this->input->post('admin_id');
            $admin_name = $this->input->post('admin_name');
            $professional = $this->input->post('professional',true);
            $data = array(
                'admin_name' => $admin_name,
                'professional' => $professional
            );
            $admin_role = $this->admin_model->change_admin_role($data,$admin_id);
            if($admin_role) {
                echo json_encode(array('code' => 1, 'message' => 'Modify successfull!'));
            }else{
                echo json_encode(array('code' => 0, 'message' => 'Modify failure!'));
            }
        }
    }

    //修改管理员信息
    public function modifyAdmin(){
        $user = $this->session->userdata('user');
        $this->load->view('modifyAdmin',$user);
    }

    //执行修改
    public function do_modify(){
        $this->form_validation->set_rules('admin_name','Admin_name','max_length[6]|alpha_numeric');
        $this->form_validation->set_rules('admin_pwd','Admin_Password','min_length[6]|max_length[10]','alpha_dash');
        if($this->form_validation->run() == false){
            echo validation_errors();
        }else{
            $admin_id = $this->input->post('admin_id');
            $admin_name = $this->input->post('admin_name',true);
            $pwd = $this->input->post('admin_pwd',true);
            $admin_pwd = md5($pwd);
            $professional = $this->input->post('professional');
            $data = array(
                'admin_name' => $admin_name,
                'admin_pwd' => $admin_pwd,
                'professional' => $professional,
            );
            $row = $this->admin_model->modifyAdmin($data,$admin_id);
            if($row) {
                echo json_encode(array('code' => 1, 'message' => 'Modify successfull! Please Login again!'));
            }else{
                echo json_encode(array('code' => 0, 'message' => 'Modify failure!'));
            }
        }
    }

    
}




